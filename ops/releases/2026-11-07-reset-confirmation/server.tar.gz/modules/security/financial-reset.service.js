"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.FinancialResetService = void 0;
const common_1 = require("@nestjs/common");
const security_repository_1 = require("./security.repository");
function receipt(row) {
    if (!row?.request_id)
        throw new common_1.HttpException({ code: 'NOT_FOUND' }, 404);
    return {
        id: row.request_id,
        status: row.cleanup_pending ? 'processing' : 'completed',
        generation: Number(row.generation),
    };
}
let FinancialResetService = class FinancialResetService {
    repository;
    constructor(repository) {
        this.repository = repository;
    }
    reset(principal, operationId) {
        return this.transaction(principal, async (client) => {
            await client.query("set local lock_timeout = '3s'");
            await client.query("set local statement_timeout = '60s'");
            const resetQuery = {
                text: 'select * from private.reset_financial_data($1,$2::uuid)',
                values: [principal.userId, operationId],
                query_timeout: 65_000,
            };
            const result = await client.query(resetQuery);
            return receipt(result.rows[0]);
        });
    }
    receipt(principal, id) {
        return this.transaction(principal, async (client) => {
            const result = await client.query('select * from private.financial_reset_receipt($1,$2::uuid)', [principal.userId, id]);
            return receipt(result.rows[0]);
        });
    }
    state(principal) {
        return this.transaction(principal, async (client) => {
            const result = await client.query('select * from private.financial_reset_state($1)', [principal.userId]);
            const row = result.rows[0];
            if (!row)
                throw new Error('FINANCIAL_RESET_STATE_UNAVAILABLE');
            return {
                generation: Number(row.generation),
                resetAt: row.reset_at?.toISOString() ?? null,
                status: row.cleanup_pending ? 'processing' : 'ready',
                requestId: row.request_id,
            };
        });
    }
    async transaction(principal, work) {
        try {
            return await this.repository.withPrincipalTransaction(principal, work);
        }
        catch (error) {
            if (error instanceof Error && 'code' in error) {
                if (error.code === '42501' && error.message === 'PROFILE_INACTIVE')
                    throw new common_1.HttpException({ code: 'PROFILE_INACTIVE' }, 403);
                if (error.code === '28000' && error.message === 'AUTH_TOKEN_INVALID')
                    throw new common_1.HttpException({ code: 'AUTH_TOKEN_INVALID' }, 401);
                if (error.code === '55P03' || error.code === '40P01')
                    throw new common_1.HttpException({ code: 'FINANCIAL_RESET_WORK_BUSY' }, 409);
            }
            throw error;
        }
    }
};
exports.FinancialResetService = FinancialResetService;
exports.FinancialResetService = FinancialResetService = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [security_repository_1.SecurityRepository])
], FinancialResetService);
