"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.financialGeneration = void 0;
exports.generationHeader = generationHeader;
const node_async_hooks_1 = require("node:async_hooks");
exports.financialGeneration = new node_async_hooks_1.AsyncLocalStorage();
function generationHeader(value) {
    return value && /^(0|[1-9][0-9]{0,9})$/.test(value) ? value : '';
}
