"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.generateOpenApi = generateOpenApi;
const swagger_1 = require("@nestjs/swagger");
const platform_contract_dto_1 = require("./platform-contract.dto");
const meta_dto_1 = require("../meta/meta.dto");
const schemaNames = [
    'FinancialResetCommand',
    'FinancialResetState',
    'FinancialResetReceipt',
    'LivenessResponse',
    'DependencyChecks',
    'ReadinessSuccess',
    'ReadinessFailure',
    'PlatformMetadata',
    'PlatformCapabilities',
    'SafeMaintenance',
    'FieldError',
    'SafeError',
    'Profile',
    'ProfileUpdate',
    'PrivacySettings',
    'Preferences',
    'PreferencesReplace',
    'OnboardingProgress',
    'OnboardingReplace',
    'Device',
    'DevicePage',
    'DeviceRegistration',
    'DeviceRegistrationResult',
    'DevPushRegistration',
    'DevInstallationSignOut',
];
const operationMethods = new Set(['get', 'put', 'post', 'delete', 'patch', 'options', 'head']);
function comparable(value) {
    if (Array.isArray(value))
        return value.map(comparable);
    if (typeof value !== 'object' || value === null)
        return value;
    return Object.fromEntries(Object.entries(value)
        .filter(([key]) => key !== 'description' && key !== 'summary')
        .sort(([left], [right]) => left.localeCompare(right))
        .map(([key, child]) => [key, comparable(child)]));
}
function sameContract(left, right) {
    return JSON.stringify(comparable(left)) === JSON.stringify(comparable(right));
}
function mergeCompatible(left, right, label) {
    if (left === undefined)
        return structuredClone(right);
    if (right === undefined || sameContract(left, right))
        return left;
    if (typeof left !== 'object' ||
        left === null ||
        typeof right !== 'object' ||
        right === null ||
        Array.isArray(left) ||
        Array.isArray(right)) {
        throw new Error(`OpenAPI contract conflict: ${label}`);
    }
    const merged = structuredClone(left);
    for (const key of Object.keys(right).sort()) {
        if (key === 'description' || key === 'summary')
            continue;
        merged[key] = mergeCompatible(merged[key], Reflect.get(right, key), label);
    }
    return merged;
}
function mergeNamed(target, source, category) {
    for (const name of Object.keys(source).sort()) {
        if (category === 'schemas' && target[name] !== undefined) {
            const current = target[name];
            const approved = source[name];
            const currentProperties = Object.keys(current.properties ?? {}).sort();
            const approvedProperties = Object.keys(approved.properties ?? {}).sort();
            const currentRequired = [...(current.required ?? [])].sort();
            const approvedRequired = [...(approved.required ?? [])].sort();
            if (JSON.stringify(currentProperties) !== JSON.stringify(approvedProperties) ||
                JSON.stringify(currentRequired) !== JSON.stringify(approvedRequired) ||
                current.additionalProperties !== approved.additionalProperties) {
                throw new Error(`OpenAPI contract conflict: ${category} ${name}`);
            }
            target[name] = structuredClone(source[name]);
            continue;
        }
        target[name] = mergeCompatible(target[name], source[name], `${category} ${name}`);
    }
}
function composeFragments(document, fragments) {
    const operationIds = new Set();
    for (const path of Object.values(document.paths)) {
        for (const [method, operation] of Object.entries(path)) {
            if (!operationMethods.has(method) || typeof operation !== 'object' || operation === null)
                continue;
            const operationId = operation.operationId;
            if (typeof operationId === 'string')
                operationIds.add(operationId);
        }
    }
    for (const fragment of fragments) {
        const paths = fragment.paths;
        for (const pathName of Object.keys(paths ?? {}).sort()) {
            const incoming = paths?.[pathName] ?? {};
            const existing = (document.paths[pathName] ??= {});
            for (const key of Object.keys(incoming).sort()) {
                const value = incoming[key];
                if (key in existing) {
                    const current = existing[key];
                    const currentId = typeof current === 'object' && current !== null
                        ? current.operationId
                        : undefined;
                    const incomingId = typeof value === 'object' && value !== null
                        ? value.operationId
                        : undefined;
                    if (!operationMethods.has(key) ||
                        currentId !== incomingId ||
                        typeof incomingId !== 'string') {
                        throw new Error(`OpenAPI path operation conflict: ${pathName} ${key}`);
                    }
                    existing[key] = structuredClone(value);
                    continue;
                }
                if (operationMethods.has(key) && typeof value === 'object' && value !== null) {
                    const operationId = value.operationId;
                    if (typeof operationId === 'string' && operationIds.has(operationId)) {
                        throw new Error(`OpenAPI operationId conflict: ${operationId}`);
                    }
                    if (typeof operationId === 'string')
                        operationIds.add(operationId);
                }
                existing[key] = structuredClone(value);
            }
        }
        const components = fragment.components;
        if (components) {
            document.components ??= {};
            const target = document.components;
            for (const category of Object.keys(components).sort()) {
                const source = components[category];
                if (!source)
                    continue;
                target[category] ??= {};
                mergeNamed(target[category], source, category);
            }
        }
        const tags = fragment.tags;
        for (const tag of tags ?? []) {
            const name = tag.name;
            if (typeof name !== 'string')
                continue;
            const existing = document.tags?.find((candidate) => candidate.name === name);
            if (existing)
                mergeCompatible(existing, tag, `tag ${name}`);
            if (!existing)
                (document.tags ??= []).push(structuredClone(tag));
        }
    }
}
function generateOpenApi(app, approvedFragments = []) {
    const config = new swagger_1.DocumentBuilder()
        .setTitle('Masarifi Backend Foundation API')
        .setVersion('1.0.0')
        .addBearerAuth({ type: 'http', scheme: 'bearer', bearerFormat: 'JWT' }, 'ClerkBearer')
        .build();
    const document = swagger_1.SwaggerModule.createDocument(app, config, {
        extraModels: [
            platform_contract_dto_1.LivenessResponseDto,
            platform_contract_dto_1.DependencyChecksDto,
            platform_contract_dto_1.ReadinessSuccessDto,
            platform_contract_dto_1.ReadinessFailureDto,
            meta_dto_1.MetaResponseDto,
            platform_contract_dto_1.FieldErrorDto,
            platform_contract_dto_1.SafeErrorDto,
        ],
    });
    for (const name of schemaNames) {
        const schema = document.components?.schemas?.[name];
        if (schema && typeof schema === 'object' && !('$ref' in schema))
            schema.additionalProperties = false;
    }
    document.openapi = '3.1.0';
    composeFragments(document, approvedFragments);
    return document;
}
