"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.PoolService = void 0;
exports.buildPoolOptions = buildPoolOptions;
const common_1 = require("@nestjs/common");
const pg_1 = require("pg");
const platform_config_service_1 = require("../config/platform-config.service");
const financial_generation_1 = require("../http/financial-generation");
function buildPoolOptions(connectionString, max) {
    if (!Number.isInteger(max) || max < 1 || max > 50) {
        throw new Error('DATABASE_POOL_SIZE_INVALID');
    }
    return {
        connectionString,
        max,
        allowExitOnIdle: true,
        connectionTimeoutMillis: 1_000,
        idleTimeoutMillis: 30_000,
        query_timeout: 2_000,
    };
}
let PoolService = class PoolService {
    pool;
    runtimeRole;
    initializedClients = new WeakSet();
    clientGenerations = new WeakMap();
    constructor(config) {
        this.pool = new pg_1.Pool(buildPoolOptions(config.get('DATABASE_URL'), config.get('MASARIFI_DATABASE_POOL_MAX')));
        const processKind = config.get('MASARIFI_PROCESS_KIND');
        this.runtimeRole =
            processKind === 'api'
                ? 'masarifi_api'
                : processKind === 'worker'
                    ? 'masarifi_worker'
                    : undefined;
    }
    async query(text, values = [], timeoutMs = 2_000) {
        const client = await this.connect();
        const query = client.query(text, [...values]);
        let timer;
        let failed = false;
        try {
            return await Promise.race([
                query,
                new Promise((_, reject) => {
                    timer = setTimeout(() => {
                        failed = true;
                        reject(new Error('DATABASE_QUERY_TIMEOUT'));
                    }, timeoutMs);
                }),
            ]);
        }
        catch (error) {
            failed = true;
            throw error;
        }
        finally {
            if (timer)
                clearTimeout(timer);
            client.release(failed);
        }
    }
    async ping(timeoutMs) {
        await this.query('select 1', [], timeoutMs);
    }
    async withClient(action) {
        const client = await this.connect();
        let failed = false;
        try {
            return await action(client);
        }
        catch (error) {
            failed = true;
            throw error;
        }
        finally {
            client.release(failed);
        }
    }
    async connect() {
        const client = await this.pool.connect();
        try {
            const generation = financial_generation_1.financialGeneration.getStore() ?? '';
            if ((this.clientGenerations.get(client) ?? '') !== generation) {
                await client.query("select set_config('masarifi.financial_generation',$1,false)", [generation]);
                this.clientGenerations.set(client, generation);
            }
            if (this.initializedClients.has(client))
                return client;
            const deadline = "select set_config('statement_timeout', least(nullif((select setting::integer from pg_settings where name='statement_timeout'), 0), 2000)::text, false)";
            const initialization = this.runtimeRole
                ? `${deadline}; set role ${this.runtimeRole}`
                : deadline;
            await client.query(initialization);
            this.initializedClients.add(client);
            return client;
        }
        catch (error) {
            client.release(true);
            throw error;
        }
    }
    async onModuleDestroy() {
        await this.pool.end();
    }
};
exports.PoolService = PoolService;
exports.PoolService = PoolService = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [platform_config_service_1.PlatformConfigService])
], PoolService);
