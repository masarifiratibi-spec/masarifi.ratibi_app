"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.bindFinancialClaim = bindFinancialClaim;
exports.withClaimGeneration = withClaimGeneration;
const financial_generation_1 = require("../http/financial-generation");
async function bindFinancialClaim(client, kind, id, token) {
    const row = (await client.query('select private.bind_financial_worker_generation($1,$2::uuid,$3::uuid)::text generation', [kind, id, token])).rows[0];
    if (!row || !/^(0|[1-9][0-9]*)$/u.test(row.generation))
        throw new Error('FINANCIAL_WORKER_GENERATION_UNAVAILABLE');
    return row.generation;
}
function withClaimGeneration(generation, action) {
    return financial_generation_1.financialGeneration.run(generation ?? '', action);
}
