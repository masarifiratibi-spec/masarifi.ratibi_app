"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.LedgerWorker = void 0;
const node_crypto_1 = require("node:crypto");
const common_1 = require("@nestjs/common");
const platform_metrics_1 = require("../platform/observability/platform-metrics");
const ledger_repository_1 = require("./ledger.repository");
let LedgerWorker = class LedgerWorker {
    repository;
    cursor = null;
    active;
    timer;
    stopped = false;
    constructor(repository) {
        this.repository = repository;
    }
    runOnce(options = {}) {
        const batchSize = options.batchSize ?? 100;
        if (!Number.isInteger(batchSize) || batchSize < 1 || batchSize > 500)
            return Promise.reject(new Error('LEDGER_RECONCILIATION_BATCH_INVALID'));
        if (this.active)
            return this.active;
        const running = this.execute(batchSize);
        this.active = running;
        void running
            .finally(() => {
            if (this.active === running)
                this.active = undefined;
        })
            .catch(() => undefined);
        return running;
    }
    start() {
        if (this.stopped || this.timer)
            return;
        void this.runOnce().catch(() => undefined);
        this.timer = setInterval(() => void this.runOnce().catch(() => undefined), 60_000);
        this.timer.unref();
    }
    async stop() {
        this.stopped = true;
        if (this.timer)
            clearInterval(this.timer);
        this.timer = undefined;
        await this.active?.catch(() => undefined);
    }
    async onModuleDestroy() {
        await this.stop();
    }
    async execute(batchSize) {
        const startedAt = performance.now();
        let outcome = 'failure';
        try {
            const observedAt = new Date().toISOString();
            const result = await this.repository.reconcile(this.cursor, batchSize);
            const mismatches = result.rows.filter((row) => !row.matches && row.mismatchKind !== null);
            for (const row of mismatches) {
                await this.repository.recordReconciliationMismatch({
                    accountId: row.accountId,
                    mismatchKind: row.mismatchKind,
                    ledgerVersion: row.ledgerVersion,
                    observedAt,
                    requestId: (0, node_crypto_1.randomUUID)(),
                });
                (0, platform_metrics_1.recordPlatformMetric)(platform_metrics_1.LEDGER_METRICS.reconciliationMismatch, 1, {
                    mismatch_kind: row.mismatchKind,
                });
            }
            (0, platform_metrics_1.recordPlatformMetric)(platform_metrics_1.LEDGER_METRICS.reconciliationChecked, result.rows.length, {});
            (0, platform_metrics_1.recordPlatformMetric)(platform_metrics_1.LEDGER_METRICS.reconciliationBatchSize, result.rows.length, {});
            (0, platform_metrics_1.recordPlatformMetric)(platform_metrics_1.LEDGER_METRICS.reconciliationAge, Math.max(0, ...result.rows.map(({ projectionAgeSeconds }) => projectionAgeSeconds)), {});
            this.cursor = result.nextCursor;
            outcome = 'success';
            return result;
        }
        catch (error) {
            (0, platform_metrics_1.recordPlatformMetric)(platform_metrics_1.LEDGER_METRICS.reconciliationFailure, 1, {});
            (0, platform_metrics_1.recordPlatformMetric)(platform_metrics_1.LEDGER_METRICS.reconciliationRetry, 1, { outcome: 'scheduled' });
            throw error;
        }
        finally {
            (0, platform_metrics_1.recordPlatformMetric)(platform_metrics_1.LEDGER_METRICS.reconciliationDuration, performance.now() - startedAt, {
                outcome,
            });
        }
    }
};
exports.LedgerWorker = LedgerWorker;
exports.LedgerWorker = LedgerWorker = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [ledger_repository_1.LedgerRepository])
], LedgerWorker);
