"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.stagingPrivacyScope = stagingPrivacyScope;
exports.bootstrapStagingPrivacyWorker = bootstrapStagingPrivacyWorker;
require("reflect-metadata");
const node_crypto_1 = require("node:crypto");
const node_fs_1 = require("node:fs");
const node_os_1 = require("node:os");
const node_path_1 = require("node:path");
const common_1 = require("@nestjs/common");
const core_1 = require("@nestjs/core");
const platform_config_service_1 = require("./platform/config/platform-config.service");
const environment_schema_1 = require("./platform/config/environment.schema");
const graceful_shutdown_1 = require("./platform/observability/graceful-shutdown");
const platform_logger_1 = require("./platform/observability/platform-logger");
const worker_error_1 = require("./platform/observability/worker-error");
const financial_reset_worker_1 = require("./security/financial-reset.worker");
const security_worker_1 = require("./security/security.worker");
function stagingPrivacyScope(config) {
    if (!config.CLERK_SECRET_KEY?.startsWith('sk_test_'))
        throw new Error('PRIVACY_SCOPED_TEST_CLERK_INSTANCE_REQUIRED');
    const owner = config.MASARIFI_STAGING_PRIVACY_OWNER_ID;
    if (!owner ||
        !/^user_[A-Za-z0-9]+$/.test(owner) ||
        owner.length > 128 ||
        !/^[a-f0-9]{40}$/.test(config.MASARIFI_RELEASE_VERSION) ||
        config.MASARIFI_PROCESS_KIND !== 'worker' ||
        config.SUPABASE_URL !== 'https://qcffvfbpzvpwcwxwjyro.supabase.co')
        throw new Error('PRIVACY_SCOPED_RUNTIME_CONFIGURATION_INVALID');
    return {
        owner,
        source: config.MASARIFI_RELEASE_VERSION,
        ownerHash: (0, node_crypto_1.createHash)('sha256').update(owner).digest('hex'),
    };
}
async function bootstrapStagingPrivacyWorker() {
    const scope = stagingPrivacyScope((0, environment_schema_1.validateEnvironment)(process.env));
    const { PlatformConfigModule } = await Promise.resolve().then(() => __importStar(require('./platform/config/platform-config.module')));
    const { SecurityWorkerModule } = await Promise.resolve().then(() => __importStar(require('./security/security.module')));
    let StagingPrivacyWorkerModule = class StagingPrivacyWorkerModule {
    };
    StagingPrivacyWorkerModule = __decorate([
        (0, common_1.Module)({ imports: [PlatformConfigModule, SecurityWorkerModule] })
    ], StagingPrivacyWorkerModule);
    const app = await core_1.NestFactory.createApplicationContext(StagingPrivacyWorkerModule, {
        abortOnError: false,
        bufferLogs: true,
    });
    const config = app.get(platform_config_service_1.PlatformConfigService);
    const worker = app.get(security_worker_1.SecurityWorkerService);
    const resetWorker = app.get(financial_reset_worker_1.FinancialResetWorker);
    const logger = new platform_logger_1.PlatformLogger(undefined, config.get('MASARIFI_LOG_LEVEL'));
    app.useLogger(logger);
    const pulsePath = (0, node_path_1.join)((0, node_os_1.tmpdir)(), 'staging-privacy-health.json');
    let stopping = false;
    let inFlight;
    const pulse = (state) => {
        (0, node_fs_1.writeFileSync)(`${pulsePath}.next`, JSON.stringify({
            source: scope.source,
            ownerHash: scope.ownerHash,
            checkedAt: new Date().toISOString(),
            state,
        }), { mode: 0o600 });
        (0, node_fs_1.renameSync)(`${pulsePath}.next`, pulsePath);
    };
    const tick = () => {
        if (stopping || inFlight)
            return;
        inFlight = worker
            .runDeletionForOwner(scope.owner)
            .then(() => resetWorker.run(scope.owner))
            .then(() => {
            pulse('checked');
        })
            .catch((error) => {
            pulse('unavailable');
            logger.error('PRIVACY_SCOPED_CHECK_FAILED', (0, worker_error_1.workerErrorFields)(error));
        })
            .finally(() => {
            inFlight = undefined;
        });
    };
    const timer = setInterval(tick, config.getRequired('MASARIFI_SECURITY_WORKER_POLL_MS'));
    const stop = async () => {
        if (stopping)
            return;
        stopping = true;
        clearInterval(timer);
        const deadlineMs = config.get('MASARIFI_SHUTDOWN_TIMEOUT_MS');
        const hardStop = setTimeout(() => process.exit(1), deadlineMs);
        hardStop.unref();
        try {
            const shutdown = await new graceful_shutdown_1.GracefulShutdown(deadlineMs).shutdown(() => inFlight);
            if (shutdown.timedOut)
                process.exit(1);
            await app.close();
        }
        finally {
            clearTimeout(hardStop);
        }
    };
    process.once('SIGTERM', () => {
        void stop();
    });
    process.once('SIGINT', () => {
        void stop();
    });
    tick();
    logger.info('platform.started', {
        context: 'StagingPrivacyWorker',
        processKind: 'worker',
        version: scope.source,
    });
    return app;
}
if (require.main === module) {
    void bootstrapStagingPrivacyWorker().catch((error) => {
        new platform_logger_1.PlatformLogger((line) => process.stderr.write(line + '\n')).error('PRIVACY_SCOPED_BOOTSTRAP_FAILED', (0, worker_error_1.workerErrorFields)(error));
        process.exitCode = 1;
    });
}
