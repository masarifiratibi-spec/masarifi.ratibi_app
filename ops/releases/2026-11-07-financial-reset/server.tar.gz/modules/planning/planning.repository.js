"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.PlanningRepository = void 0;
const financial_worker_generation_1 = require("../platform/database/financial-worker-generation");
const node_crypto_1 = require("node:crypto");
const common_1 = require("@nestjs/common");
const idempotency_1 = require("../ledger/idempotency");
const pool_service_1 = require("../platform/database/pool.service");
const platform_config_service_1 = require("../platform/config/platform-config.service");
const staging_planning_scope_1 = require("./staging-planning-scope");
const planning_dto_1 = require("./planning.dto");
function stableUuid(seed) {
    const value = (0, node_crypto_1.createHash)('sha256').update(seed).digest('hex').slice(0, 32).split('');
    value[12] = '4';
    value[16] = ((Number.parseInt(value[16] ?? '0', 16) & 3) | 8).toString(16);
    const hex = value.join('');
    return `${hex.slice(0, 8)}-${hex.slice(8, 12)}-${hex.slice(12, 16)}-${hex.slice(16, 20)}-${hex.slice(20)}`;
}
function domainError(code, status, currentVersion) {
    return new common_1.HttpException({ code, ...(currentVersion === undefined ? {} : { currentVersion }) }, status);
}
function mapError(error) {
    if (error instanceof common_1.HttpException)
        return error;
    const pg = error;
    const messageCode = pg.message?.match(/[A-Z][A-Z0-9_]{2,63}/)?.[0] ?? '';
    if (messageCode === 'VERSION_CONFLICT') {
        const version = Number(pg.detail);
        return domainError('PLANNING_VERSION_CONFLICT', 409, Number.isSafeInteger(version) ? version : undefined);
    }
    if (messageCode.startsWith('IDEMPOTENCY_'))
        return domainError(messageCode, 409);
    if (messageCode.endsWith('_NOT_FOUND'))
        return domainError('PLANNING_NOT_FOUND', 404);
    if (/(?:REFERENCE|ACCOUNT|TRANSACTION)_INVALID$/.test(messageCode))
        return domainError('PLANNING_LEDGER_STATE_INVALID', 409);
    if (messageCode.endsWith('_USED'))
        return domainError('PLANNING_TRANSACTION_DUPLICATE', 409);
    if (/ALLOCATION|SCHEDULE_INVALID|CATEGORY_INVALID|COPY_INVALID/.test(messageCode))
        return domainError('PLANNING_ALLOCATION_INVALID', 409);
    if (messageCode === 'PLANNING_PROGRESS_INSUFFICIENT')
        return domainError(messageCode, 409);
    if (messageCode === 'SAVINGS_TARGET_DECISION_REQUIRED')
        return domainError('PLANNING_REVIEW_REQUIRED', 409);
    if (/INELIGIBLE|TRANSITION_INVALID|TERMINAL|SCHEDULE_LOCKED|REPLACEMENT_INVALID/.test(messageCode))
        return domainError('PLANNING_LIFECYCLE_INVALID', 409);
    if (messageCode.endsWith('_REQUEST_INVALID') || messageCode === 'PLANNING_HORIZON_INVALID')
        return domainError('VALIDATION_FAILED', 400);
    if (['22023', '22P02', '23502', '23503', '23505', '23514'].includes(pg.code ?? ''))
        return domainError('VALIDATION_FAILED', 400);
    if (pg.code === '28000')
        return domainError('AUTH_TOKEN_INVALID', 401);
    if (pg.code === '42501')
        return domainError('PERMISSION_DENIED', 403);
    if (['40001', '40P01', '55P03', '57014'].includes(pg.code ?? ''))
        return domainError('PLANNING_RATE_LIMITED', 409);
    return domainError('INTERNAL_ERROR', 503);
}
function databaseOperation(operation) {
    const match = [
        ['create', 'create'],
        ['update', 'update'],
        ['archive', 'archive'],
        ['delete', 'delete'],
        ['link', 'link'],
        ['unlink', 'unlink'],
        ['replace', 'replace'],
        ['allocate', 'record'],
        ['reverse', 'reverse'],
        ['decide', 'decide'],
        ['record', 'record'],
    ].find(([prefix]) => operation.startsWith(prefix));
    if (!match)
        throw new Error('PLANNING_OPERATION_UNSUPPORTED');
    return match[1];
}
function planningCommandSql(operation) {
    if (operation.includes('SalaryProfile'))
        return 'select private.save_salary_profile($1,$2::jsonb) result';
    if (operation.includes('SalaryReceipt'))
        return 'select private.link_salary_receipt($1,$2::jsonb) result';
    if (operation.includes('Obligation'))
        return 'select private.save_obligation($1,$2::jsonb) result';
    if (operation.includes('SavingsGoal'))
        return 'select private.save_savings_goal($1,$2::jsonb) result';
    return 'select private.save_budget($1,$2::jsonb) result';
}
let PlanningRepository = class PlanningRepository {
    pool;
    config;
    constructor(pool, config) {
        this.pool = pool;
        this.config = config;
    }
    async mutate(input) {
        try {
            return await this.withApiTransaction(input.principal, (client) => this.mutateWithClient(client, input));
        }
        catch (error) {
            throw mapError(error);
        }
    }
    async mutateWithClient(client, input) {
        const keyHash = (0, idempotency_1.hashIdempotencyKey)(input.idempotencyKey);
        const requestHash = (0, idempotency_1.hashNormalizedCommand)(input.command);
        const claim = await this.claimMutation(client, input, keyHash, requestHash);
        if (claim.outcome === 'replay')
            return claim.response_body;
        const operationId = stableUuid(`${input.principal.userId}:${input.scope}:${keyHash}:operation`);
        const command = this.buildCommand(input, keyHash, operationId);
        const resource = await this.executeMutation(client, input, command, operationId);
        if (!resource || typeof resource.id !== 'string')
            throw new Error('PLANNING_RESULT_MISSING');
        const response = { operationId, replayed: false, resource };
        await this.completeMutation(client, input, claim, keyHash, requestHash, response, resource.id);
        return response;
    }
    async claimMutation(client, input, keyHash, requestHash) {
        const claim = (await client.query('select * from private.claim_sync_idempotency_key($1,$2,$3,$4,$5::interval)', [input.principal.userId, input.scope, keyHash, requestHash, '2 minutes'])).rows[0];
        if (!claim)
            throw new Error('IDEMPOTENCY_REPLAY_UNAVAILABLE');
        if (claim.outcome === 'hash_mismatch')
            throw new Error('IDEMPOTENCY_KEY_REUSED');
        if (claim.outcome === 'in_progress')
            throw new Error('IDEMPOTENCY_IN_PROGRESS');
        if (claim.outcome === 'replay') {
            if (!claim.response_body || claim.response_status !== input.status)
                throw new Error('IDEMPOTENCY_REPLAY_UNAVAILABLE');
            return claim;
        }
        if (!claim.lease_token)
            throw new Error('IDEMPOTENCY_REPLAY_UNAVAILABLE');
        return claim;
    }
    buildCommand(input, keyHash, operationId) {
        const command = {
            ...input.command,
            operation: databaseOperation(input.operation),
            operationId,
            requestId: input.requestId,
        };
        const resourceFields = {
            createSalaryProfile: 'profileId',
            createBudget: 'budgetId',
            createObligation: 'obligationId',
            allocateObligationPayment: 'paymentId',
            createSavingsGoal: 'goalId',
            recordSavingsMovement: 'movementId',
        };
        const resourceField = resourceFields[input.operation];
        const resourceId = stableUuid(`${input.principal.userId}:${input.scope}:${keyHash}:resource`);
        if (resourceField)
            command[resourceField] = resourceId;
        if (input.operation === 'decidePaymentMatch' && command.decision === 'accepted')
            command.allocation = {
                ...command.allocation,
                paymentId: resourceId,
            };
        return command;
    }
    async executeMutation(client, input, command, operationId) {
        if (input.operation === 'replaceBudgetCategories')
            return this.queryJson(client, 'select private.replace_budget_categories($1,$2::uuid,$3::bigint,$4::jsonb) result', [
                input.principal.userId,
                command.budgetId,
                command.expectedVersion,
                JSON.stringify({
                    allocations: command.allocations,
                    operationId,
                    requestId: input.requestId,
                }),
            ]);
        const devPayment = ['allocateObligationPayment', 'reverseObligationPayment'].includes(input.operation) &&
            (0, staging_planning_scope_1.isStagingPlanningOwner)(this.config, input.principal.userId);
        if (devPayment)
            await client.query("select set_config('masarifi.staging_planning_owner',$1,true)", [
                input.principal.userId,
            ]);
        if (input.operation === 'allocateObligationPayment' && command.transaction)
            return this.queryJson(client, devPayment
                ? 'select private.staging_dev_create_obligation_payment($1,$2::jsonb) result'
                : 'select private.create_obligation_payment($1,$2::jsonb) result', [input.principal.userId, JSON.stringify(command)]);
        if (['allocateObligationPayment', 'reverseObligationPayment'].includes(input.operation))
            return this.queryJson(client, devPayment
                ? 'select private.staging_dev_allocate_obligation_payment($1,$2::jsonb) result'
                : 'select private.allocate_obligation_payment($1,$2::jsonb) result', [input.principal.userId, JSON.stringify(command)]);
        if (input.operation === 'decidePaymentMatch')
            return this.queryJson(client, 'select private.decide_payment_match($1,$2::jsonb) result', [
                input.principal.userId,
                JSON.stringify(command),
            ]);
        if (input.operation === 'recordSavingsMovement')
            return this.queryJson(client, 'select private.record_savings_movement($1,$2::jsonb) result', [
                input.principal.userId,
                JSON.stringify(command),
            ]);
        if (input.operation !== 'reverseSavingsMovement')
            return this.queryJson(client, planningCommandSql(input.operation), [
                input.principal.userId,
                JSON.stringify(command),
            ]);
        const resource = await this.queryJson(client, 'select private.reverse_savings_movement($1,$2::uuid,$3::bigint,$4::uuid) result', [input.principal.userId, command.movementId, command.expectedVersion, operationId]);
        if (resource?.goalId !== command.goalId)
            throw new Error('SAVINGS_GOAL_NOT_FOUND');
        return resource;
    }
    async queryJson(client, sql, values) {
        return (await client.query(sql, values)).rows[0]?.result;
    }
    async completeMutation(client, input, claim, keyHash, requestHash, response, resourceId) {
        await client.query('select private.complete_sync_idempotency_key($1,$2,$3,$4,$5,$6,$7::jsonb,$8)', [
            input.principal.userId,
            input.scope,
            keyHash,
            requestHash,
            claim.lease_token,
            input.status,
            JSON.stringify(response),
            resourceId,
        ]);
    }
    async listSalaryProfiles(principal, query, requestId) {
        const cursor = query.cursor ? (0, planning_dto_1.decodePlanningCursor)(query.cursor) : null;
        const rows = await this.queryOwner(principal, `select * from public.salary_profiles
       where user_id=$1 and ($2::timestamptz is null or (created_at,id)<($2,$3::uuid))
       order by created_at desc,id desc limit $4`, [principal.userId, cursor?.at ?? null, cursor?.id ?? null, query.limit + 1]);
        const items = rows.slice(0, query.limit).map((row) => this.salaryProfile(row));
        const last = rows.length > query.limit ? rows[query.limit - 1] : undefined;
        return {
            items,
            nextCursor: last
                ? (0, planning_dto_1.encodePlanningCursor)({ at: last.created_at.toISOString(), id: last.id })
                : null,
            requestId,
        };
    }
    async getSalaryProfile(principal, profileId, requestId) {
        const row = (await this.queryOwner(principal, 'select * from public.salary_profiles where id=$1 and user_id=$2', [profileId, principal.userId]))[0];
        if (!row)
            throw domainError('NOT_FOUND', 404);
        return { ...this.salaryProfile(row), requestId };
    }
    async listSalaryReceipts(principal, profileId, query, requestId) {
        const cursor = query.cursor ? (0, planning_dto_1.decodePlanningCursor)(query.cursor) : null;
        const rows = await this.queryOwner(principal, `select * from public.salary_receipts where user_id=$1 and salary_profile_id=$2
       and ($3::uuid is null or transaction_id=$3)
       and ($4::timestamptz is null or (created_at,id)<($4,$5::uuid))
       order by created_at desc,id desc limit $6`, [
            principal.userId,
            profileId,
            query.transactionId,
            cursor?.at ?? null,
            cursor?.id ?? null,
            query.limit + 1,
        ]);
        const items = rows.slice(0, query.limit).map((row) => this.salaryReceipt(row));
        const last = rows.length > query.limit ? rows[query.limit - 1] : undefined;
        return {
            items,
            nextCursor: last
                ? (0, planning_dto_1.encodePlanningCursor)({ at: last.created_at.toISOString(), id: last.id })
                : null,
            requestId,
        };
    }
    async listBudgets(principal, query, requestId) {
        const cursor = query.cursor ? (0, planning_dto_1.decodePlanningCursor)(query.cursor) : null;
        const rows = await this.queryOwner(principal, `select * from public.budgets where user_id=$1
       and ($2::date is null or (period_start<=$3::date and period_end>=$2::date))
       and ($4::timestamptz is null or (created_at,id)<($4,$5::uuid))
       order by created_at desc,id desc limit $6`, [
            principal.userId,
            query.period?.start ?? null,
            query.period?.end ?? null,
            cursor?.at ?? null,
            cursor?.id ?? null,
            query.limit + 1,
        ]);
        const items = rows.slice(0, query.limit).map((row) => this.budget(row));
        const last = rows.length > query.limit ? rows[query.limit - 1] : undefined;
        return {
            items,
            nextCursor: last
                ? (0, planning_dto_1.encodePlanningCursor)({ at: last.created_at.toISOString(), id: last.id })
                : null,
            requestId,
        };
    }
    async getBudget(principal, budgetId, requestId) {
        const rows = await this.queryOwner(principal, 'select * from public.budgets where id=$1 and user_id=$2', [budgetId, principal.userId]);
        const row = rows[0];
        if (!row)
            throw domainError('NOT_FOUND', 404);
        const categories = await this.queryOwner(principal, 'select * from public.budget_categories where budget_id=$1 and user_id=$2 order by category_id,id', [budgetId, principal.userId]);
        return {
            ...this.budget(row),
            categories: categories.map((category) => this.budgetCategory(category)),
            requestId,
        };
    }
    async getBudgetSummary(principal, budgetId, requestId) {
        const budgetRows = await this.queryOwner(principal, 'select * from public.budgets where id=$1 and user_id=$2', [budgetId, principal.userId]);
        const budget = budgetRows[0];
        if (!budget)
            throw domainError('NOT_FOUND', 404);
        const rows = await this.queryOwner(principal, 'select * from public.v_budget_utilization where budget_id=$1 and user_id=$2 order by category_id,budget_category_id', [budgetId, principal.userId]);
        const spent = rows.reduce((total, row) => total + BigInt(row.spent_minor), 0n);
        const partial = rows.some((row) => row.data_state === 'partial');
        return {
            budgetId,
            currencyCode: budget.currency_code.trim(),
            periodStart: budget.period_start,
            periodEnd: budget.period_end,
            totalMinor: budget.total_minor,
            spentMinor: spent.toString(),
            remainingMinor: (BigInt(budget.total_minor) - spent).toString(),
            dataState: partial ? 'partial' : 'complete',
            unavailableReason: partial ? 'missing_rate' : null,
            ledgerVersion: Math.max(0, ...rows.map((row) => Number(row.ledger_version))),
            items: rows.map((row) => ({
                budgetCategoryId: row.budget_category_id,
                categoryId: row.category_id,
                limitMinor: row.limit_minor,
                spentMinor: row.spent_minor,
                remainingMinor: row.remaining_minor,
                utilizationBps: row.utilization_bps,
                dataState: row.data_state,
                unavailableReason: row.unavailable_reason,
            })),
            requestId,
        };
    }
    async listObligations(principal, query, requestId) {
        const cursor = query.cursor ? (0, planning_dto_1.decodePlanningCursor)(query.cursor) : null;
        const rows = await this.queryOwner(principal, `select * from public.obligations where user_id=$1 and ($2::text is null or status=$2)
       and ($3::timestamptz is null or (created_at,id)<($3,$4::uuid))
       order by created_at desc,id desc limit $5`, [principal.userId, query.status, cursor?.at ?? null, cursor?.id ?? null, query.limit + 1]);
        const items = rows.slice(0, query.limit).map((row) => this.obligation(row));
        const last = rows.length > query.limit ? rows[query.limit - 1] : undefined;
        return {
            items,
            nextCursor: last
                ? (0, planning_dto_1.encodePlanningCursor)({ at: last.created_at.toISOString(), id: last.id })
                : null,
            requestId,
        };
    }
    async getObligation(principal, obligationId, requestId) {
        const rows = await this.queryOwner(principal, 'select * from public.obligations where id=$1 and user_id=$2', [obligationId, principal.userId]);
        const row = rows[0];
        if (!row)
            throw domainError('NOT_FOUND', 404);
        const summary = (await this.queryOwner(principal, 'select * from public.v_obligation_status where obligation_id=$1 and user_id=$2', [obligationId, principal.userId]))[0];
        return {
            ...this.obligation(row),
            summary: summary ? this.obligationStatus(summary) : null,
            requestId,
        };
    }
    async listObligationSchedule(principal, obligationId, query, requestId) {
        const exists = (await this.queryOwner(principal, 'select id from public.obligations where id=$1 and user_id=$2', [obligationId, principal.userId]))[0];
        if (!exists)
            throw domainError('NOT_FOUND', 404);
        const cursor = query.cursor ? (0, planning_dto_1.decodePlanningCursor)(query.cursor) : null;
        const rows = await this.queryOwner(principal, `select * from public.obligation_schedule_items where obligation_id=$1 and user_id=$2
       and ($3::timestamptz is null or (created_at,id)<($3,$4::uuid))
       order by created_at desc,id desc limit $5`, [obligationId, principal.userId, cursor?.at ?? null, cursor?.id ?? null, query.limit + 1]);
        const items = rows.slice(0, query.limit).map((row) => this.obligationSchedule(row));
        const last = rows.length > query.limit ? rows[query.limit - 1] : undefined;
        return {
            items,
            nextCursor: last
                ? (0, planning_dto_1.encodePlanningCursor)({ at: last.created_at.toISOString(), id: last.id })
                : null,
            requestId,
        };
    }
    async listObligationPayments(principal, obligationId, query, requestId) {
        return this.withApiTransaction(principal, async (client) => {
            const exists = await client.query('select id from public.obligations where id=$1 and user_id=$2', [obligationId, principal.userId]);
            if (!exists.rows.length)
                throw domainError('NOT_FOUND', 404);
            const cursor = query.cursor ? (0, planning_dto_1.decodePlanningCursor)(query.cursor) : null;
            const rows = (await client.query(`select p.id,p.paid_at,jsonb_build_object(
          'id',p.id,'obligationId',p.obligation_id,'transactionId',p.transaction_id,
          'amountMinor',p.amount_minor::text,'currencyCode',btrim(o.currency_code),
          'paidAt',p.paid_at,'paymentMethod',p.payment_method,'paymentCase',p.payment_case,
          'allocationIntent',p.allocation_intent,'source',p.source,'status',p.status,
          'operationId',p.operation_id,'replacesPaymentId',p.replaces_payment_id,
          'transactionOwnership',p.transaction_ownership,
          'principalReductionMinor',p.principal_reduction_minor::text,
          'settlementAdjustmentMinor',p.settlement_adjustment_minor::text,
          'version',p.version,'createdAt',p.created_at,'updatedAt',p.updated_at,
          'allocations',coalesce((select jsonb_agg(jsonb_build_object(
            'scheduleItemId',a.schedule_item_id,'amountMinor',a.amount_minor::text)
            order by a.schedule_item_id) from public.obligation_payment_allocations a
            where a.payment_id=p.id and a.user_id=p.user_id),'[]'::jsonb)
        ) result from public.obligation_payments p
        join public.obligations o on o.id=p.obligation_id and o.user_id=p.user_id
        where p.obligation_id=$1 and p.user_id=$2
          and ($3::timestamptz is null or (p.paid_at,p.id)<($3,$4::uuid))
        order by p.paid_at desc,p.id desc limit $5`, [obligationId, principal.userId, cursor?.at ?? null, cursor?.id ?? null, query.limit + 1])).rows;
            const last = rows.length > query.limit ? rows[query.limit - 1] : undefined;
            return {
                items: rows.slice(0, query.limit).map((row) => row.result),
                nextCursor: last
                    ? (0, planning_dto_1.encodePlanningCursor)({ at: last.paid_at.toISOString(), id: last.id })
                    : null,
                requestId,
            };
        });
    }
    async listPaymentMatches(principal, query, requestId) {
        const cursor = query.cursor ? (0, planning_dto_1.decodePlanningCursor)(query.cursor) : null;
        const rows = await this.queryOwner(principal, `select * from public.payment_matches where user_id=$1 and ($2::text is null or status=$2)
       and ($3::timestamptz is null or (created_at,id)<($3,$4::uuid))
       order by created_at desc,id desc limit $5`, [principal.userId, query.status, cursor?.at ?? null, cursor?.id ?? null, query.limit + 1]);
        const items = rows.slice(0, query.limit).map((row) => this.paymentMatch(row));
        const last = rows.length > query.limit ? rows[query.limit - 1] : undefined;
        return {
            items,
            nextCursor: last
                ? (0, planning_dto_1.encodePlanningCursor)({ at: last.created_at.toISOString(), id: last.id })
                : null,
            requestId,
        };
    }
    async getPaymentMatch(principal, matchId, requestId) {
        const row = (await this.queryOwner(principal, `select m.*,
          t.amount_minor transaction_amount_minor,t.currency_code transaction_currency_code,
          t.occurred_at transaction_occurred_at,t.title transaction_title,t.merchant transaction_merchant,
          source_account.id source_account_id,source_account.name source_account_name,
          o.name obligation_name,o.provider obligation_provider,o.type obligation_type,
          o.direction obligation_direction,o.currency_code obligation_currency_code,
          status.remaining_minor obligation_remaining_minor,
          next_item.due_at obligation_next_due_at,
          greatest(next_item.amount_minor-next_item.paid_minor,0)::bigint obligation_next_due_amount_minor,
          o.version obligation_version,next_item.id suggested_schedule_item_id,
          case when t.currency_code=o.currency_code
            then least(t.amount_minor,greatest(next_item.amount_minor-next_item.paid_minor,0))::bigint
            else null end suggested_amount_minor
         from public.payment_matches m
         join public.transactions t on t.id=m.transaction_id and t.user_id=m.user_id
         left join public.obligations o on o.id=m.obligation_id and o.user_id=m.user_id
         left join public.v_obligation_status status on status.obligation_id=o.id
         left join lateral (
           select i.* from public.obligation_schedule_items i
           where i.user_id=m.user_id and i.obligation_id=o.id
             and i.status not in ('paid','cancelled')
           order by i.due_at,i.sequence_no,i.id limit 1
         ) next_item on true
         left join lateral (
           select a.id,a.name from public.transaction_postings p
           join public.accounts a on a.id=p.account_id and a.user_id=m.user_id
           where p.transaction_id=t.id and p.posting_role='source'
           order by p.created_at,p.id limit 1
         ) source_account on true
         where m.id=$1 and m.user_id=$2`, [matchId, principal.userId]))[0];
        if (!row)
            throw domainError('NOT_FOUND', 404);
        const suggestedAllocation = row.suggested_schedule_item_id &&
            row.suggested_amount_minor &&
            BigInt(row.suggested_amount_minor) > 0n
            ? {
                scheduleItemId: row.suggested_schedule_item_id,
                amountMinor: row.suggested_amount_minor,
            }
            : null;
        return {
            ...this.paymentMatch(row),
            transaction: {
                id: row.transaction_id,
                amountMinor: row.transaction_amount_minor,
                currencyCode: row.transaction_currency_code.trim(),
                occurredAt: row.transaction_occurred_at.toISOString(),
                title: row.transaction_title,
                merchant: row.transaction_merchant,
                sourceAccountId: row.source_account_id,
                sourceAccountName: row.source_account_name,
            },
            candidate: row.obligation_id
                ? {
                    id: row.obligation_id,
                    title: row.obligation_name,
                    provider: row.obligation_provider,
                    type: row.obligation_type,
                    direction: row.obligation_direction,
                    currencyCode: row.obligation_currency_code?.trim(),
                    remainingMinor: row.obligation_remaining_minor,
                    nextDueAt: row.obligation_next_due_at?.toISOString() ?? null,
                    nextDueAmountMinor: row.obligation_next_due_amount_minor,
                    obligationVersion: Number(row.obligation_version),
                }
                : null,
            suggestedAllocation,
            requestId,
        };
    }
    async listSavingsGoals(principal, query, requestId) {
        const cursor = query.cursor ? (0, planning_dto_1.decodePlanningCursor)(query.cursor) : null;
        const rows = await this.queryOwner(principal, `select g.*,(g.opening_tracked_minor+coalesce(sum(m.amount_minor),0))::bigint progress_minor
       from public.savings_goals g left join public.savings_goal_movements m on m.goal_id=g.id
       where g.user_id=$1 and ($2::text is null or g.status=$2)
         and ($3::timestamptz is null or (g.created_at,g.id)<($3,$4::uuid))
       group by g.id order by g.created_at desc,g.id desc limit $5`, [principal.userId, query.status, cursor?.at ?? null, cursor?.id ?? null, query.limit + 1]);
        const items = rows.slice(0, query.limit).map((row) => this.savingsGoal(row));
        const last = rows.length > query.limit ? rows[query.limit - 1] : undefined;
        return {
            items,
            nextCursor: last
                ? (0, planning_dto_1.encodePlanningCursor)({ at: last.created_at.toISOString(), id: last.id })
                : null,
            requestId,
        };
    }
    async getSavingsGoal(principal, goalId, requestId) {
        const row = (await this.queryOwner(principal, `select g.*,(g.opening_tracked_minor+coalesce(sum(m.amount_minor),0))::bigint progress_minor
       from public.savings_goals g left join public.savings_goal_movements m on m.goal_id=g.id
       where g.id=$1 and g.user_id=$2 group by g.id`, [goalId, principal.userId]))[0];
        if (!row)
            throw domainError('NOT_FOUND', 404);
        const movements = await this.queryOwner(principal, 'select * from public.savings_goal_movements where goal_id=$1 and user_id=$2 order by occurred_at desc,id desc limit 100', [goalId, principal.userId]);
        return {
            ...this.savingsGoal(row),
            movements: movements.map((movement) => this.savingsMovement(movement)),
            requestId,
        };
    }
    async getPlanningSummary(principal, period, requestId) {
        return this.withApiTransaction(principal, async (client) => {
            const salary = (await client.query(`select p.id,p.name,p.currency_code,p.amount_minor expected_minor,
          anchor.id start_receipt_id,anchor.received_at start_at,projection.expected_at next_expected_at,
          coalesce(totals.income_minor,0)::bigint actual_income_minor,
          coalesce(totals.expense_minor,0)::bigint actual_expense_minor,
          coalesce((select sum(greatest(i.amount_minor-i.paid_minor,0)) from public.obligation_schedule_items i
            join public.obligations o on o.id=i.obligation_id where i.user_id=p.user_id
            and o.currency_code=p.currency_code and o.direction='payable' and o.status='active'
            and i.status in ('due','partial','overdue') and i.due_at>=anchor.received_at
            and i.due_at<greatest(projection.expected_at,scope.through_at)),0)::bigint reserved_obligation_minor
         from public.salary_profiles p join public.profiles u on u.id=p.user_id
         cross join lateral (select ($2::date+1)::timestamp at time zone u.timezone through_at) scope
         left join lateral (
           select r.id,r.received_at,r.expected_at from public.salary_receipts r
           join public.transactions income on income.id=r.transaction_id and income.user_id=r.user_id
             and income.kind='income' and income.status='confirmed' and income.deleted_at is null
           where r.salary_profile_id=p.id and r.user_id=p.user_id and r.status in ('received','corrected')
             and r.received_at<scope.through_at and income.currency_code=p.currency_code
           order by r.received_at desc,r.created_at desc,r.id desc limit 1
         ) anchor on true
         left join lateral (
           select coalesce((select min(r.expected_at) from public.salary_receipts r
             where r.salary_profile_id=p.id and r.user_id=p.user_id and r.status in ('expected','missed')
             and r.expected_at>coalesce(anchor.expected_at,'-infinity'::timestamptz)),
             case when p.frequency='monthly' then (
               date_trunc('month',coalesce(anchor.expected_at at time zone u.timezone,$2::date::timestamp))
               + case when anchor.id is null then interval '0 months' else interval '1 month' end
               + (least(p.expected_day,extract(day from date_trunc('month',
                 coalesce(anchor.expected_at at time zone u.timezone,$2::date::timestamp))
                 + case when anchor.id is null then interval '1 month - 1 day' else interval '2 months - 1 day' end)::integer)-1)*interval '1 day'
             ) at time zone u.timezone else null end) expected_at
         ) projection on true
         left join lateral (
           select sum(t.amount_minor) filter(where t.kind='income') income_minor,
             sum(case when t.kind='expense' then t.amount_minor when t.kind='refund' then -t.amount_minor else 0 end) expense_minor
           from public.transactions t where t.user_id=p.user_id and t.currency_code=p.currency_code
             and t.status='confirmed' and t.deleted_at is null and t.kind in ('income','expense','refund')
             and t.occurred_at>=anchor.received_at and t.occurred_at<scope.through_at
         ) totals on true
         where p.user_id=$1 and p.status='active' order by p.updated_at desc,p.id limit 1`, [principal.userId, period.asOf ?? period.end])).rows[0] ?? null;
            const budgets = (await client.query(`select b.id,b.name,b.currency_code,b.total_minor,coalesce(sum(u.spent_minor),0)::bigint spent_minor,
          (b.total_minor-coalesce(sum(u.spent_minor),0))::bigint remaining_minor,
          coalesce(max(u.ledger_version),0)::bigint ledger_version,
          case when bool_or(u.data_state='partial') then 'partial' else 'complete' end data_state
         from public.budgets b left join public.v_budget_utilization u on u.budget_id=b.id
         where b.user_id=$1 and b.status<>'deleted' and b.period_end>=$2::date and b.period_start<=$3::date
         group by b.id order by b.period_start desc,b.id limit 101`, [principal.userId, period.start, period.end])).rows;
            const budgetCategories = budgets.length
                ? (await client.query(`select * from (
               select c.*,row_number() over(partition by c.budget_id order by c.category_id,c.id) row_number
               from public.budget_categories c
               where c.user_id=$1 and c.status<>'deleted' and c.budget_id=any($2::uuid[])
             ) ranked where row_number<=101 order by budget_id,category_id,id`, [principal.userId, budgets.slice(0, 100).map(({ id }) => id)])).rows
                : [];
            const obligations = (await client.query(`select o.id,o.name,s.direction,s.currency_code,s.scheduled_minor,s.allocated_minor,s.paid_minor,
          s.remaining_minor,s.overdue_minor,s.next_due_at,
          greatest(next_item.amount_minor-next_item.paid_minor,0)::bigint next_due_amount_minor,
          s.completed_installment_count,s.status,s.ledger_version
         from public.obligations o join public.v_obligation_status s on s.obligation_id=o.id
         left join lateral (
           select i.amount_minor,i.paid_minor from public.obligation_schedule_items i
           where i.user_id=o.user_id and i.obligation_id=o.id and i.status not in ('paid','cancelled')
           order by i.due_at,i.sequence_no,i.id limit 1
         ) next_item on true
         where o.user_id=$1 and o.status='active'
         order by s.next_due_at nulls last,o.id limit 101`, [principal.userId])).rows;
            const savings = (await client.query(`select g.*,(g.opening_tracked_minor+coalesce(sum(m.amount_minor),0))::bigint progress_minor
         from public.savings_goals g left join public.savings_goal_movements m on m.goal_id=g.id
         where g.user_id=$1 and g.status<>'deleted' group by g.id order by g.target_date nulls last,g.id limit 101`, [principal.userId])).rows;
            const ledgerVersion = Number((await client.query(`select coalesce(max(ab.ledger_version),0)::bigint version from public.account_balances ab
         join public.accounts a on a.id=ab.account_id where a.user_id=$1`, [principal.userId])).rows[0]?.version ?? 0);
            const partial = budgets.some((budget) => budget.data_state === 'partial') ||
                budgets.length > 100 ||
                budgetCategories.some(({ row_number: rowNumber }) => Number(rowNumber) > 100) ||
                obligations.length > 100 ||
                savings.length > 100;
            const empty = !salary && budgets.length === 0 && obligations.length === 0 && savings.length === 0;
            const obligation = (row) => ({
                id: row.id,
                name: row.name,
                ...this.obligationStatus(row),
            });
            return {
                period: period.key,
                dataState: partial ? 'partial' : empty ? 'empty' : 'ready',
                ledgerVersion,
                salary: salary
                    ? {
                        id: salary.id,
                        name: salary.name,
                        currencyCode: salary.currency_code.trim(),
                        expectedMinor: salary.expected_minor,
                        actualIncomeMinor: salary.actual_income_minor,
                        actualExpenseMinor: salary.actual_expense_minor,
                        reservedObligationMinor: salary.reserved_obligation_minor,
                        nextExpectedAt: salary.next_expected_at?.toISOString() ?? null,
                        startReceiptId: salary.start_receipt_id ?? null,
                        startAt: salary.start_at?.toISOString() ?? null,
                    }
                    : null,
                budgets: budgets.slice(0, 100).map((budget) => ({
                    id: budget.id,
                    name: budget.name,
                    currencyCode: budget.currency_code.trim(),
                    totalMinor: budget.total_minor,
                    spentMinor: budget.spent_minor,
                    remainingMinor: budget.remaining_minor,
                    ledgerVersion: Number(budget.ledger_version),
                    dataState: budget.data_state,
                    categories: budgetCategories
                        .filter((category) => category.budget_id === budget.id && Number(category.row_number) <= 100)
                        .map((category) => ({
                        budgetId: budget.id,
                        ...this.budgetCategory(category),
                    })),
                })),
                obligations: {
                    payables: obligations
                        .slice(0, 100)
                        .filter((row) => row.direction === 'payable')
                        .map(obligation),
                    receivables: obligations
                        .slice(0, 100)
                        .filter((row) => row.direction === 'receivable')
                        .map(obligation),
                },
                savings: savings.slice(0, 100).map((goal) => this.savingsGoal(goal)),
                requestId,
            };
        });
    }
    async getAdminPlanningSummary(principal, userId, period, requestId) {
        const result = await this.withApiTransaction(principal, async (client) => (await client.query('select private.read_admin_planning_summary($1,$2,$3::date,$4::date) result', [principal.userId, userId, period.start, period.end])).rows[0]?.result);
        if (!result)
            throw domainError('NOT_FOUND', 404);
        return { ...result, period: period.key, requestId };
    }
    async claimPlanning(job, limit = 100, leaseSeconds = 60) {
        const functionName = {
            'planning.salary-cycle.generate': 'claim_planning_salary_cycles',
            'planning.obligation-schedule.generate': 'claim_planning_obligation_schedules',
            'planning.payment-match.propose': 'claim_planning_match_candidates',
            'planning.overdue.mark': 'claim_planning_overdue',
            'planning.reminders.emit': 'claim_planning_reminders',
        }[job];
        return this.withWorkerTransaction(async (client) => (await client.query(`select id,resource_id,attempt_count,lease_token from private.${functionName}($1::uuid,$2,$3)`, [null, limit, leaseSeconds])).rows.map((row) => ({
            id: row.id,
            resourceId: row.resource_id,
            attemptCount: row.attempt_count,
            leaseToken: row.lease_token,
        })));
    }
    async executePlanningClaim(job, claim) {
        await this.withWorkerTransaction(async (client) => {
            await (0, financial_worker_generation_1.bindFinancialClaim)(client, 'planning', claim.id, claim.leaseToken);
            const result = (await client.query('select private.execute_planning_claim($1::uuid,$2::uuid,$3,$4::uuid) result', [claim.id, claim.leaseToken, job, claim.resourceId])).rows[0]?.result;
            if (!result)
                throw new Error('PLANNING_RESULT_MISSING');
            await client.query('select private.complete_planning_claim($1::uuid,$2::uuid,$3,$4::jsonb)', [
                claim.id,
                claim.leaseToken,
                'completed',
                JSON.stringify(result),
            ]);
        });
    }
    completePlanningClaim(claimId, leaseToken, outcome, result) {
        return this.withWorkerTransaction(async (client) => {
            await client.query('select private.complete_planning_claim($1::uuid,$2::uuid,$3,$4::jsonb)', [
                claimId,
                leaseToken,
                outcome,
                JSON.stringify(result),
            ]);
        });
    }
    reconcilePlanning(repair, limit = 100) {
        return this.withWorkerTransaction(async (client) => (await client.query('select * from private.reconcile_planning($1::uuid,$2,$3)', [null, repair, limit])).rows);
    }
    withApiTransaction(principal, action) {
        return this.transaction('masarifi_api', principal, action);
    }
    withWorkerTransaction(action) {
        return this.transaction('masarifi_worker', null, action);
    }
    async queryOwner(principal, sql, values = []) {
        return this.withApiTransaction(principal, async (client) => (await client.query(sql, [...values])).rows);
    }
    async transaction(role, principal, action) {
        return this.pool.withClient(async (client) => {
            await client.query('begin');
            try {
                if (principal)
                    await client.query("select set_config('request.jwt.claims',$1,true)", [
                        JSON.stringify({
                            role: 'authenticated',
                            sub: principal.userId,
                            sid: principal.sessionId,
                        }),
                    ]);
                await client.query(role === 'masarifi_api'
                    ? 'set local role masarifi_api'
                    : 'set local role masarifi_worker');
                const result = await action(client);
                await client.query('commit');
                return result;
            }
            catch (error) {
                await client.query('rollback');
                throw error;
            }
        });
    }
    salaryProfile(row) {
        return {
            id: row.id,
            name: row.name,
            amountMinor: row.amount_minor,
            currencyCode: row.currency_code.trim(),
            frequency: row.frequency,
            expectedDay: row.expected_day,
            customIntervalDays: row.custom_interval_days,
            accountId: row.account_id,
            automaticDetectionEnabled: row.automatic_detection_enabled,
            status: row.status,
            deletedAt: row.deleted_at?.toISOString() ?? null,
            createdAt: row.created_at.toISOString(),
            updatedAt: row.updated_at.toISOString(),
            version: Number(row.version),
        };
    }
    salaryReceipt(row) {
        return {
            id: row.id,
            salaryProfileId: row.salary_profile_id,
            transactionId: row.transaction_id,
            expectedAt: row.expected_at.toISOString(),
            receivedAt: row.received_at?.toISOString() ?? null,
            amountMinor: row.amount_minor,
            status: row.status,
            operationId: row.operation_id,
            replacesReceiptId: row.replaces_receipt_id,
            createdAt: row.created_at.toISOString(),
            updatedAt: row.updated_at.toISOString(),
            version: Number(row.version),
        };
    }
    budget(row) {
        return {
            id: row.id,
            name: row.name,
            currencyCode: row.currency_code.trim(),
            periodStart: row.period_start,
            periodEnd: row.period_end,
            totalMinor: row.total_minor,
            incomeTargetMinor: row.income_target_minor,
            savingsTargetMinor: row.savings_target_minor,
            rolloverEnabled: row.rollover_enabled,
            rolloverMinor: row.rollover_minor,
            status: row.status,
            copiedFromBudgetId: row.copied_from_budget_id,
            deletedAt: row.deleted_at?.toISOString() ?? null,
            createdAt: row.created_at.toISOString(),
            updatedAt: row.updated_at.toISOString(),
            version: Number(row.version),
        };
    }
    budgetCategory(row) {
        return {
            id: row.id,
            categoryId: row.category_id,
            limitMinor: row.limit_minor,
            rolloverMinor: row.rollover_minor,
            alertThresholds: row.alert_thresholds,
            status: row.status,
            createdAt: row.created_at.toISOString(),
            updatedAt: row.updated_at.toISOString(),
            version: Number(row.version),
        };
    }
    obligation(row) {
        return {
            id: row.id,
            name: row.name,
            direction: row.direction,
            type: row.type,
            scheduleKind: row.schedule_kind,
            currencyCode: row.currency_code.trim(),
            principalMinor: row.principal_minor,
            openingPaidMinor: row.opening_paid_minor,
            installmentAmountMinor: row.installment_amount_minor,
            installmentCount: row.installment_count,
            frequency: row.frequency,
            expectedDay: row.expected_day,
            customIntervalDays: row.custom_interval_days,
            startDate: row.start_date,
            endDate: row.end_date,
            status: row.status,
            defaultAccountId: row.default_account_id,
            automaticMatchingEnabled: row.automatic_matching_enabled,
            provider: row.provider,
            providerKeywords: row.provider_keywords,
            reminderTiming: row.reminder_timing,
            notes: row.notes,
            deletedAt: row.deleted_at?.toISOString() ?? null,
            createdAt: row.created_at.toISOString(),
            updatedAt: row.updated_at.toISOString(),
            version: Number(row.version),
        };
    }
    obligationSchedule(row) {
        return {
            id: row.id,
            obligationId: row.obligation_id,
            dueAt: row.due_at.toISOString(),
            amountMinor: row.amount_minor,
            paidMinor: row.paid_minor,
            status: row.status,
            sequenceNo: row.sequence_no,
            kind: row.kind,
            createdAt: row.created_at.toISOString(),
            updatedAt: row.updated_at.toISOString(),
            version: Number(row.version),
        };
    }
    obligationStatus(row) {
        return {
            direction: row.direction,
            currencyCode: row.currency_code.trim(),
            scheduledMinor: row.scheduled_minor,
            allocatedMinor: row.allocated_minor,
            paidMinor: row.paid_minor,
            remainingMinor: row.remaining_minor,
            overdueMinor: row.overdue_minor,
            nextDueAt: row.next_due_at?.toISOString() ?? null,
            nextDueAmountMinor: row.next_due_amount_minor ?? null,
            completedInstallmentCount: row.completed_installment_count,
            status: row.status,
            ledgerVersion: Number(row.ledger_version),
        };
    }
    paymentMatch(row) {
        const reasonCodes = [];
        if (row.evidence.amountMatch === true)
            reasonCodes.push('amount_match');
        if (row.evidence.keywordMatch === true)
            reasonCodes.push('keyword_match');
        return {
            id: row.id,
            transactionId: row.transaction_id,
            obligationId: row.obligation_id,
            scheduleItemId: row.schedule_item_id,
            advisoryConfidence: row.confidence,
            reasonCodes,
            status: row.status,
            reviewedAt: row.reviewed_at?.toISOString() ?? null,
            createdAt: row.created_at.toISOString(),
            updatedAt: row.updated_at.toISOString(),
            version: Number(row.version),
        };
    }
    savingsGoal(row) {
        const progress = BigInt(row.progress_minor);
        return {
            id: row.id,
            name: row.name,
            currencyCode: row.currency_code.trim(),
            targetMinor: row.target_minor,
            openingTrackedMinor: row.opening_tracked_minor,
            progressMinor: row.progress_minor,
            remainingMinor: (BigInt(row.target_minor) - progress).toString(),
            progressBps: Number((progress * 10000n) / BigInt(row.target_minor)),
            targetDate: row.target_date,
            status: row.status,
            linkedAccountId: row.linked_account_id,
            iconKey: row.icon_key,
            emergencyFund: row.emergency_fund,
            deletedAt: row.deleted_at?.toISOString() ?? null,
            createdAt: row.created_at.toISOString(),
            updatedAt: row.updated_at.toISOString(),
            version: Number(row.version),
        };
    }
    savingsMovement(row) {
        return {
            id: row.id,
            goalId: row.goal_id,
            transactionId: row.transaction_id,
            amountMinor: row.amount_minor,
            occurredAt: row.occurred_at.toISOString(),
            kind: row.kind,
            operationId: row.operation_id,
            replacesMovementId: row.replaces_movement_id,
            createdAt: row.created_at.toISOString(),
        };
    }
};
exports.PlanningRepository = PlanningRepository;
exports.PlanningRepository = PlanningRepository = __decorate([
    (0, common_1.Injectable)(),
    __param(1, (0, common_1.Optional)()),
    __metadata("design:paramtypes", [pool_service_1.PoolService,
        platform_config_service_1.PlatformConfigService])
], PlanningRepository);
