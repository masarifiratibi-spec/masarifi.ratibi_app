"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.AiWorker = void 0;
exports.evaluatePromptCorpus = evaluatePromptCorpus;
exports.assistantProviderPayload = assistantProviderPayload;
exports.encodeAssistantProviderPayload = encodeAssistantProviderPayload;
const financial_worker_generation_1 = require("../platform/database/financial-worker-generation");
const voice_batch_1 = require("./voice-batch");
const common_1 = require("@nestjs/common");
const node_crypto_1 = require("node:crypto");
const ai_abort_1 = require("./ai.abort");
const platform_config_service_1 = require("../platform/config/platform-config.service");
const platform_logger_1 = require("../platform/observability/platform-logger");
const worker_error_1 = require("../platform/observability/worker-error");
const voice_transient_error_1 = require("./voice-transient-error");
const ai_observability_1 = require("./ai.observability");
const ai_gateway_1 = require("./ai.gateway");
const ai_repository_1 = require("./ai.repository");
const ai_schemas_1 = require("./ai.schemas");
const ai_storage_1 = require("./ai.storage");
function object(value) {
    if (!value || typeof value !== 'object' || Array.isArray(value))
        throw new Error('AI_WORK_INPUT_INVALID');
    return value;
}
const voiceScopeReasons = new Set([
    'decision_count',
    'decision_status',
    'command_validity',
    'kind',
    'amount',
    'currency',
    'account',
    'category',
    'capture_date',
]);
function audioFormat(contentType) {
    return ({
        'audio/m4a': 'm4a',
        'audio/mp4': 'mp4',
        'audio/mpeg': 'mp3',
        'audio/ogg': 'ogg',
        'audio/wav': 'wav',
        'audio/webm': 'webm',
    }[contentType] ?? 'unknown');
}
function validMagic(body, contentType) {
    if (body.length < 12)
        return false;
    if (contentType === 'audio/wav')
        return (body.subarray(0, 4).toString('ascii') === 'RIFF' &&
            body.subarray(8, 12).toString('ascii') === 'WAVE');
    if (contentType === 'audio/ogg')
        return body.subarray(0, 4).toString('ascii') === 'OggS';
    if (contentType === 'audio/mpeg')
        return (body.subarray(0, 3).toString('ascii') === 'ID3' ||
            (body[0] === 0xff && (body[1] ?? 0) >= 0xe0));
    if (contentType === 'audio/webm')
        return body.subarray(0, 4).equals(Buffer.from([0x1a, 0x45, 0xdf, 0xa3]));
    return body.subarray(4, 8).toString('ascii') === 'ftyp';
}
function aliasReferences(value) {
    if (!Array.isArray(value) || value.length > 100)
        throw new Error('AI_WORK_INPUT_INVALID');
    const references = value.map((item) => {
        const row = object(item);
        if (typeof row.alias !== 'string' ||
            typeof row.kind !== 'string' ||
            typeof row.id !== 'string' ||
            typeof row.version !== 'number')
            throw new Error('AI_WORK_INPUT_INVALID');
        return {
            alias: row.alias,
            kind: row.kind,
            id: row.id,
            version: row.version,
            data: row.data && typeof row.data === 'object' && !Array.isArray(row.data)
                ? row.data
                : {},
        };
    });
    if (new Set(references.map(({ alias }) => alias)).size !== references.length)
        throw new Error('AI_WORK_INPUT_INVALID');
    return references;
}
function resolveId(value, kind, references, nullable = false) {
    if (nullable && value === null)
        return null;
    if (typeof value !== 'string')
        throw new Error('AI_SCHEMA_INVALID');
    const match = references.find((item) => item.kind === kind && (item.alias === value || item.id === value));
    if (!match)
        throw new Error('AI_SCHEMA_INVALID');
    return match.id;
}
function resolveVoiceProposal(proposal, references) {
    return {
        ...proposal,
        accountId: resolveId(proposal.accountId, 'account', references),
        categoryId: resolveId(proposal.categoryId, 'category', references, true),
    };
}
function resolveAssistantOutput(output, references) {
    if (!output.actionPreview)
        return output;
    const payload = structuredClone(output.actionPreview.payload);
    const kinds = {
        accountId: 'account',
        linkedAccountId: 'account',
        categoryId: 'category',
        transactionId: 'transaction',
        budgetId: 'budget',
        obligationId: 'obligation',
        scheduleItemId: 'schedule',
        reviewId: 'review',
    };
    const visit = (value) => {
        if (Array.isArray(value)) {
            value.forEach(visit);
            return;
        }
        if (!value || typeof value !== 'object')
            return;
        for (const [key, child] of Object.entries(value)) {
            const kind = kinds[key];
            if (kind)
                value[key] = resolveId(child, kind, references, key === 'categoryId' || key === 'linkedAccountId');
            else
                visit(child);
        }
    };
    visit(payload);
    return (0, ai_schemas_1.parseAssistantOutput)({ ...output, actionPreview: { ...output.actionPreview, payload } });
}
function safetyConfigurations(route, type) {
    return route.safetyRules
        .filter((rule) => rule.type === type)
        .map(({ configuration }) => configuration);
}
function inputLimit(route) {
    return Math.min(8_192, ...safetyConfigurations(route, 'input_block').map(({ maxUtf8Bytes }) => Number(maxUtf8Bytes)));
}
function assertConfiguredOutput(route, value, field) {
    const maximum = Math.min(field === 'answer' ? 16_384 : 8_192, ...safetyConfigurations(route, 'field_limit')
        .filter((rule) => rule.field === field)
        .map(({ maxUtf8Bytes }) => Number(maxUtf8Bytes)));
    const text = field === 'answer' ? value.answer : String(value);
    if (new TextEncoder().encode(text).length > maximum)
        throw new Error('AI_SCHEMA_INVALID');
    const forbidden = new Set(safetyConfigurations(route, 'output_block').flatMap(({ forbiddenKeys }) => Array.isArray(forbiddenKeys) ? forbiddenKeys.map((key) => String(key).toLowerCase()) : []));
    const containsForbidden = (entry) => Array.isArray(entry)
        ? entry.some(containsForbidden)
        : Boolean(entry &&
            typeof entry === 'object' &&
            Object.entries(entry).some(([key, child]) => forbidden.has(key.toLowerCase()) || containsForbidden(child)));
    if (containsForbidden(value))
        throw new Error('AI_SCHEMA_INVALID');
    if (field === 'answer') {
        const output = value;
        const evidenceMaximum = Math.min(...safetyConfigurations(route, 'evidence_limit').map(({ maxItems }) => Number(maxItems)));
        if (output.evidenceIds.length > evidenceMaximum ||
            (output.actionPreview?.evidenceIds.length ?? 0) > evidenceMaximum)
            throw new Error('AI_SCHEMA_INVALID');
        const allowlists = safetyConfigurations(route, 'action_allowlist').map(({ values }) => new Set(Array.isArray(values) ? values.map(String) : []));
        if (output.actionPreview &&
            allowlists.some((allowed) => !allowed.has(output.actionPreview?.actionType ?? '')))
            throw new Error('AI_SCHEMA_INVALID');
    }
}
function normalizedDigits(value) {
    const arabic = '٠١٢٣٤٥٦٧٨٩', eastern = '۰۱۲۳۴۵۶۷۸۹';
    return Array.from(value)
        .map((character) => {
        const arabicIndex = arabic.indexOf(character), easternIndex = eastern.indexOf(character);
        if (arabicIndex >= 0)
            return arabicIndex.toString();
        if (easternIndex >= 0)
            return easternIndex.toString();
        return character === '٫' || character === ',' ? '.' : character;
    })
        .join('');
}
function evaluatePromptCorpus(template, cases) {
    if (cases.length === 0 ||
        template.length > 32_768 ||
        !/\b(?:no|never|do not)\b[\s\S]{0,24}\btools?\b/iu.test(template))
        throw new Error('AI_EVALUATION_FAILED');
    for (const item of cases) {
        const test = object(item), fixture = object(test.fixture), expected = object(test.expected);
        if (Object.keys(expected).some((key) => !['schema', 'noTools', 'blocked', 'amountMinor', 'currency', 'citations'].includes(key)))
            throw new Error('AI_EVALUATION_FAILED');
        if (expected.noTools !== true || (expected.blocked !== true && expected.schema !== true))
            throw new Error('AI_EVALUATION_FAILED');
        const input = typeof fixture.question === 'string'
            ? fixture.question
            : typeof fixture.text === 'string'
                ? fixture.text
                : '';
        if (expected.blocked === true) {
            try {
                (0, ai_schemas_1.assertSafeAiInput)(input);
                throw new Error('AI_EVALUATION_FAILED');
            }
            catch (error) {
                if (error instanceof Error && error.message === 'AI_EVALUATION_FAILED')
                    throw error;
            }
        }
        else if (input)
            (0, ai_schemas_1.assertSafeAiInput)(input);
        if (typeof expected.amountMinor === 'string') {
            const amount = normalizedDigits(input).match(/-?\d+(?:\.\d{1,2})?/u)?.[0];
            if (!amount || Math.round(Number(amount) * 100).toString() !== expected.amountMinor)
                throw new Error('AI_EVALUATION_FAILED');
        }
        if (typeof expected.currency === 'string' &&
            !(expected.currency === 'SAR' && /\bSAR\b|ريال/iu.test(input)))
            throw new Error('AI_EVALUATION_FAILED');
        if (Array.isArray(expected.citations)) {
            const aliases = Array.isArray(fixture.evidence)
                ? fixture.evidence.map((entry) => String(object(entry).alias))
                : [];
            if (expected.citations.some((alias) => typeof alias !== 'string' || !aliases.includes(alias)))
                throw new Error('AI_EVALUATION_FAILED');
        }
    }
}
function assistantProviderPayload(input) {
    const references = aliasReferences(input.aliases).map(({ alias, kind, version, data }) => ({
        alias,
        kind,
        version,
        data: (0, ai_schemas_1.redactAiContext)(data),
    }));
    const history = Array.isArray(input.historyPayload) ? input.historyPayload.slice(-4) : [];
    const context = object(input.contextPayload);
    const metadata = context.assistantMetadata && typeof context.assistantMetadata === 'object'
        ? object(context.assistantMetadata)
        : {};
    return {
        responseLanguage: context.responseLocale ?? metadata.locale ?? 'ar',
        intent: String(input.intent),
        question: (0, ai_schemas_1.redactAiText)((0, ai_schemas_1.assertSafeAiInput)(String(input.content))),
        financialTruth: (0, ai_schemas_1.redactAiContext)(object(input.contextPayload)),
        conversation: history.map((turn) => {
            const value = object(turn);
            return {
                role: value.role === 'assistant' ? 'assistant' : 'user',
                content: (0, ai_schemas_1.redactAiText)((0, ai_schemas_1.assertSafeAiInput)(String(value.content))),
            };
        }),
        references,
    };
}
function encodeAssistantProviderPayload(input, maximumBytes) {
    const encoded = JSON.stringify(assistantProviderPayload(input));
    if (new TextEncoder().encode(encoded).length > maximumBytes)
        throw new Error('AI_CONTEXT_LIMIT');
    return encoded;
}
let AiWorker = class AiWorker {
    repository;
    storage;
    gateway;
    config;
    timer;
    running = false;
    abortController;
    healthObserver;
    constructor(repository, storage, gateway, config) {
        this.repository = repository;
        this.storage = storage;
        this.gateway = gateway;
        this.config = config;
    }
    observeHealth(observer) {
        this.healthObserver = observer;
        this.reportHealth('starting');
    }
    reportHealth(state) {
        try {
            this.healthObserver?.(state);
        }
        catch {
            new platform_logger_1.PlatformLogger().error('AI_WORKER_HEALTH_UNAVAILABLE', { context: 'AiWorker' });
        }
    }
    start() {
        if (this.timer)
            return;
        this.reportHealth('starting');
        this.timer = setInterval(() => {
            void this.runOnce().catch(() => {
                (0, ai_observability_1.recordAiJob)('ai.worker', 'failure');
            });
        }, this.config.getRequired('MASARIFI_AI_WORKER_POLL_MS'));
        if (!this.config.get('MASARIFI_VOICE_ANALYSIS_ONLY') &&
            !this.config.get('MASARIFI_AI_ASSISTANT_ONLY'))
            this.timer.unref();
        void this.runOnce().catch(() => {
            (0, ai_observability_1.recordAiJob)('ai.worker', 'failure');
        });
    }
    async stop() {
        if (this.timer)
            clearInterval(this.timer);
        this.timer = undefined;
        this.abortController?.abort();
        while (this.running)
            await new Promise((resolve) => setTimeout(resolve, 10));
        this.reportHealth('stopped');
    }
    async onModuleDestroy() {
        await this.stop();
    }
    async runOnce() {
        if (this.running)
            return;
        this.running = true;
        this.abortController = new AbortController();
        let stage = 'scope';
        let healthFailed = false;
        try {
            if (this.config.get('MASARIFI_AI_ASSISTANT_ONLY')) {
                if (this.config.get('MASARIFI_VOICE_ANALYSIS_ONLY'))
                    throw new Error('ASSISTANT_SCOPE_INVALID');
                stage = 'assistant.respond';
                await this.runJob('assistant.respond');
                return;
            }
            if (this.config.get('MASARIFI_VOICE_ANALYSIS_ONLY')) {
                stage = 'voice.transcribe_extract';
                await this.runJob('voice.transcribe_extract');
                stage = 'voice-media.purge';
                await this.runJob('voice-media.purge');
                return;
            }
            for (const job of [
                'voice.transcribe_extract',
                'assistant.respond',
                'ai.evaluate_route',
                'voice.finalize',
                'ai.usage_rollup',
                'voice-media.purge',
                'ai.reconcile',
            ]) {
                stage = job;
                await this.runJob(job);
            }
        }
        catch (error) {
            healthFailed = true;
            this.reportHealth('failed');
            new platform_logger_1.PlatformLogger().error('AI_WORKER_RUNTIME_FAILED', {
                context: 'AiWorker',
                failureStage: stage,
                ...(0, worker_error_1.workerErrorFields)(error),
            });
            throw error;
        }
        finally {
            this.abortController = undefined;
            this.running = false;
            if (!healthFailed)
                this.reportHealth('ready');
        }
    }
    async runJob(job) {
        if (this.config.get('MASARIFI_AI_ASSISTANT_ONLY') && job !== 'assistant.respond')
            throw new Error('ASSISTANT_SCOPE_INVALID');
        if (this.config.get('MASARIFI_VOICE_ANALYSIS_ONLY') &&
            !['voice.transcribe_extract', 'voice-media.purge'].includes(job))
            throw new Error('VOICE_ANALYSIS_JOB_FORBIDDEN');
        const limit = this.config.getRequired('MASARIFI_AI_JOB_BATCH_SIZE');
        if (['voice.transcribe_extract', 'assistant.respond', 'ai.evaluate_route'].includes(job))
            return this.config.getRequired('MASARIFI_AI_PROVIDER_ENABLED')
                ? this.processKind(job)
                : 0;
        if (job === 'voice.finalize')
            return this.repository.finalizeVoiceBatches(limit);
        if (job === 'ai.usage_rollup') {
            await this.repository.expire(limit);
            await this.repository.rollup(limit);
            (0, ai_observability_1.recordAiJob)(job, 'success');
            return 1;
        }
        if (job === 'voice-media.purge')
            return this.purge();
        if (job === 'financial-insights.generate')
            return this.repository.refreshInsights(limit);
        await this.repository.reconcile(limit);
        return 1;
    }
    async processKind(kind) {
        if (this.config.get('MASARIFI_AI_ASSISTANT_ONLY') && kind !== 'assistant.respond')
            throw new Error('ASSISTANT_SCOPE_INVALID');
        const concurrency = this.config.getRequired('MASARIFI_AI_MAX_CONCURRENCY');
        const limit = Math.min(concurrency, this.config.getRequired('MASARIFI_AI_JOB_BATCH_SIZE'));
        const lease = this.config.getRequired('MASARIFI_AI_LEASE_SECONDS');
        const claims = this.config.get('MASARIFI_VOICE_ANALYSIS_ONLY')
            ? kind === 'voice.transcribe_extract'
                ? await this.repository.claimAnalysisWork(this.workerId(), limit, lease)
                : []
            : await this.repository.claimWork(kind, this.workerId(), limit, lease);
        if (this.config.get('MASARIFI_AI_ASSISTANT_ONLY') &&
            claims.some((claim) => claim.kind !== 'assistant.respond'))
            throw new Error('ASSISTANT_SCOPE_INVALID');
        for (let offset = 0; offset < claims.length; offset += concurrency)
            await Promise.all(claims
                .slice(offset, offset + concurrency)
                .map((claim) => (0, financial_worker_generation_1.withClaimGeneration)(claim.generation, () => this.process(claim))));
        return claims.length;
    }
    async processVoiceClaim(claim, signal, continuous = false) {
        if (claim.kind !== 'voice.transcribe_extract')
            throw new Error('VOICE_SCOPE_INVALID');
        return (0, financial_worker_generation_1.withClaimGeneration)(claim.generation, () => this.process(claim, signal, continuous));
    }
    async process(claim, externalSignal, continuous = false) {
        const startedAt = performance.now();
        const controller = new AbortController();
        const signal = AbortSignal.any([
            controller.signal,
            ...(this.abortController ? [this.abortController.signal] : []),
            ...(externalSignal ? [externalSignal] : []),
        ]);
        let renewal;
        let deadline;
        let renewing = false;
        let renewalFailure;
        let outcome = 'failure';
        try {
            if (claim.kind === 'voice.transcribe_extract') {
                const lease = this.config.getRequired('MASARIFI_AI_LEASE_SECONDS');
                if (!(await this.repository.renewVoiceWork(claim.id, claim.claim_token, lease)))
                    throw new Error('AI_WORK_FENCE_INVALID');
                renewal = setInterval(() => {
                    if (renewing)
                        return;
                    renewing = true;
                    void this.repository
                        .renewVoiceWork(claim.id, claim.claim_token, lease)
                        .then((valid) => {
                        if (!valid)
                            controller.abort();
                    })
                        .catch((error) => {
                        renewalFailure = error;
                        controller.abort();
                    })
                        .finally(() => {
                        renewing = false;
                    });
                }, Math.floor((lease * 1_000) / 3));
                deadline = setTimeout(() => {
                    controller.abort();
                }, 180_000);
                await (0, ai_abort_1.withAiAbort)(signal, () => this.voice(claim, signal, continuous));
            }
            else if (claim.kind === 'assistant.respond') {
                const leaseMs = this.config.getRequired('MASARIFI_AI_LEASE_SECONDS') * 1000;
                deadline = setTimeout(() => {
                    controller.abort();
                }, Math.max(1, leaseMs - Math.min(1000, leaseMs / 3)));
                await (0, ai_abort_1.withAiAbort)(signal, () => this.assistant(claim, signal));
            }
            else
                await this.evaluate(claim);
            (0, ai_observability_1.recordAiJob)(claim.kind, 'success');
            outcome = 'success';
            return true;
        }
        catch (error) {
            if (continuous && (externalSignal?.aborted || (0, voice_transient_error_1.isTransientVoiceError)(renewalFailure)))
                throw renewalFailure ?? error;
            if (continuous && (0, voice_transient_error_1.isTransientVoiceError)(error))
                throw error;
            if (error instanceof ai_gateway_1.AiGatewayError && error.diagnostic)
                new platform_logger_1.PlatformLogger().warn('AI_PROVIDER_REQUEST_REJECTED', {
                    ...error.diagnostic,
                    eventName: 'ai.provider.request_rejected',
                });
            if (error instanceof Error && error.message === 'VOICE_MEDIA_INVALID')
                new platform_logger_1.PlatformLogger().warn('VOICE_MEDIA_INVALID', {
                    eventName: 'voice.media.rejected',
                    state: typeof error.cause === 'string' &&
                        [
                            'magic',
                            'expected_size',
                            'header_missing',
                            'declared_length',
                            'response_body',
                            'stream_overflow',
                            'stream_length',
                        ].includes(error.cause)
                        ? error.cause
                        : 'unknown',
                });
            const code = error instanceof ai_gateway_1.AiGatewayError
                ? error.code
                : error instanceof Error && /^[A-Z][A-Z0-9_]{1,79}$/.test(error.message)
                    ? error.message
                    : 'AI_PROCESSING_FAILED';
            const retry = error instanceof ai_gateway_1.AiGatewayError && error.retryable && claim.attempt_count < 2;
            await this.repository.recordFailure(claim.user_id, claim.kind === 'voice.transcribe_extract' ? 'voice_transcription' : 'financial_assistant', code, code === 'AI_SCHEMA_INVALID', retry, Math.round(performance.now() - startedAt), claim.id);
            await this.repository.completeWork(claim.kind, claim.id, claim.claim_token, retry ? 'retry' : 'failed', code);
            (0, ai_observability_1.recordAiJob)(claim.kind, retry ? 'retry' : 'failure');
            outcome = retry ? 'retry' : 'failure';
            return false;
        }
        finally {
            if (renewal)
                clearInterval(renewal);
            if (deadline)
                clearTimeout(deadline);
            if (claim.kind === 'assistant.respond') {
                const durationMs = Math.round(performance.now() - startedAt);
                (0, ai_observability_1.recordAiResult)('assistant.respond', outcome, durationMs);
                new platform_logger_1.PlatformLogger().log('ASSISTANT_WORK_FINISHED', {
                    eventName: 'assistant.work_finished',
                    jobName: claim.kind,
                    state: outcome,
                    durationMs,
                    requestId: (0, node_crypto_1.createHash)('sha256').update(claim.id).digest('hex').slice(0, 24),
                });
            }
        }
    }
    async voice(claim, signal, continuous = false) {
        const input = object(await this.repository.workInput(claim.kind, claim.id, claim.claim_token));
        const route = await this.repository.getRoute('voice_transcription');
        if (!route)
            throw new ai_gateway_1.AiGatewayError('AI_UNAVAILABLE');
        const audio = await this.storage.download(String(input.storageRef), Number(input.sizeBytes), signal);
        const contentType = String(input.contentType);
        if (!validMagic(audio, contentType))
            throw new Error('VOICE_MEDIA_INVALID', { cause: 'magic' });
        if (audio.length !== Number(input.sizeBytes) ||
            typeof input.contentHash !== 'string' ||
            (0, node_crypto_1.createHash)('sha256').update(audio).digest('hex') !== input.contentHash)
            throw new Error('VOICE_MEDIA_INVALID', { cause: 'hash_mismatch' });
        if (signal.aborted)
            throw new Error('AI_WORK_CANCELLED');
        const references = aliasReferences(input.aliases);
        const batch = input.contractVersion === 3;
        const descriptors = references.map(({ alias, kind, version, data }) => {
            if (kind === 'account' && typeof data.name === 'string') {
                data = { ...data };
                try {
                    data.name = (0, ai_schemas_1.redactAiText)((0, ai_schemas_1.assertSafeAiInput)(data.name));
                }
                catch {
                    delete data.name;
                }
            }
            return { alias, kind, version, data };
        });
        let attemptNo = 0;
        let dispatchFailure;
        const completion = await this.gateway
            .complete({
            route: batch
                ? {
                    ...route,
                    limits: { ...route.limits, outputTokens: Math.min(1200, route.limits.outputTokens) },
                    prompt: { template: voice_batch_1.VOICE_BATCH_PROMPT, schemaVersion: 3 },
                }
                : route,
            voiceBatch: batch,
            userContent: [
                {
                    type: 'text',
                    text: JSON.stringify({
                        locale: String(input.locale),
                        capture: {
                            recordedAt: new Date(String(input.recordedAt)).toISOString(),
                            timezoneOffsetMinutes: input.timezoneOffsetMinutes,
                            referenceLocalDate: new Date(Date.parse(String(input.recordedAt)) -
                                Number(input.timezoneOffsetMinutes) * 60_000)
                                .toISOString()
                                .slice(0, 10),
                            legacyContext: input.captureContextLegacy,
                        },
                        references: descriptors,
                        instruction: batch
                            ? voice_batch_1.VOICE_BATCH_PROMPT
                            : 'Use only supplied aliases. Expenses use positive amountMinor; income uses negative amountMinor. Return unsupported for transfers, multiple operations, obligations, or unclear intent; never downgrade them to one transaction.',
                    }),
                },
                {
                    type: 'input_audio',
                    input_audio: { data: audio.toString('base64'), format: audioFormat(contentType) },
                },
            ],
            schema: batch ? voice_batch_1.VOICE_BATCH_OUTPUT_SCHEMA : ai_schemas_1.VOICE_OUTPUT_SCHEMA,
            parse: batch ? voice_batch_1.parseVoiceBatchProviderOutput : ai_schemas_1.parseVoiceWorkerOutput,
            requestId: String(input.operationId),
            signal,
            beforeDispatch: async (candidate) => {
                const authorized = await this.repository
                    .authorizeVoiceDispatch(claim.id, claim.claim_token, candidate.modelId, candidate.provider, route)
                    .catch((error) => {
                    dispatchFailure = error;
                    throw error;
                });
                if (authorized.operationId !== input.operationId ||
                    !Number.isInteger(authorized.attemptNo))
                    throw new Error('AI_DISPATCH_REJECTED');
                attemptNo = Number(authorized.attemptNo);
            },
            onReceipt: (receipt) => this.repository
                .recordVoiceAttempt(String(input.operationId), attemptNo, receipt, true)
                .then(() => undefined),
            onDispatchFailure: (received) => this.repository
                .recordVoiceAttempt(String(input.operationId), attemptNo, null, received)
                .then(() => undefined),
        })
            .catch((error) => {
            if (continuous && (0, voice_transient_error_1.isTransientVoiceError)(dispatchFailure))
                throw dispatchFailure;
            throw error;
        });
        if (batch) {
            const decisions = (0, voice_batch_1.decideVoiceBatch)(completion.value, {
                recordedAt: String(input.recordedAt),
                timezoneOffsetMinutes: Number(input.timezoneOffsetMinutes),
                defaultAccountId: typeof input.defaultAccountId === 'string' ? input.defaultAccountId : null,
                references,
            });
            const skipReasonCounts = {};
            let eligibleEventCount = 0;
            for (const decision of decisions) {
                if (decision.status === 'eligible')
                    eligibleEventCount++;
                else
                    skipReasonCounts[decision.reason] = (skipReasonCounts[decision.reason] ?? 0) + 1;
            }
            const diagnosticCounts = {
                extractedEventCount: decisions.length,
                eligibleEventCount,
                skippedEventCount: decisions.length - eligibleEventCount,
                skipReasonCounts,
            };
            const logger = new platform_logger_1.PlatformLogger();
            logger.info('VOICE_EXTRACTION_DECIDED', {
                context: 'AiWorker',
                eventName: 'voice.extraction_decided',
                state: decisions.length === 0 ? 'empty' : eligibleEventCount === 0 ? 'all_skipped' : 'eligible',
                ...diagnosticCounts,
            });
            signal.throwIfAborted();
            const acceptance = await this.repository.acceptVoiceBatch(claim.id, claim.claim_token, decisions, voice_batch_1.VOICE_BATCH_POLICY);
            if (acceptance.accepted !== true) {
                logger.warn('VOICE_BATCH_REJECTED', {
                    context: 'AiWorker',
                    eventName: 'voice.batch_rejected',
                    failureStage: 'batch_acceptance',
                    code: 'VOICE_SCOPE_INVALID',
                    state: acceptance.scopeMismatch === true ? 'scope_mismatch' : 'acceptance_rejected',
                    ...(acceptance.scopeMismatch === true
                        ? {
                            rejectedFields: [
                                typeof acceptance.scopeMismatchReason === 'string' &&
                                    voiceScopeReasons.has(acceptance.scopeMismatchReason)
                                    ? acceptance.scopeMismatchReason
                                    : 'unknown',
                            ],
                        }
                        : {}),
                    ...diagnosticCounts,
                });
                throw new Error('VOICE_SCOPE_INVALID');
            }
            logger.info('VOICE_BATCH_ACCEPTED', {
                context: 'AiWorker',
                eventName: 'voice.batch_accepted',
                state: 'accepted',
                ...diagnosticCounts,
            });
            if (input.retainAcceptanceEvidence !== true) {
                try {
                    await this.storage.delete(String(input.storageRef));
                }
                catch {
                    (0, ai_observability_1.recordAiJob)('voice-media.purge', 'retry');
                }
            }
            return;
        }
        const output = (0, ai_schemas_1.parseVoiceWorkerOutput)(completion.value);
        assertConfiguredOutput(route, output.transcript, 'transcript');
        if (output.outcome === 'unsupported')
            throw new Error(`VOICE_INTENT_UNSUPPORTED_${output.unsupportedReason.toUpperCase()}`);
        const proposal = resolveVoiceProposal(output.proposal, references);
        signal.throwIfAborted();
        await this.repository.saveVoiceResult(claim.id, claim.claim_token, {
            provider: completion.provider,
            model: completion.model,
            transcript: (0, ai_schemas_1.redactAiText)((0, ai_schemas_1.assertSafeAiInput)(output.transcript)),
            confidence: output.confidence,
            language: output.language,
            payload: proposal,
        });
        try {
            await this.storage.delete(String(input.storageRef));
        }
        catch {
            (0, ai_observability_1.recordAiJob)('voice-media.purge', 'retry');
        }
    }
    async assistant(claim, signal) {
        const input = object(await this.repository.workInput(claim.kind, claim.id, claim.claim_token));
        signal.throwIfAborted();
        const route = await this.repository.getRoute('financial_assistant');
        signal.throwIfAborted();
        if (!route)
            throw new ai_gateway_1.AiGatewayError('AI_UNAVAILABLE');
        const evidence = Array.isArray(input.evidence) ? input.evidence : [];
        const references = aliasReferences(input.aliases);
        const readOnlyAdvice = input.intent === 'financial_advice' || input.intent === 'general_finance';
        const completion = await this.gateway.complete({
            route: {
                ...route,
                prompt: {
                    ...route.prompt,
                    template: route.prompt.template +
                        '\nUse concise, natural Saudi/Gulf Arabic for Arabic prose. Respond in English when requested. Answer only the current question; give explanations or saving advice only when asked. Preserve amounts, currencies, dates, names and action payloads exactly. Describe an action as a preview until the user confirms it.',
                },
            },
            userContent: encodeAssistantProviderPayload(input, inputLimit(route)),
            schema: readOnlyAdvice
                ? ai_schemas_1.ASSISTANT_ADVICE_OUTPUT_SCHEMA
                : input.intent === 'create_transaction'
                    ? ai_schemas_1.ASSISTANT_TRANSACTION_OUTPUT_SCHEMA
                    : ai_schemas_1.ASSISTANT_OUTPUT_SCHEMA,
            parse: readOnlyAdvice ? ai_schemas_1.parseAssistantAdviceWorkerOutput : ai_schemas_1.parseAssistantWorkerOutput,
            requestId: String(input.operationId),
            signal,
        });
        signal.throwIfAborted();
        if (input.intent === 'create_transaction' &&
            completion.value.actionPreview &&
            completion.value.actionPreview.actionType !== 'transaction.create')
            throw new ai_gateway_1.AiGatewayError('AI_SCHEMA_INVALID');
        const allowed = new Set([
            ...evidence.map((item) => String(object(item).alias)),
            ...references.map(({ alias }) => alias),
        ]);
        if (completion.value.evidenceIds.some((id) => !allowed.has(id)) ||
            completion.value.actionPreview?.evidenceIds.some((id) => !allowed.has(id)))
            throw new ai_gateway_1.AiGatewayError('AI_SCHEMA_INVALID', true);
        const refs = evidence.map((item) => {
            const value = object(item);
            return {
                kind: value.kind,
                alias: value.alias,
                version: value.version,
                ...(typeof value.asOf === 'string' ? { asOf: value.asOf } : {}),
            };
        });
        const output = resolveAssistantOutput(completion.value, references);
        assertConfiguredOutput(route, output, 'answer');
        await this.repository.recordUsage(claim.user_id, 'financial_assistant', completion, String(input.operationId));
        signal.throwIfAborted();
        await this.repository.saveAssistantResult(claim.id, claim.claim_token, {
            provider: completion.provider,
            model: completion.model,
            content: (0, ai_schemas_1.redactAiText)(output.answer),
            evidence: refs,
            preview: output.actionPreview,
        });
    }
    async evaluate(claim) {
        const input = object(await this.repository.workInput(claim.kind, claim.id, claim.claim_token));
        const cases = Array.isArray(input.cases) ? input.cases : [];
        if (typeof input.template !== 'string')
            throw new Error('AI_EVALUATION_FAILED');
        evaluatePromptCorpus(input.template, cases);
        await this.repository.completeWork(claim.kind, claim.id, claim.claim_token, 'completed', null);
    }
    async purge() {
        const limit = this.config.getRequired('MASARIFI_AI_JOB_BATCH_SIZE');
        const lease = this.config.getRequired('MASARIFI_AI_LEASE_SECONDS');
        const claims = this.config.get('MASARIFI_VOICE_ANALYSIS_ONLY')
            ? await this.repository.claimAnalysisPurges(this.workerId(), limit, lease)
            : await this.repository.claimPurges(this.workerId(), limit, lease);
        for (const claim of claims) {
            try {
                await this.storage.delete(claim.storage_ref);
                await this.repository.completePurge(claim.id, claim.purge_token, true);
                (0, ai_observability_1.recordAiJob)('voice-media.purge', 'success');
            }
            catch {
                await this.repository.completePurge(claim.id, claim.purge_token, false);
                (0, ai_observability_1.recordAiJob)('voice-media.purge', 'failure');
            }
        }
        return claims.length;
    }
    workerId() {
        return this.config.get('MASARIFI_WORKER_ID') ?? `ai-${process.pid.toString()}`;
    }
};
exports.AiWorker = AiWorker;
exports.AiWorker = AiWorker = __decorate([
    (0, common_1.Injectable)(),
    __param(2, (0, common_1.Inject)('AI_GATEWAY')),
    __metadata("design:paramtypes", [ai_repository_1.AiRepository,
        ai_storage_1.AiStorage,
        ai_gateway_1.AiGateway,
        platform_config_service_1.PlatformConfigService])
], AiWorker);
