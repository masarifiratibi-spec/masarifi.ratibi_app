"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.AiRepository = void 0;
const financial_worker_generation_1 = require("../platform/database/financial-worker-generation");
const node_crypto_1 = require("node:crypto");
const common_1 = require("@nestjs/common");
const idempotency_1 = require("../ledger/idempotency");
const pool_service_1 = require("../platform/database/pool.service");
const voice_transient_error_1 = require("./voice-transient-error");
const platform_logger_1 = require("../platform/observability/platform-logger");
function stableUuid(seed) {
    const bytes = (0, node_crypto_1.createHash)('sha256').update(seed).digest().subarray(0, 16);
    bytes[6] = ((bytes[6] ?? 0) & 0x0f) | 0x40;
    bytes[8] = ((bytes[8] ?? 0) & 0x3f) | 0x80;
    const hex = bytes.toString('hex');
    return `${hex.slice(0, 8)}-${hex.slice(8, 12)}-${hex.slice(12, 16)}-${hex.slice(16, 20)}-${hex.slice(20)}`;
}
function camel(key) {
    return key.replace(/_([a-z])/g, (_match, letter) => letter.toUpperCase());
}
function publicValue(value) {
    if (value instanceof Date)
        return value.toISOString();
    if (Array.isArray(value))
        return value.map(publicValue);
    if (!value || typeof value !== 'object')
        return value;
    return Object.fromEntries(Object.entries(value).map(([key, child]) => [
        camel(key),
        publicValue(child),
    ]));
}
function mapped(error) {
    if (error instanceof common_1.HttpException)
        return error;
    const message = error && typeof error === 'object' && 'message' in error
        ? String(Reflect.get(error, 'message'))
        : '';
    if (message === 'VOICE_AUTOMATIC_UNAVAILABLE')
        return new common_1.HttpException({ code: 'VOICE_AUTOMATIC_UNAVAILABLE' }, 503);
    if (message === 'PROFILE_INACTIVE')
        return new common_1.HttpException({ code: 'PROFILE_INACTIVE' }, 403);
    if (/NOT_FOUND/.test(message))
        return new common_1.HttpException({ code: message }, 404);
    if (/EXPIRED/.test(message))
        return new common_1.HttpException({ code: message }, 410);
    if (/CONFLICT|FENCE|IN_PROGRESS|REUSED/.test(message))
        return new common_1.HttpException({ code: message }, 409);
    if (/CONSENT|OWNER|PERMISSION|DENIED/.test(message))
        return new common_1.HttpException({ code: message }, 403);
    if (/QUOTA|BUDGET/.test(message))
        return new common_1.HttpException({ code: message }, 429);
    if (/ROUTE_UNAVAILABLE|PROMPT_UNAVAILABLE|AUTOMATIC_UNAVAILABLE/.test(message))
        return new common_1.HttpException({ code: 'AI_UNAVAILABLE' }, 503);
    if (/INVALID|LIMIT|REQUIRED|SCHEMA/.test(message))
        return new common_1.HttpException({ code: message }, 422);
    return error instanceof Error ? error : new Error('AI_DATABASE_UNAVAILABLE');
}
function quotaError(quota) {
    throw new common_1.HttpException({
        code: quota.reason === 'AI_BUDGET_EXHAUSTED' ? quota.reason : 'AI_QUOTA_EXCEEDED',
        limit: quota.limit,
        used: quota.used,
        resetsAt: quota.resetsAt,
    }, 429);
}
let AiRepository = class AiRepository {
    pool;
    constructor(pool) {
        this.pool = pool;
    }
    operationId(principal, scope, key) {
        return stableUuid(`${principal.userId}:${scope}:${(0, idempotency_1.hashIdempotencyKey)(key)}`);
    }
    async workloadAvailable(workload) {
        return Boolean((await this.pool.query('select private.ai_workload_available($1) result', [workload])).rows[0]?.result);
    }
    createVoiceSession(principal, input, key, uploadSeconds = 300, automatic) {
        return this.idempotent(principal, 'ai.voice-session.create', key, automatic
            ? {
                ...input,
                contractVersion: 3,
                ...(automatic.analysisOnly ? { analysisOnly: true } : {}),
            }
            : input, 201, async (client, operationId) => automatic
            ? this.json(client, automatic.analysisOnly
                ? 'select private.create_voice_analysis_session($1,$2::jsonb,$3::uuid,$4,$5,$6,$7::jsonb) result'
                : 'select private.create_voice_session_v3($1,$2::jsonb,$3::uuid,$4,$5,$6,$7::jsonb) result', [
                principal.userId,
                JSON.stringify(input),
                operationId,
                uploadSeconds,
                principal.factorAgeSeconds,
                automatic.maxAuthAge,
                JSON.stringify(automatic.thresholds),
            ])
            : input.contentHash
                ? this.json(client, 'select private.create_voice_session_v2($1,$2::jsonb,$3::uuid,$4) result', [principal.userId, JSON.stringify(input), operationId, uploadSeconds])
                : this.json(client, 'select private.create_voice_session($1,$2,$3,$4,$5,$6::uuid) result', [
                    principal.userId,
                    input.locale,
                    input.durationMs,
                    input.contentType,
                    input.sizeBytes,
                    operationId,
                ]));
    }
    createVoiceReviewSession(principal, input, key, uploadSeconds = 300) {
        return this.idempotent(principal, 'ai.voice-session.create', key, input, 201, (client, operationId) => this.json(client, 'select private.create_voice_review_session($1,$2::jsonb,$3::uuid,$4) result', [principal.userId, JSON.stringify(input), operationId, uploadSeconds]));
    }
    processVoiceSession(principal, sessionId, input, key) {
        return this.idempotent(principal, `ai.voice-session.process.${sessionId}`, key, input, 202, async (client, operationId) => {
            const quota = await this.json(client, 'select private.reserve_ai_quota($1,$2::uuid,$3) result', [principal.userId, operationId, 'voice_transcription']);
            if (!quota.allowed)
                quotaError(quota);
            return this.json(client, 'select private.finalize_voice_session($1,$2::uuid,$3,$4,$5::uuid) result', [principal.userId, sessionId, input.expectedVersion, input.contentHash, operationId]);
        });
    }
    getVoiceBatchResult(principal, sessionId, eventResults = false) {
        const sql = eventResults
            ? 'select private.get_voice_batch_event_result($1,$2::uuid) result'
            : 'select private.get_voice_batch_result($1,$2::uuid) result';
        return this.ownerJson(principal, sql, [principal.userId, sessionId], eventResults);
    }
    listVoiceBatchRecovery(principal, after, afterId, limit, eventResults = false) {
        const sql = eventResults
            ? 'select private.list_voice_batch_event_recovery($1,$2::timestamptz,$3::uuid,$4) result'
            : 'select private.list_voice_batch_recovery($1,$2::timestamptz,$3::uuid,$4) result';
        return this.ownerJson(principal, sql, [principal.userId, after, afterId, limit], eventResults);
    }
    acceptVoiceBatch(id, token, decisions, policy) {
        return this.workerJson('select private.accept_voice_batch($1::uuid,$2::uuid,$3::jsonb,$4) result', [id, token, JSON.stringify(decisions), policy]);
    }
    async finalizeVoiceBatches(limit) {
        limit = Math.min(limit, 25);
        await this.worker(async (client) => {
            await client.query('select private.purge_expired_voice_commands($1)', [limit]);
        });
        const claims = await this.worker(async (client) => (await client.query('select * from private.claim_voice_finalization($1)', [limit])).rows);
        await this.finalizeVoiceClaims(claims);
        return claims.length;
    }
    async finalizeVoiceEpoch(epoch, limit, bounded = false, continuous = false) {
        if (!bounded)
            await this.worker(async (client) => {
                await client.query('select private.expire_staging_voice_commands($1::uuid,$2)', [
                    epoch,
                    limit,
                ]);
            });
        const claims = await this.worker(async (client) => (await client.query('select * from private.claim_staging_voice_finalization($1::uuid,$2)', [epoch, limit])).rows);
        return this.finalizeVoiceClaims(claims, bounded
            ? () => this.closeVoiceEpoch(epoch, 'execution_failed').then(() => undefined)
            : undefined, continuous);
    }
    async finalizeVoiceClaims(claims, stopOnFailure, continuous = false) {
        let failed = false;
        for (const claim of claims) {
            try {
                const events = await this.worker(async (client) => (await client.query('select private.list_voice_finalization_events($1::uuid,$2::uuid) result', [claim.batch_id, claim.token])).rows[0]?.result);
                for (const next of events ?? []) {
                    try {
                        const receipt = await this.worker(async (client) => {
                            await (0, financial_worker_generation_1.bindFinancialClaim)(client, 'voice-batch', claim.batch_id, claim.token);
                            return this.json(client, continuous
                                ? 'select private.execute_operating_voice_event($1::uuid,$2::uuid,$3::uuid) result'
                                : 'select private.execute_voice_event($1::uuid,$2::uuid,$3::uuid) result', [claim.batch_id, claim.token, next.eventId]);
                        });
                        if (stopOnFailure && receipt.status !== 'committed') {
                            failed = true;
                            await stopOnFailure();
                            break;
                        }
                    }
                    catch (error) {
                        if (continuous && (0, voice_transient_error_1.isTransientVoiceError)(error))
                            throw error;
                        const permanent = continuous ? (0, voice_transient_error_1.permanentVoiceFailure)(error) : null;
                        if (permanent) {
                            await this.workerJson('select private.fail_operating_voice_event($1::uuid,$2::uuid,$3::uuid) result', [claim.batch_id, claim.token, next.eventId]);
                            try {
                                new platform_logger_1.PlatformLogger().error('VOICE_FINALIZATION_REJECTED', {
                                    failureStage: 'finalize',
                                    code: permanent,
                                    resourceId: next.eventId,
                                });
                            }
                            catch {
                            }
                            continue;
                        }
                        if (stopOnFailure) {
                            failed = true;
                            await stopOnFailure();
                            break;
                        }
                        await this.worker(async (client) => {
                            await client.query('select private.retry_voice_event($1::uuid,$2::uuid,$3::uuid)', [
                                claim.batch_id,
                                claim.token,
                                next.eventId,
                            ]);
                        });
                    }
                }
            }
            finally {
                if (!failed)
                    await this.worker(async (client) => {
                        await client.query(continuous
                            ? 'select private.release_operating_voice_finalization($1::uuid,$2::uuid)'
                            : 'select private.retry_voice_finalization($1::uuid,$2::uuid)', [claim.batch_id, claim.token]);
                    });
            }
            if (failed)
                break;
        }
        return !failed;
    }
    voiceEpochHeartbeat(epoch, workerId, sourceSha) {
        return this.workerJson('select private.staging_voice_heartbeat($1::uuid,$2,$3) result', [
            epoch,
            workerId,
            sourceSha,
        ]);
    }
    closeVoiceEpoch(epoch, reason) {
        return this.workerJson("select jsonb_build_object('closed',private.close_staging_voice_epoch($1::uuid,$2)) result", [epoch, reason]);
    }
    claimVoiceEpochWork(epoch, workerId, limit, lease) {
        return this.worker(async (client) => (await client.query("select w.*,private.bind_financial_worker_generation('voice',w.id,w.claim_token)::text generation from private.claim_staging_voice_work($1::uuid,$2,$3,$4) w", [epoch, workerId, limit, lease])).rows);
    }
    claimVoiceEpochPurges(epoch, workerId, limit, lease) {
        return this.worker(async (client) => (await client.query('select * from private.claim_staging_voice_purge($1::uuid,$2,$3,$4)', [epoch, workerId, limit, lease])).rows);
    }
    getVoiceSession(principal, sessionId) {
        return this.ownerJson(principal, 'select private.get_voice_session($1,$2::uuid) result', [
            principal.userId,
            sessionId,
        ]);
    }
    getVoiceProposal(principal, sessionId) {
        return this.ownerJson(principal, 'select private.get_voice_proposal($1,$2::uuid) result', [
            principal.userId,
            sessionId,
        ]);
    }
    beginVoiceUpload(principal, sessionId) {
        return this.ownerJson(principal, 'select private.begin_voice_upload($1,$2::uuid) result', [
            principal.userId,
            sessionId,
        ]);
    }
    finishVoiceUpload(principal, sessionId, token, hash) {
        return this.ownerJson(principal, 'select private.finish_voice_upload($1,$2::uuid,$3::uuid,$4) result', [principal.userId, sessionId, token, hash]);
    }
    releaseVoiceUpload(principal, sessionId, token) {
        return this.owner(principal, async (client) => {
            await client.query('select private.release_voice_upload($1,$2::uuid,$3::uuid)', [
                principal.userId,
                sessionId,
                token,
            ]);
        });
    }
    cancelVoiceSession(principal, sessionId, key) {
        return this.idempotent(principal, 'ai.voice-session.cancel.' + sessionId, key, {}, 200, (client) => this.json(client, 'select private.cancel_voice_session($1,$2::uuid) result', [
            principal.userId,
            sessionId,
        ]));
    }
    getVoiceRecovery(principal, sessionId) {
        return this.ownerJson(principal, 'select private.get_voice_recovery($1,$2::uuid) result', [
            principal.userId,
            sessionId,
        ]);
    }
    listVoicePreferences(principal) {
        return this.ownerValues(principal, 'select value from private.list_voice_category_preferences($1)', [principal.userId]);
    }
    upsertVoicePreference(principal, input, key) {
        return this.idempotent(principal, `ai.voice-category-preference.${input.id ? 'update' : 'create'}`, key, input, 200, (client) => this.json(client, 'select private.upsert_voice_category_preference($1,$2::uuid,$3,$4,$5::uuid,$6) result', [
            principal.userId,
            input.id,
            input.expectedVersion,
            input.merchantPattern,
            input.categoryId,
            input.confidence,
        ]));
    }
    deleteVoicePreference(principal, id, version, key) {
        return this.idempotent(principal, `ai.voice-category-preference.delete.${id}`, key, { expectedVersion: version }, 204, async (client) => ({
            id,
            deleted: Boolean((await client.query('select private.delete_voice_category_preference($1,$2::uuid,$3) result', [principal.userId, id, version])).rows[0]?.result),
        }));
    }
    getConsent(principal, policyVersion) {
        return this.ownerJson(principal, 'select private.get_assistant_consent($1,$2) result', [
            principal.userId,
            policyVersion,
        ]);
    }
    getAssistantAvailability(principal, policyVersion = 'assistant-privacy-v1') {
        return this.ownerJson(principal, 'select private.get_assistant_availability($1,$2) result', [
            principal.userId,
            policyVersion,
        ]);
    }
    setConsent(principal, policyVersion, enabled, expectedVersion, key) {
        return this.idempotent(principal, `ai.assistant-consent.${enabled ? 'grant' : 'revoke'}`, key, { policyVersion, enabled, expectedVersion }, 200, (client) => this.json(client, 'select private.set_assistant_consent($1,$2,$3,$4) result', [
            principal.userId,
            policyVersion,
            enabled,
            expectedVersion,
        ]));
    }
    createConversation(principal, title, key) {
        return this.idempotent(principal, 'ai.assistant-conversation.create', key, { title }, 201, (client) => this.json(client, 'select private.create_assistant_conversation($1,$2) result', [
            principal.userId,
            title,
        ]));
    }
    updateConversation(principal, id, input, key) {
        return this.idempotent(principal, `ai.assistant-conversation.update.${id}`, key, input, 200, (client) => this.json(client, 'select private.update_assistant_conversation($1,$2::uuid,$3,$4,$5) result', [principal.userId, id, input.title ?? null, input.status ?? null, input.expectedVersion]));
    }
    async getConversation(principal, id) {
        return this.owner(principal, async (client) => {
            const row = (await client.query(`select id,title,status,last_message_at,version,created_at,updated_at from public.assistant_conversations where id=$1 and user_id=$2 and status<>'deleted'`, [id, principal.userId])).rows[0];
            if (!row)
                throw new Error('AI_CONVERSATION_NOT_FOUND');
            const version = Number(row.version);
            if (!Number.isSafeInteger(version) || version < 1)
                throw new Error('AI_CONVERSATION_SCHEMA_INVALID');
            return publicValue({ ...row, version });
        });
    }
    listConversations(principal, cursor, limit) {
        return this.ownerValues(principal, 'select value from private.list_assistant_conversations($1,$2::timestamptz,$3::uuid,$4)', [principal.userId, cursor.time, cursor.id, limit]);
    }
    enqueueMessage(principal, conversationId, input, key) {
        return this.idempotent(principal, `ai.assistant-message.create.${conversationId}`, key, input.requestIdentity ?? input, 202, async (client, operationId) => {
            const quota = await this.json(client, 'select private.reserve_ai_quota($1,$2::uuid,$3) result', [principal.userId, operationId, 'financial_assistant']);
            if (!quota.allowed)
                quotaError(quota);
            return this.json(client, input.context?.assistantAgent === 1
                ? 'select private.enqueue_assistant_agent_message($1,$2::uuid,$3,$4,$5::text[],$6::jsonb,$7::jsonb,$8::jsonb,$9,$10::uuid) result'
                : 'select private.enqueue_assistant_message_v3($1,$2::uuid,$3,$4,$5::text[],$6::jsonb,$7::jsonb,$8::jsonb,$9,$10::uuid) result', [
                principal.userId,
                conversationId,
                input.content,
                input.intent,
                input.contextScope ?? [],
                JSON.stringify(input.context ?? {}),
                JSON.stringify(input.evidence ?? []),
                JSON.stringify(input.history ?? []),
                input.responseMode,
                operationId,
            ]);
        });
    }
    saveDeterministicMessage(principal, conversationId, input, key) {
        return this.idempotent(principal, `ai.assistant-message.create.${conversationId}`, key, input.requestIdentity ?? input, 202, (client, operationId) => this.json(client, 'select private.save_deterministic_assistant_message($1,$2::uuid,$3,$4,$5,$6::jsonb,$7::jsonb,$8,$9::uuid) result', [
            principal.userId,
            conversationId,
            input.content,
            input.intent,
            input.answer,
            JSON.stringify(input.context ?? {}),
            JSON.stringify(input.evidence ?? []),
            input.responseMode,
            operationId,
        ]));
    }
    recentConversationTurns(principal, conversationId, limit) {
        return this.ownerValues(principal, `select jsonb_build_object('role',role,'content',content_redacted,'intent',intent) value
       from public.assistant_messages
       where conversation_id=$1 and user_id=$2 and work_status='completed'
       order by created_at desc,coalesce(reply_to_message_id,id) desc,
         (role='assistant') desc,id desc limit least($3,private.ai_history_turn_limit())`, [conversationId, principal.userId, limit]).then((rows) => rows.reverse());
    }
    listInsights(principal, limit) {
        return this.ownerValues(principal, 'select value from private.list_financial_insights($1,$2)', [
            principal.userId,
            limit,
        ]);
    }
    listMessages(principal, conversationId, cursor, limit) {
        return this.ownerValues(principal, 'select value from private.list_assistant_messages($1,$2::uuid,$3::timestamptz,$4::uuid,$5)', [principal.userId, conversationId, cursor.time, cursor.id, limit]);
    }
    messageResult(principal, messageId) {
        return this.ownerJson(principal, 'select private.get_assistant_message_result($1,$2::uuid) result', [principal.userId, messageId]);
    }
    async getMessage(principal, messageId) {
        const rows = await this.ownerValues(principal, `select (to_jsonb(m)-array['user_id','claim_token','claimed_by','lease_until','context_scope','evidence_payload']) || jsonb_build_object(
       'snapshot',(select to_jsonb(s)-array['user_id','message_id'] from public.assistant_response_snapshots s where s.message_id=m.id),
       'preview',(select to_jsonb(a)-array['user_id','decision_token','decision_action','decision_lease_until','deleted_at'] from public.assistant_action_previews a where a.message_id=m.id order by a.created_at limit 1)) value
       from public.assistant_messages m join public.assistant_conversations c on c.id=m.conversation_id
       where m.id=$1::uuid and m.user_id=$2 and c.user_id=$2 and c.deleted_at is null`, [messageId, principal.userId]);
        if (!rows[0])
            throw new common_1.HttpException({ code: 'AI_MESSAGE_NOT_FOUND' }, 404);
        return rows[0];
    }
    async messageAcceptance(principal, conversationId, key) {
        const operationId = this.operationId(principal, `ai.assistant-message.create.${conversationId}`, key);
        const rows = await this.ownerValues(principal, `select jsonb_build_object('id',m.id,'status',m.work_status) value from public.assistant_messages m
       join public.assistant_conversations c on c.id=m.conversation_id
       where m.user_id=$1 and m.conversation_id=$2::uuid and m.operation_id=$3::uuid and m.role='user' and c.user_id=$1 and c.deleted_at is null`, [principal.userId, conversationId, operationId]);
        if (!rows[0])
            throw new common_1.HttpException({ code: 'AI_MESSAGE_NOT_FOUND' }, 404);
        return rows[0];
    }
    async getPreviewTimezone(principal, previewId) {
        const rows = await this.ownerValues(principal, `select jsonb_build_object('timezone',q.context_payload->>'timezone') value
       from public.assistant_action_previews p join public.assistant_messages r on r.id=p.message_id
       join public.assistant_messages q on q.id=r.reply_to_message_id
       join public.assistant_conversations c on c.id=q.conversation_id
       where p.id=$1::uuid and p.user_id=$2 and q.user_id=$2 and c.user_id=$2 and c.deleted_at is null`, [previewId, principal.userId]);
        const timezone = rows[0]?.timezone;
        if (typeof timezone !== 'string' || !timezone)
            throw new common_1.HttpException({ code: 'AI_EVIDENCE_INCOMPLETE' }, 409);
        return timezone;
    }
    cancelMessage(principal, messageId) {
        return this.owner(principal, async (client) => Boolean((await client.query('select private.cancel_assistant_message($1,$2::uuid) result', [principal.userId, messageId])).rows[0]?.result));
    }
    claimVoiceAction(principal, id, operationId, decision) {
        return this.ownerJson(principal, 'select private.claim_voice_action($1::uuid,$2,$3::uuid,$4::jsonb,$5::jsonb,$6) result', [
            id,
            decision.expectedVersion,
            operationId,
            JSON.stringify(decision.editedFields),
            JSON.stringify(decision.command),
            decision.timezoneOffsetMinutes,
        ]);
    }
    completeVoiceAction(principal, id, token, resourceId) {
        return this.ownerJson(principal, 'select private.complete_voice_action($1::uuid,$2::uuid,$3::uuid) result', [id, token, resourceId]);
    }
    abandonVoiceAction(principal, id, token) {
        return this.owner(principal, async (client) => Boolean((await client.query('select private.abandon_voice_action($1::uuid,$2::uuid) result', [id, token])).rows[0]?.result));
    }
    claimAction(principal, id, version, operationId, patch = {}) {
        return this.ownerJson(principal, 'select private.confirm_ai_action($1::uuid,$2,$3::uuid,$4::jsonb) result', [id, version, operationId, JSON.stringify(patch)]);
    }
    completeAction(principal, id, token, resourceId) {
        return this.ownerJson(principal, 'select private.complete_ai_action($1::uuid,$2::uuid,$3::uuid) result', [id, token, resourceId]);
    }
    rejectAction(principal, id, version, reason, key) {
        return this.idempotent(principal, `ai.action.reject.${id}`, key, { expectedVersion: version, reason }, 200, (client) => this.json(client, 'select private.reject_ai_action($1,$2::uuid,$3,$4) result', [
            principal.userId,
            id,
            version,
            reason,
        ]));
    }
    feedback(principal, messageId, rating, reason, key) {
        return this.idempotent(principal, `ai.assistant-feedback.${messageId}`, key, { rating, reason }, 200, (client) => this.json(client, 'select private.record_assistant_feedback($1,$2::uuid,$3::smallint,$4) result', [principal.userId, messageId, rating, reason]));
    }
    report(principal, messageId, type, reason, key) {
        return this.idempotent(principal, `ai.assistant-report.${messageId}`, key, { type, reason }, 201, (client) => this.json(client, 'select private.create_ai_response_report($1,$2::uuid,$3,$4) result', [
            principal.userId,
            messageId,
            type,
            reason,
        ]));
    }
    adminRead(principal, resource, id, limit) {
        return this.ownerValues(principal, 'select value from private.read_admin_ai($1,$2::uuid,$3)', [
            resource,
            id,
            limit,
        ]);
    }
    adminReadPage(principal, resource, afterId, limit, filters = {}) {
        return this.ownerValues(principal, 'select value from private.read_admin_ai_filtered($1,$2::uuid,$3,$4::jsonb)', [resource, afterId, limit, JSON.stringify(filters)]);
    }
    adminMutate(principal, resource, id, input, key, requestId) {
        return this.idempotent(principal, `ai.admin.${resource}.${id ? 'update' : 'create'}`, key, input, id ? 200 : 201, async (client) => {
            const { reason, expectedVersion, ...patch } = input;
            return this.json(client, 'select private.mutate_admin_ai($1,$2::uuid,$3,$4::jsonb,$5,$6,$7) result', [
                resource,
                id,
                expectedVersion ?? 1,
                JSON.stringify(patch),
                principal.userId,
                reason,
                requestId,
            ]);
        }, true);
    }
    testPrompt(principal, id, input, key, requestId) {
        return this.idempotent(principal, `ai.prompts.test.${id}`, key, input, 202, (client) => this.json(client, 'select private.test_ai_prompt_version($1::uuid,$2,$3,$4,$5) result', [
            id,
            input.expectedVersion,
            principal.userId,
            input.reason,
            requestId,
        ]), true);
    }
    publishPrompt(principal, id, input, key, requestId) {
        return this.idempotent(principal, `ai.prompts.publish.${id}`, key, input, 200, (client) => this.json(client, 'select private.publish_ai_prompt_version($1::uuid,$2,$3,$4,$5) result', [
            id,
            input.expectedVersion,
            principal.userId,
            input.reason,
            requestId,
        ]), true);
    }
    getRoute(workload) {
        return this.worker(async (client) => (await client.query('select private.get_effective_ai_route($1) result', [workload])).rows[0]?.result ?? null);
    }
    claimWork(kind, workerId, limit, leaseSeconds) {
        return this.workerClaims("select coalesce(jsonb_agg(to_jsonb(work) || jsonb_build_object('generation',case when work.kind='ai.evaluate_route' then null else private.bind_financial_worker_generation(case when work.kind='assistant.respond' then 'assistant' else 'voice' end,work.id,work.claim_token)::text end)),'[]'::jsonb) claims from private.claim_ai_work($1,$2,$3,$4) work", [kind, workerId, limit, leaseSeconds]);
    }
    claimAnalysisWork(workerId, limit, leaseSeconds) {
        return this.workerClaims("select coalesce(jsonb_agg(to_jsonb(work) || jsonb_build_object('generation',private.bind_financial_worker_generation('voice',work.id,work.claim_token)::text)),'[]'::jsonb) claims from private.claim_voice_analysis_work($1,$2,$3) work", [workerId, limit, leaseSeconds]);
    }
    claimAnalysisPurges(workerId, limit, leaseSeconds) {
        return this.workerClaims("select coalesce(jsonb_agg(work),'[]'::jsonb) claims from private.claim_voice_analysis_purge($1,$2,$3) work", [workerId, limit, leaseSeconds]);
    }
    workInput(kind, id, token) {
        return kind === 'assistant.respond'
            ? this.workerJson('select private.get_assistant_work_input_v2($1::uuid,$2::uuid) result', [
                id,
                token,
            ])
            : this.workerJson('select private.get_ai_work_input($1,$2::uuid,$3::uuid) result', [
                kind,
                id,
                token,
            ]);
    }
    renewVoiceWork(id, token, leaseSeconds) {
        return this.worker(async (client) => (await client.query('select private.renew_voice_work($1::uuid,$2::uuid,$3) result', [id, token, leaseSeconds])).rows[0]?.result === true);
    }
    authorizeVoiceDispatch(id, token, model, provider, policy) {
        return this.workerJson('select private.authorize_voice_dispatch($1::uuid,$2::uuid,$3,$4,$5::jsonb) result', [id, token, model, provider, JSON.stringify(policy)]);
    }
    recordVoiceAttempt(operationId, attempt, receipt, responseReceived) {
        const safeReceipt = receipt
            ? {
                ...receipt.usage,
                latencyMs: receipt.latencyMs,
                fallbackUsed: receipt.fallbackUsed,
                generationHash: (0, node_crypto_1.createHash)('sha256').update(receipt.generationId).digest('hex'),
            }
            : null;
        return this.workerJson('select private.record_voice_attempt($1::uuid,$2,$3::jsonb,$4) result', [
            operationId,
            attempt,
            safeReceipt ? JSON.stringify(safeReceipt) : null,
            responseReceived,
        ]);
    }
    saveVoiceResult(id, token, result) {
        return this.workerJson('select private.save_voice_result($1::uuid,$2::uuid,$3,$4,$5,$6,$7,$8::jsonb) result', [
            id,
            token,
            result.provider,
            result.model,
            result.transcript,
            result.confidence,
            result.language,
            JSON.stringify(result.payload),
        ]);
    }
    saveAssistantResult(id, token, result) {
        return this.workerJson('select private.save_assistant_result($1::uuid,$2::uuid,$3,$4,$5,$6::jsonb,$7::jsonb) result', [
            id,
            token,
            result.provider,
            result.model,
            result.content,
            JSON.stringify(result.evidence),
            result.preview == null ? null : JSON.stringify(result.preview),
        ]);
    }
    completeWork(kind, id, token, status, error) {
        return this.worker(async (client) => Boolean((await client.query('select private.complete_ai_work($1,$2::uuid,$3::uuid,$4,$5) result', [kind, id, token, status, error])).rows[0]?.result));
    }
    recordUsage(userId, workload, completion, requestId) {
        const generationHash = (0, node_crypto_1.createHash)('sha256').update(completion.generationId).digest('hex');
        return this.worker(async (client) => {
            await client.query('select private.record_ai_usage($1,$2,$3,$4,$5,$6,$7,$8,$9,$10)', [
                userId,
                workload,
                completion.model,
                completion.provider,
                completion.usage.inputTokens,
                completion.usage.outputTokens,
                completion.usage.cost,
                completion.latencyMs,
                completion.fallbackUsed,
                requestId,
            ]);
            await client.query('select private.record_ai_generation_hash($1,$2)', [
                requestId,
                generationHash,
            ]);
        });
    }
    recordFailure(userId, workload, code, schemaFailure, retryable, latencyMs, requestId) {
        return this.worker(async (client) => {
            await client.query('select private.record_ai_failure($1,$2,$3,$4,$5,$6,$7,$8,$9)', [
                userId,
                workload,
                null,
                null,
                code,
                schemaFailure,
                retryable,
                latencyMs,
                requestId,
            ]);
        });
    }
    expire(limit) {
        return this.worker(async (client) => (await client.query('select private.expire_ai_proposals($1) result', [
            limit,
        ])).rows[0]?.result ?? 0);
    }
    reconcile(limit) {
        return this.workerJson('select private.reconcile_ai_state($1) result', [limit]);
    }
    rollup(limit) {
        return this.workerJson('select private.rollup_ai_usage($1) result', [limit]);
    }
    refreshInsights(limit) {
        return this.worker(async (client) => (await client.query('select private.refresh_financial_insights($1) result', [limit])).rows[0]?.result ?? 0);
    }
    claimPurges(workerId, limit, leaseSeconds) {
        return this.worker(async (client) => (await client.query('select * from private.claim_voice_media_purge($1,$2,$3)', [workerId, limit, leaseSeconds])).rows);
    }
    completePurge(id, token, deleted) {
        return this.worker(async (client) => Boolean((await client.query('select private.complete_voice_media_purge($1::uuid,$2::uuid,$3,$4) result', [id, token, deleted, deleted ? null : 'VOICE_PURGE_FAILED'])).rows[0]?.result));
    }
    async idempotent(principal, scope, key, command, status, action, admin = false) {
        return this.owner(principal, async (client) => {
            const keyHash = (0, idempotency_1.hashIdempotencyKey)(key), requestHash = (0, idempotency_1.hashNormalizedCommand)(command);
            const storedScope = admin ? `tracking.admin.${scope}` : scope;
            const claim = (await client.query(admin
                ? 'select * from private.claim_tracking_admin_idempotency($1,$2,$3,$4,$5::interval)'
                : 'select * from private.claim_sync_idempotency_key($1,$2,$3,$4,$5::interval)', [principal.userId, storedScope, keyHash, requestHash, '2 minutes'])).rows[0];
            if (!claim)
                throw new Error('IDEMPOTENCY_REPLAY_UNAVAILABLE');
            if (claim.outcome === 'replay')
                return { ...(claim.response_body ?? {}), replayed: true };
            if (claim.outcome === 'hash_mismatch')
                throw new Error('IDEMPOTENCY_KEY_REUSED');
            if (claim.outcome === 'in_progress' || !claim.lease_token)
                throw new Error('IDEMPOTENCY_IN_PROGRESS');
            const operationId = this.operationId(principal, scope, key);
            const resource = await action(client, operationId);
            const response = { resource: publicValue(resource), operationId, replayed: false };
            await client.query(admin
                ? 'select private.complete_tracking_admin_idempotency($1,$2,$3,$4,$5,$6,$7::jsonb,$8)'
                : 'select private.complete_sync_idempotency_key($1,$2,$3,$4,$5,$6,$7::jsonb,$8)', [
                principal.userId,
                storedScope,
                keyHash,
                requestHash,
                claim.lease_token,
                status,
                JSON.stringify(response),
                typeof resource.id === 'string' ? resource.id : operationId,
            ]);
            return response;
        });
    }
    ownerJson(principal, sql, values, repeatableRead = false) {
        return this.owner(principal, async (client) => publicValue(await this.json(client, sql, values)), repeatableRead);
    }
    workerClaims(sql, values) {
        return this.worker(async (client) => {
            const row = (await client.query(sql, [...values])).rows[0];
            if (!row || !Array.isArray(row.claims))
                throw new Error('AI_RESULT_MISSING');
            return row.claims;
        });
    }
    workerJson(sql, values) {
        return this.worker(async (client) => publicValue(await this.json(client, sql, values)));
    }
    ownerValues(principal, sql, values) {
        return this.owner(principal, async (client) => publicValue((await client.query(sql, [...values])).rows.map(({ value }) => value)));
    }
    async json(client, sql, values) {
        const result = (await client.query(sql, [...values])).rows[0]?.result;
        if (!result)
            throw new Error('AI_RESULT_MISSING');
        return result;
    }
    owner(principal, action, repeatableRead = false) {
        return this.transaction('masarifi_api', principal, action, repeatableRead);
    }
    worker(action) {
        return this.transaction('masarifi_worker', null, action);
    }
    transaction(role, principal, action, repeatableRead = false) {
        return this.pool.withClient(async (client) => {
            await client.query(repeatableRead ? 'begin isolation level repeatable read' : 'begin');
            try {
                if (principal)
                    await client.query("select set_config('request.jwt.claims',$1,true)", [
                        JSON.stringify({
                            role: 'authenticated',
                            sub: principal.userId,
                            sid: principal.sessionId,
                            nativeRequest: principal.nativeRequest === true,
                        }),
                    ]);
                await client.query(role === 'masarifi_api'
                    ? 'set local role masarifi_api'
                    : 'set local role masarifi_worker');
                const value = await action(client);
                await client.query('commit');
                return value;
            }
            catch (error) {
                await client.query('rollback');
                throw mapped(error);
            }
        });
    }
};
exports.AiRepository = AiRepository;
exports.AiRepository = AiRepository = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [pool_service_1.PoolService])
], AiRepository);
