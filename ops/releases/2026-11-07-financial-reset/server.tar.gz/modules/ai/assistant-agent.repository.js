"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.AssistantAgentRepository = void 0;
const financial_worker_generation_1 = require("../platform/database/financial-worker-generation");
const common_1 = require("@nestjs/common");
const node_crypto_1 = require("node:crypto");
const pool_service_1 = require("../platform/database/pool.service");
const ai_gateway_1 = require("./ai.gateway");
let AssistantAgentRepository = class AssistantAgentRepository {
    pool;
    constructor(pool) {
        this.pool = pool;
    }
    claim(owner) {
        return this.call('select private.claim_assistant_agent_job($1,180) result', [owner]);
    }
    claimNext() {
        return this.call('select private.claim_next_assistant_agent_job(180) result', []);
    }
    authorizeDispatch(claim, route) {
        return this.call('select private.authorize_assistant_agent_dispatch($1::uuid,$2::uuid,$3::jsonb) result', [claim.id, claim.claimToken, JSON.stringify(route)], claim);
    }
    finish(claim, answer) {
        const content = answer.content.replace(/\n/gu, '\u2028');
        if (Buffer.byteLength(content) > 16384 ||
            Array.from(content).some((character) => character.charCodeAt(0) < 32 || character.charCodeAt(0) === 127))
            throw new ai_gateway_1.AiGatewayError('AI_SCHEMA_INVALID');
        return this.call('select private.finish_assistant_agent_job($1::uuid,$2::uuid,$3::jsonb) result', [claim.id, claim.claimToken, JSON.stringify({ ...answer, content, preview: null })], claim);
    }
    fail(claim, code, retry) {
        return this.call('select private.fail_assistant_agent_job($1::uuid,$2::uuid,$3,$4) result', [claim.id, claim.claimToken, code, retry], claim);
    }
    receipt(claim, receipt) {
        const generationHash = (0, node_crypto_1.createHash)('sha256').update(receipt.generationId).digest('hex');
        return this.record(claim, {
            generationHash,
            model: receipt.model,
            provider: receipt.provider,
            usage: receipt.usage,
            latencyMs: receipt.latencyMs,
            fallbackUsed: receipt.fallbackUsed,
        });
    }
    uncertainDispatch(claim) {
        return this.record(claim, { uncertain: true });
    }
    record(claim, receipt) {
        return this.call('select private.record_assistant_agent_receipt($1::uuid,$2::uuid,$3::jsonb) result', [claim.id, claim.claimToken, JSON.stringify(receipt)], claim);
    }
    call(sql, args, claim) {
        return this.pool.withClient(async (client) => {
            await client.query('begin');
            try {
                await client.query('set local role masarifi_worker');
                await client.query("select set_config('request.jwt.claims','{}',true)");
                if (claim)
                    await (0, financial_worker_generation_1.bindFinancialClaim)(client, 'assistant', claim.id, claim.claimToken);
                const response = await client.query(sql, args);
                await client.query('commit');
                const row = response.rows[0];
                if (!row)
                    throw new Error('AI_DATABASE_RESULT_MISSING');
                return row.result;
            }
            catch (error) {
                await client.query('rollback');
                throw error;
            }
        });
    }
};
exports.AssistantAgentRepository = AssistantAgentRepository;
exports.AssistantAgentRepository = AssistantAgentRepository = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [pool_service_1.PoolService])
], AssistantAgentRepository);
