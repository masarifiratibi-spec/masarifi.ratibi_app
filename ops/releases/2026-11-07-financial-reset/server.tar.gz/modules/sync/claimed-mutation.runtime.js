"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.prepareClaimedMutationRuntime = prepareClaimedMutationRuntime;
const financial_worker_generation_1 = require("../platform/database/financial-worker-generation");
const ledger_repository_1 = require("../ledger/ledger.repository");
const ledger_service_1 = require("../ledger/ledger.service");
const pool_service_1 = require("../platform/database/pool.service");
const reference_repository_1 = require("../reference/reference.repository");
const reference_service_1 = require("../reference/reference.service");
const security_repository_1 = require("../security/security.repository");
const claimed_mutation_executor_1 = require("./claimed-mutation.executor");
const sync_handlers_1 = require("./sync.handlers");
const sync_repository_1 = require("./sync.repository");
function assertConfiguration(config) {
    const positive = [
        'MASARIFI_DATABASE_POOL_MAX',
        'MASARIFI_SYNC_RETRY_BASE_SECONDS',
        'MASARIFI_SYNC_RETRY_MAX_SECONDS',
        'MASARIFI_SYNC_MAX_ATTEMPTS',
        'MASARIFI_RECENT_AUTH_MAX_AGE_SECONDS',
    ];
    const jitter = config.getRequired('MASARIFI_SYNC_RETRY_JITTER_MS');
    if (positive.some((key) => !Number.isSafeInteger(config.getRequired(key)) || config.getRequired(key) < 1) ||
        config.getRequired('MASARIFI_DATABASE_POOL_MAX') > 50 ||
        !Number.isSafeInteger(jitter) ||
        jitter < 0 ||
        config.getRequired('MASARIFI_PROCESS_KIND') !== 'worker' ||
        !config.getRequired('DATABASE_URL') ||
        config.getRequired('MASARIFI_SYNC_RETRY_MAX_SECONDS') <
            config.getRequired('MASARIFI_SYNC_RETRY_BASE_SECONDS'))
        throw new Error('EXACT_EXECUTOR_CONFIG_UNVERIFIED');
}
async function prepareClaimedMutationRuntime(workerConfig, apiConfig, workerId, verifiedImageSha256) {
    assertConfiguration(workerConfig);
    if (apiConfig?.getRequired('MASARIFI_PROCESS_KIND') !== 'api' ||
        !Number.isSafeInteger(apiConfig.getRequired('MASARIFI_DATABASE_POOL_MAX')) ||
        apiConfig.getRequired('MASARIFI_DATABASE_POOL_MAX') < 1 ||
        apiConfig.getRequired('MASARIFI_DATABASE_POOL_MAX') > 50 ||
        !Number.isSafeInteger(apiConfig.getRequired('MASARIFI_RECENT_AUTH_MAX_AGE_SECONDS')) ||
        apiConfig.getRequired('MASARIFI_RECENT_AUTH_MAX_AGE_SECONDS') < 1 ||
        !apiConfig.getRequired('DATABASE_URL') ||
        apiConfig.getRequired('DATABASE_URL') === workerConfig.getRequired('DATABASE_URL'))
        throw new Error('EXACT_EXECUTOR_API_CONFIG_UNVERIFIED');
    if (!/^[a-f0-9]{64}$/.test(verifiedImageSha256))
        throw new Error('EXACT_EXECUTOR_IMAGE_UNVERIFIED');
    let workerPool;
    let apiCommandPool;
    const close = async () => {
        const results = await Promise.allSettled([workerPool, apiCommandPool]
            .filter((pool) => pool !== undefined)
            .map((pool) => pool.onModuleDestroy()));
        if (results.some((result) => result.status === 'rejected'))
            throw new Error('EXACT_EXECUTOR_CLOSE_FAILED');
    };
    try {
        workerPool = new pool_service_1.PoolService(workerConfig);
        apiCommandPool = new pool_service_1.PoolService(apiConfig);
        const ledger = new ledger_service_1.LedgerService(new ledger_repository_1.LedgerRepository(apiCommandPool, apiConfig), new security_repository_1.SecurityRepository(apiCommandPool), apiConfig);
        const reference = new reference_service_1.ReferenceService(new reference_repository_1.ReferenceRepository(apiCommandPool), ledger);
        const queueRepository = new sync_repository_1.SyncRepository(workerPool);
        const apiRepository = new sync_repository_1.SyncRepository(apiCommandPool);
        const executor = new claimed_mutation_executor_1.ClaimedMutationExecutor({
            workerComplete: queueRepository.workerComplete.bind(queueRepository),
            retryMutation: queueRepository.retryMutation.bind(queueRepository),
            createConflict: queueRepository.createConflict.bind(queueRepository),
            conflictTarget: apiRepository.conflictTarget.bind(apiRepository),
        }, new sync_handlers_1.SyncHandlers(reference, ledger), workerConfig, workerId);
        return {
            normalPool: workerPool,
            apiCommandPool,
            imageSha256: verifiedImageSha256,
            executeClaim: async (row) => {
                const generation = await queueRepository.claimedGeneration(row.id, row.lease_token);
                return (0, financial_worker_generation_1.withClaimGeneration)(generation, () => executor.process((0, sync_repository_1.toClaimedMutation)(row)));
            },
            close,
        };
    }
    catch (error) {
        await close();
        throw error;
    }
}
