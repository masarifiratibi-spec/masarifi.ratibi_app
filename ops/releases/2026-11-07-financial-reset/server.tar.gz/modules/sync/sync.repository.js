"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.SyncRepository = void 0;
exports.toClaimedMutation = toClaimedMutation;
const financial_worker_generation_1 = require("../platform/database/financial-worker-generation");
const common_1 = require("@nestjs/common");
const pool_service_1 = require("../platform/database/pool.service");
function toClaimedMutation(row) {
    return {
        generation: row.generation,
        id: row.id,
        userId: row.user_id,
        deviceId: row.device_id,
        factorAgeSeconds: row.factor_age_seconds,
        authenticatedAt: row.authenticated_at != null
            ? new Date(row.authenticated_at).toISOString()
            : row.factor_age_seconds !== null && Number.isFinite(new Date(row.created_at).getTime())
                ? new Date(new Date(row.created_at).getTime() - row.factor_age_seconds * 1000).toISOString()
                : null,
        mutation: {
            operationId: row.operation_id,
            domain: row.domain,
            resourceType: row.resource_type,
            schemaVersion: row.schema_version,
            dependsOn: row.depends_on,
            operation: row.operation,
            resourceId: row.resource_id,
            baseVersion: row.base_version === null ? null : Number(row.base_version),
            payload: row.payload,
        },
        attemptCount: row.attempt_count,
        leaseToken: row.lease_token,
    };
}
let SyncRepository = class SyncRepository {
    pool;
    constructor(pool) {
        this.pool = pool;
    }
    transaction(principal, action, repeatableSnapshot = false) {
        return this.pool.withClient(async (client) => {
            await client.query(repeatableSnapshot ? 'begin isolation level repeatable read' : 'begin');
            try {
                await client.query("select set_config('request.jwt.claims',$1,true)", [
                    JSON.stringify({
                        role: 'authenticated',
                        sub: principal.userId,
                        sid: principal.sessionId,
                    }),
                ]);
                await client.query('set local role masarifi_api');
                const result = await action(client);
                await client.query('commit');
                return result;
            }
            catch (error) {
                await client.query('rollback');
                throw error;
            }
        });
    }
    assertActiveDevice(principal, deviceId) {
        return this.transaction(principal, async (client) => {
            await client.query('select private.assert_active_sync_device($1,$2)', [
                principal.userId,
                deviceId,
            ]);
        });
    }
    recordIssuedCursor(principal, deviceId, domain, position) {
        return this.transaction(principal, async (client) => {
            await client.query('select private.record_sync_cursor_issued($1,$2,$3,$4)', [
                principal.userId,
                deviceId,
                domain,
                position.toString(),
            ]);
        });
    }
    async claimBatch(principal, keyHash, requestHash, leaseSeconds) {
        return this.transaction(principal, async (client) => {
            const row = (await client.query(`select * from private.claim_sync_idempotency_key(
            $1,'sync.mutations',$2,$3,$4::interval
          )`, [principal.userId, keyHash, requestHash, `${String(leaseSeconds)} seconds`])).rows[0];
            if (!row)
                throw new Error('SYNC_IDEMPOTENCY_UNAVAILABLE');
            return {
                outcome: row.outcome,
                responseStatus: row.response_status,
                responseBody: row.response_body,
                retryAfterSeconds: row.retry_after_seconds,
                leaseToken: row.lease_token,
            };
        });
    }
    completeBatch(principal, completion, status, body) {
        return this.transaction(principal, async (client) => {
            await client.query(`select private.complete_sync_idempotency_key(
          $1,'sync.mutations',$2,$3,$4,$5,$6::jsonb,null
        )`, [
                principal.userId,
                completion.keyHash,
                completion.requestHash,
                completion.leaseToken,
                status,
                JSON.stringify(body),
            ]);
        });
    }
    async receiveMutation(principal, deviceId, mutation, payloadHash) {
        return this.transaction(principal, async (client) => {
            const row = (await client.query(`select * from private.receive_client_mutation(
            $1,$2,$3,$4,$5,$6,$7,$8::uuid[],$9,$10,$11,$12,$13::jsonb
          )`, [
                principal.userId,
                deviceId,
                principal.factorAgeSeconds,
                mutation.operationId,
                mutation.domain,
                mutation.resourceType,
                mutation.schemaVersion,
                mutation.dependsOn,
                mutation.operation,
                mutation.resourceId,
                mutation.baseVersion,
                payloadHash,
                JSON.stringify(mutation.payload),
            ])).rows[0];
            if (!row)
                throw new Error('SYNC_RECEIPT_UNAVAILABLE');
            return {
                outcome: row.outcome,
                mutationId: row.mutation_id,
                status: row.status,
                result: row.result,
                error: row.error,
            };
        });
    }
    bootstrap(principal, domains, after, limit, boundary) {
        return this.transaction(principal, async (client) => {
            const result = [];
            for (const domain of domains) {
                const table = domain;
                const owner = domain === 'categories' ? '(user_id=$1 or user_id is null)' : 'user_id=$1';
                const snapshot = domain === 'transactions'
                    ? `jsonb_build_object(
                'id',source.id,'kind',source.kind,'status',source.status,
                'amount_minor',source.amount_minor,'fee_minor',source.fee_minor,
                'currency_code',source.currency_code,'category_id',source.category_id,
                'title',source.title,'merchant',source.merchant,
                'payment_method',source.payment_method,'note',source.note,
                'occurred_at',source.occurred_at,'source',source.source,
                'reverses_transaction_id',source.reverses_transaction_id,
                'deleted_at',source.deleted_at,'undo_expires_at',source.undo_expires_at,
                'created_at',source.created_at,'updated_at',source.updated_at,
                'version',source.version,'postings',coalesce((
                select jsonb_agg(jsonb_build_object(
                  'account_id',p.account_id,'amount_minor',p.amount_minor,
                  'clearing_state',p.clearing_state,'posting_role',p.posting_role,
                  'occurred_at',p.occurred_at
                ) order by p.posting_role,p.id)
                from public.transaction_postings p where p.transaction_id=source.id
              ),'[]'::jsonb))`
                    : domain === 'accounts'
                        ? `jsonb_build_object(
                  'id',source.id,'name',source.name,'type',source.type,
                  'currency_code',source.currency_code,
                  'institution_name',source.institution_name,'last_four',source.last_four,
                  'credit_limit_minor',source.credit_limit_minor,'is_default',source.is_default,
                  'icon_key',source.icon_key,'color_key',source.color_key,'notes',source.notes,
                  'status',source.status,'sort_order',source.sort_order,
                  'include_in_totals',source.include_in_totals,'opened_at',source.opened_at,
                  'automatic_tracking_enabled',source.automatic_tracking_enabled,
                  'statement_day',source.statement_day,
                  'payment_due_day',source.payment_due_day,
                  'monthly_interest_rate_basis_points',source.monthly_interest_rate_basis_points,
                  'minimum_payment_minor',source.minimum_payment_minor,
                  'closed_at',source.closed_at,'deleted_at',source.deleted_at,
                  'created_at',source.created_at,'updated_at',source.updated_at,
                  'version',source.version)`
                        : `jsonb_build_object(
                  'id',source.id,'parent_id',source.parent_id,
                  'merged_into_id',source.merged_into_id,'kind',source.kind,
                  'label_ar',source.label_ar,'label_en',source.label_en,
                  'icon',source.icon,'color',source.color,'system_key',source.system_key,
                  'sort_order',source.sort_order,'active',source.active,
                  'deleted_at',source.deleted_at,'created_at',source.created_at,
                  'updated_at',source.updated_at,'version',source.version)`;
                const cursor = boundary ??
                    BigInt((await client.query('select * from private.get_sync_bounds($1,$2)', [principal.userId, domain])).rows[0]?.current_cursor ?? '0');
                const items = await client.query(`select source.id::text id,${snapshot} snapshot from public.${table} source
           where ${owner} and ($2::uuid is null or source.id>$2::uuid)
           order by source.id limit $3`, [principal.userId, after, limit + 1]);
                result.push({
                    domain,
                    position: cursor,
                    items: items.rows.slice(0, limit),
                    hasMore: items.rows.length > limit,
                });
            }
            return result;
        }, true);
    }
    delta(principal, domain, position, limit) {
        return this.transaction(principal, async (client) => {
            const bounds = await client.query('select * from private.get_sync_bounds($1,$2)', [principal.userId, domain]);
            const changes = await client.query('select * from private.get_sync_delta($1,$2,$3,$4)', [
                principal.userId,
                domain,
                position.toString(),
                limit + 1,
            ]);
            return {
                oldest: BigInt(bounds.rows[0]?.oldest ?? '0'),
                current: BigInt(bounds.rows[0]?.current_cursor ?? '0'),
                changes: changes.rows.map((row) => ({
                    position: BigInt(row.position),
                    resourceId: row.resource_id,
                    resourceType: row.resource_type,
                    operation: row.operation,
                    version: Number(row.resource_version),
                    snapshot: row.snapshot,
                    deletedAt: row.deleted_at instanceof Date ? row.deleted_at.toISOString() : row.deleted_at,
                })),
            };
        }, true);
    }
    acknowledge(principal, deviceId, domain, position, lastMutationId) {
        return this.transaction(principal, async (client) => {
            const row = (await client.query('select * from private.ack_client_sync_cursor($1,$2,$3,$4,$5)', [principal.userId, deviceId, domain, position.toString(), lastMutationId])).rows[0];
            if (!row)
                throw new Error('SYNC_ACK_UNAVAILABLE');
            return {
                position: BigInt(row.last_cursor),
                acknowledgedAt: row.last_synced_at.toISOString(),
            };
        });
    }
    listConflicts(principal, status, after, limit) {
        return this.transaction(principal, async (client) => {
            const rows = await client.query(`select * from public.transaction_conflicts
         where user_id=$1 and status=$2
           and ($3::timestamptz is null or (created_at,id)>($3,$4::uuid))
         order by created_at,id limit $5`, [principal.userId, status, after?.createdAt ?? null, after?.id ?? null, limit + 1]);
            return rows.rows.map((row) => this.conflict(row));
        });
    }
    getConflict(principal, conflictId) {
        return this.transaction(principal, async (client) => {
            const row = (await client.query('select * from public.transaction_conflicts where user_id=$1 and id=$2', [principal.userId, conflictId])).rows[0];
            return row ? this.conflict(row) : null;
        });
    }
    resolveConflict(principal, conflictId, resolution, payload, requestId, keyHash, requestHash) {
        return this.transaction(principal, async (client) => {
            const row = (await client.query('select (private.resolve_transaction_conflict($1,$2,$3,$4::jsonb,$5,$6,$7)).*', [
                principal.userId,
                conflictId,
                resolution,
                payload ? JSON.stringify(payload) : null,
                requestId,
                keyHash,
                requestHash,
            ])).rows[0];
            if (!row)
                throw new Error('SYNC_CONFLICT_UNAVAILABLE');
            return this.conflict(row);
        });
    }
    createConflict(userId, input, leaseToken) {
        return this.pool.withClient(async (client) => {
            await client.query('begin');
            try {
                await client.query('set local role masarifi_worker');
                const row = (await client.query(`select (private.create_transaction_conflict(
              $1,$2,$3,$4,$5,$6,$7::jsonb,$8::jsonb
            )).*`, [
                    userId,
                    input.mutationId,
                    input.transactionId,
                    input.serverVersion,
                    input.clientVersion,
                    input.fields,
                    JSON.stringify(input.serverSnapshot),
                    JSON.stringify(input.clientSnapshot),
                ])).rows[0];
                if (!row)
                    throw new Error('SYNC_CONFLICT_UNAVAILABLE');
                await client.query("select private.complete_client_mutation($1,$2,'conflict',$3::jsonb,null)", [input.mutationId, leaseToken, JSON.stringify({ conflictId: row.id })]);
                await client.query('commit');
                return this.conflict(row);
            }
            catch (error) {
                await client.query('rollback');
                throw error;
            }
        });
    }
    async claimMutations(workerId, limit, leaseSeconds) {
        const rows = await this.pool.withClient(async (client) => {
            await client.query('begin');
            try {
                await client.query('set local role masarifi_worker');
                const result = await client.query("select w.*,private.bind_financial_worker_generation('sync',w.id,w.lease_token)::text generation from private.claim_client_mutations($1,$2,$3) w", [workerId, limit, leaseSeconds]);
                await client.query('commit');
                return result.rows;
            }
            catch (error) {
                await client.query('rollback');
                throw error;
            }
        });
        return rows.map(toClaimedMutation);
    }
    async claimedGeneration(id, token) {
        return this.pool.withClient(async (client) => {
            await client.query('begin');
            try {
                await client.query('set local role masarifi_worker');
                const generation = await (0, financial_worker_generation_1.bindFinancialClaim)(client, 'sync', id, token);
                await client.query('commit');
                return generation;
            }
            catch (error) {
                await client.query('rollback');
                throw error;
            }
        });
    }
    workerComplete(mutationId, leaseToken, status, result, error) {
        return this.workerQuery('select private.complete_client_mutation($1,$2,$3,$4::jsonb,$5::jsonb)', [
            mutationId,
            leaseToken,
            status,
            result ? JSON.stringify(result) : null,
            error ? JSON.stringify(error) : null,
        ]);
    }
    retryMutation(mutationId, leaseToken, nextAttemptAt, errorCode) {
        return this.workerQuery('select private.retry_client_mutation($1,$2,$3,$4)', [
            mutationId,
            leaseToken,
            nextAttemptAt,
            errorCode,
        ]);
    }
    async conflictTarget(principal, transactionId) {
        return this.transaction(principal, async (client) => {
            const row = (await client.query(`select version::text,jsonb_build_object(
            'id',t.id,'kind',t.kind,'status',t.status,
            'amount_minor',t.amount_minor,'fee_minor',t.fee_minor,
            'currency_code',t.currency_code,'category_id',t.category_id,
            'title',t.title,'merchant',t.merchant,'payment_method',t.payment_method,
            'note',t.note,'occurred_at',t.occurred_at,'source',t.source,
            'reverses_transaction_id',t.reverses_transaction_id,
            'deleted_at',t.deleted_at,'undo_expires_at',t.undo_expires_at,
            'created_at',t.created_at,'updated_at',t.updated_at,'version',t.version
          ) snapshot from public.transactions t where id=$1 and user_id=$2`, [transactionId, principal.userId])).rows[0];
            return row ? { version: Number(row.version), snapshot: row.snapshot } : null;
        });
    }
    async runMaintenance(job, retentionDays) {
        let affected = 0;
        await this.pool.withClient(async (client) => {
            await client.query('begin');
            try {
                await client.query('set local role masarifi_worker');
                affected =
                    (await client.query('select private.run_sync_maintenance($1,$2) affected', [job, retentionDays])).rows[0]?.affected ?? 0;
                await client.query('commit');
            }
            catch (error) {
                await client.query('rollback');
                throw error;
            }
        });
        return affected;
    }
    async workerQuery(sql, values) {
        await this.pool.withClient(async (client) => {
            await client.query('begin');
            try {
                await client.query('set local role masarifi_worker');
                await client.query(sql, values);
                await client.query('commit');
            }
            catch (error) {
                await client.query('rollback');
                throw error;
            }
        });
    }
    conflict(row) {
        return {
            id: row.id,
            transactionId: row.transaction_id,
            clientMutationId: row.client_mutation_id,
            serverVersion: Number(row.server_version),
            clientVersion: Number(row.client_version),
            conflictFields: row.conflict_fields,
            serverSnapshot: row.server_snapshot,
            clientSnapshot: row.client_snapshot,
            status: row.status,
            resolution: row.resolution,
            resolutionPayload: row.resolution_payload,
            createdAt: row.created_at.toISOString(),
            resolvedAt: row.resolved_at?.toISOString() ?? null,
        };
    }
};
exports.SyncRepository = SyncRepository;
exports.SyncRepository = SyncRepository = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [pool_service_1.PoolService])
], SyncRepository);
