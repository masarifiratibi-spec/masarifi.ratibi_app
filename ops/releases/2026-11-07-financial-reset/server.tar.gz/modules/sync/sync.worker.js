"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var SyncWorker_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.SyncWorker = void 0;
const financial_worker_generation_1 = require("../platform/database/financial-worker-generation");
const node_crypto_1 = require("node:crypto");
const common_1 = require("@nestjs/common");
const platform_config_service_1 = require("../platform/config/platform-config.service");
const sync_handlers_1 = require("./sync.handlers");
const claimed_mutation_executor_1 = require("./claimed-mutation.executor");
const sync_observability_1 = require("./sync.observability");
const sync_repository_1 = require("./sync.repository");
const sync_command_runtime_1 = require("./sync-command.runtime");
let SyncWorker = SyncWorker_1 = class SyncWorker {
    repository;
    config;
    logger = new common_1.Logger(SyncWorker_1.name);
    active;
    timer;
    stopped = false;
    lastMaintenance = 0;
    workerId = `sync-${(0, node_crypto_1.randomUUID)()}`;
    executor;
    constructor(repository, handlers, config, commands) {
        this.repository = repository;
        this.config = config;
        this.executor = new claimed_mutation_executor_1.ClaimedMutationExecutor({
            workerComplete: (...args) => repository.workerComplete(...args),
            retryMutation: (...args) => repository.retryMutation(...args),
            createConflict: (...args) => repository.createConflict(...args),
            conflictTarget: (...args) => commands ? commands.conflictTarget(...args) : repository.conflictTarget(...args),
        }, handlers, config, this.workerId);
    }
    runOnce() {
        if (this.active)
            return this.active;
        const running = this.execute();
        this.active = running;
        void running
            .finally(() => {
            if (this.active === running)
                this.active = undefined;
        })
            .catch(() => undefined);
        return running;
    }
    async runJob(job) {
        if (job === 'sync-mutations.retry') {
            const claimed = await this.repository.claimMutations(this.workerId, this.config.getRequired('MASARIFI_SYNC_BATCH_SIZE'), this.config.getRequired('MASARIFI_SYNC_LEASE_SECONDS'));
            for (const mutation of claimed) {
                await (0, financial_worker_generation_1.withClaimGeneration)(mutation.generation, () => this.executor.process(mutation));
            }
            return claimed.length;
        }
        return this.repository.runMaintenance(job, this.config.getRequired('MASARIFI_SYNC_RETENTION_DAYS'));
    }
    start() {
        if (this.stopped || this.timer)
            return;
        void this.runOnce().catch(() => undefined);
        this.timer = setInterval(() => void this.runOnce().catch(() => undefined), this.config.getRequired('MASARIFI_SYNC_POLL_MS'));
        this.timer.unref();
    }
    async stop() {
        this.stopped = true;
        if (this.timer)
            clearInterval(this.timer);
        this.timer = undefined;
        await this.active?.catch(() => undefined);
    }
    async onModuleDestroy() {
        await this.stop();
    }
    retryDelayMs(mutationId, attempt) {
        return this.executor.retryDelayMs(mutationId, attempt);
    }
    async execute() {
        await this.measured('sync-mutations.retry');
        if (Date.now() - this.lastMaintenance < 60_000)
            return;
        for (const job of ['idempotency.cleanup', 'sync-state.cleanup', 'conflicts.expire'])
            await this.measured(job);
        this.lastMaintenance = Date.now();
    }
    async measured(job) {
        try {
            await this.runJob(job);
            (0, sync_observability_1.recordSyncWorker)(job, 'success');
            (0, sync_observability_1.logSyncEvent)(this.logger, 'worker.completed', { outcome: 'success', status: job });
        }
        catch (error) {
            (0, sync_observability_1.recordSyncWorker)(job, 'failure');
            (0, sync_observability_1.logSyncEvent)(this.logger, 'worker.failed', { outcome: 'failure', status: job });
            throw error;
        }
    }
};
exports.SyncWorker = SyncWorker;
exports.SyncWorker = SyncWorker = SyncWorker_1 = __decorate([
    (0, common_1.Injectable)(),
    __param(3, (0, common_1.Optional)()),
    __metadata("design:paramtypes", [sync_repository_1.SyncRepository,
        sync_handlers_1.SyncHandlers,
        platform_config_service_1.PlatformConfigService,
        sync_command_runtime_1.SyncCommandRuntime])
], SyncWorker);
