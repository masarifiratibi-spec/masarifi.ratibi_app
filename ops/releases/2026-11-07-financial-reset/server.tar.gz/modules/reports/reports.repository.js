"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ReportsRepository = void 0;
const financial_worker_generation_1 = require("../platform/database/financial-worker-generation");
const reports_admin_1 = require("./reports.admin");
const common_1 = require("@nestjs/common");
const idempotency_1 = require("../ledger/idempotency");
const pool_service_1 = require("../platform/database/pool.service");
const platform_config_service_1 = require("../platform/config/platform-config.service");
const reports_period_1 = require("./reports.period");
const reports_schemas_1 = require("./reports.schemas");
const reports_events_1 = require("./reports.events");
function safeInteger(value) {
    const parsed = Number(value);
    if (!Number.isSafeInteger(parsed))
        throw new common_1.HttpException({ code: 'REPORT_VALUE_OUT_OF_RANGE' }, 503);
    return parsed;
}
function mapDatabaseError(error) {
    if (error instanceof common_1.HttpException)
        return error;
    const code = error.code;
    const message = error instanceof Error ? error.message : '';
    if (message.includes('REPORT_QUOTA_EXCEEDED'))
        return new common_1.HttpException({ code: 'REPORT_QUOTA_EXCEEDED' }, 429);
    if (code === '57014')
        return new common_1.HttpException({ code: 'REPORT_QUERY_TIMEOUT' }, 503);
    if (code === '42501')
        return new common_1.HttpException({ code: 'FORBIDDEN' }, 403);
    if (code === 'P0002')
        return new common_1.HttpException({ code: 'REPORT_NOT_FOUND' }, 404);
    if (code === '23505')
        return new common_1.HttpException({ code: 'REPORT_SNAPSHOT_CONFLICT' }, 409);
    if (code === '23503')
        return new common_1.HttpException({ code: 'REPORT_SCHEDULE_IN_USE' }, 409);
    if (code === '40001')
        return new common_1.HttpException({ code: 'REPORT_SCHEDULE_CONFLICT' }, 409);
    return new common_1.HttpException({ code: 'REPORT_UNAVAILABLE' }, 503);
}
let ReportsRepository = class ReportsRepository {
    pool;
    config;
    constructor(pool, config) {
        this.pool = pool;
        this.config = config;
    }
    async getContext(principal) {
        return this.withApiSnapshot(principal, async (client) => {
            const row = (await client.query(`select p.timezone,coalesce(max(b.ledger_version),0)::bigint ledger_version
           from public.profiles p left join public.accounts a on a.user_id=p.id
           left join public.account_balances b on b.account_id=a.id
           where p.id=$1 group by p.id,p.timezone`, [principal.userId])).rows[0];
            if (!row)
                throw new common_1.HttpException({ code: 'NOT_FOUND' }, 404);
            return { timezone: row.timezone, ledgerVersion: safeInteger(row.ledger_version) };
        });
    }
    async getSummary(principal, reportType, period, currency, requestId, accountIds) {
        void requestId;
        try {
            return await this.withApiSnapshot(principal, async (client) => {
                if (accountIds) {
                    const owned = await client.query('select id from public.accounts where user_id=$1 and id=any($2::uuid[])', [principal.userId, accountIds]);
                    if (owned.rowCount !== new Set(accountIds).size || accountIds.length === 0)
                        throw new common_1.HttpException({ code: 'REPORT_ACCOUNT_NOT_FOUND' }, 404);
                }
                return this.readSummary(client, principal.userId, reportType, period, currency, accountIds);
            });
        }
        catch (error) {
            throw mapDatabaseError(error);
        }
    }
    async getHome(principal, period, currency, requestId) {
        void requestId;
        return this.withApiSnapshot(principal, async (client) => {
            const summary = await this.readSummary(client, principal.userId, 'financial_summary', period, currency);
            const balances = (await client.query(`select a.id account_id,a.currency_code,b.confirmed_minor,b.pending_minor
           from public.accounts a join public.account_balances b on b.account_id=a.id
           where a.user_id=$1 and a.status='active' and ($2::char(3) is null or a.currency_code=$2)
           order by a.id limit 100`, [principal.userId, currency])).rows.map((row) => ({
                accountId: row.account_id,
                confirmed: {
                    amountMinor: safeInteger(row.confirmed_minor),
                    currency: row.currency_code.trim(),
                },
                pending: {
                    amountMinor: safeInteger(row.pending_minor),
                    currency: row.currency_code.trim(),
                },
            }));
            const planning = await this.readPlanning(client, principal.userId, period, currency);
            const recentItems = (await client.query(`select id,kind,amount_minor,currency_code,occurred_at from public.transactions
           where user_id=$1 and status='confirmed' and deleted_at is null
             and ($2::char(3) is null or currency_code=$2)
           order by occurred_at desc,id desc limit 25`, [principal.userId, currency])).rows.map((row) => ({
                id: row.id,
                kind: row.kind,
                amount: { amountMinor: safeInteger(row.amount_minor), currency: row.currency_code.trim() },
                occurredAt: row.occurred_at.toISOString(),
            }));
            return { ...summary, balances, planning, recentItems };
        });
    }
    async captureSnapshot(principal, command, idempotencyKey, requestId) {
        try {
            return await this.pool.withClient(async (client) => {
                const keyHash = (0, idempotency_1.hashIdempotencyKey)(idempotencyKey);
                await client.query('begin');
                try {
                    await this.setApiContext(client, principal);
                    await client.query('select private.reserve_user_job_quota($1,$2,$3)', [
                        principal.userId,
                        'report_generation',
                        keyHash,
                    ]);
                    await client.query('commit');
                }
                catch (error) {
                    await client.query('rollback');
                    throw error;
                }
                await client.query('begin isolation level repeatable read');
                try {
                    await this.setApiContext(client, principal);
                    const requestHash = (0, idempotency_1.hashNormalizedCommand)(command);
                    const claim = (await client.query('select * from private.claim_idempotency_key($1,$2,$3,$4,$5::interval)', [principal.userId, 'reports.create', keyHash, requestHash, '2 minutes'])).rows[0];
                    if (!claim)
                        throw new Error('IDEMPOTENCY_REPLAY_UNAVAILABLE');
                    if (claim.outcome === 'hash_mismatch')
                        throw new common_1.HttpException({ code: 'IDEMPOTENCY_KEY_REUSED' }, 409);
                    if (claim.outcome === 'in_progress')
                        throw new common_1.HttpException({ code: 'IDEMPOTENCY_IN_PROGRESS' }, 409);
                    if (claim.outcome === 'replay') {
                        if (!claim.response_body || claim.response_status !== 202)
                            throw new Error('IDEMPOTENCY_REPLAY_UNAVAILABLE');
                        await client.query('commit');
                        return claim.response_body;
                    }
                    const context = (await client.query(`select p.timezone,coalesce(u.default_currency,'SAR') currency from public.profiles p
               left join public.user_preferences u on u.user_id=p.id where p.id=$1`, [principal.userId])).rows[0];
                    if (!context)
                        throw new common_1.HttpException({ code: 'NOT_FOUND' }, 404);
                    if (command.timezone && command.timezone !== context.timezone)
                        throw new common_1.HttpException({ code: 'REPORT_TIMEZONE_CHANGED' }, 409);
                    if (command.accountIds) {
                        const owned = await client.query('select id from public.accounts where user_id=$1 and id=any($2::uuid[])', [principal.userId, command.accountIds]);
                        if (owned.rowCount !== new Set(command.accountIds).size)
                            throw new common_1.HttpException({ code: 'REPORT_ACCOUNT_NOT_FOUND' }, 404);
                    }
                    const currency = command.currency ?? context.currency.trim();
                    const allowedCurrency = await client.query('select code from public.currencies where code=$1 and enabled', [currency]);
                    if (!allowedCurrency.rowCount)
                        throw new common_1.HttpException({ code: 'INVALID_CURRENCY' }, 400);
                    const days = Math.floor((Date.parse(`${command.periodEnd}T00:00:00Z`) -
                        Date.parse(`${command.periodStart}T00:00:00Z`)) /
                        86_400_000) + 1;
                    const kind = days <= 31
                        ? 'monthly'
                        : days <= 93
                            ? 'three_months'
                            : days <= 186
                                ? 'half_year'
                                : 'annual';
                    const nextDay = new Date(Date.parse(`${command.periodEnd}T00:00:00Z`) + 86_400_000)
                        .toISOString()
                        .slice(0, 10);
                    const period = {
                        kind,
                        timezone: context.timezone,
                        startDate: command.periodStart,
                        endDate: command.periodEnd,
                        startInstant: (0, reports_period_1.zonedDateTimeToInstant)(command.periodStart, '00:00', context.timezone),
                        endExclusiveInstant: (0, reports_period_1.zonedDateTimeToInstant)(nextDay, '00:00', context.timezone),
                    };
                    const summary = await this.readSummary(client, principal.userId, command.type, period, currency, command.accountIds);
                    const content = await this.reportContent(client, {
                        userId: principal.userId,
                        reportType: command.type,
                        period,
                        currency,
                        accountIds: command.accountIds,
                        summary,
                    });
                    const snapshot = (0, reports_schemas_1.parseReportSnapshot)({
                        schemaVersion: 1,
                        generatedAt: summary.metadata.generatedAt,
                        ledgerVersion: summary.metadata.ledgerVersion,
                        reportType: command.type,
                        period: {
                            startDate: period.startDate,
                            endDate: period.endDate,
                            timezone: period.timezone,
                            kind,
                        },
                        format: command.format,
                        delivery: command.delivery,
                        currencyCode: currency,
                        dataState: content.dataState,
                        evidence: summary.metadata.evidence,
                        summary: {
                            ...content.summary,
                            accountScope: command.accountIds
                                ? `Selected accounts (${String(command.accountIds.length)})`
                                : 'All accounts',
                        },
                        breakdowns: content.breakdowns,
                        detailedRows: content.detailedRows,
                    }, this.config?.get('MASARIFI_REPORT_MAX_BYTES') ?? 52_428_800);
                    const retentionHours = this.config?.get('MASARIFI_REPORT_RETENTION_HOURS') ?? 24;
                    const expiresAt = new Date(Date.now() + retentionHours * 3_600_000).toISOString();
                    const captured = (await client.query('select * from private.capture_report_snapshot($1,$2,$3::date,$4::date,$5,$6::jsonb,$7::uuid,$8::timestamptz)', [
                        principal.userId,
                        command.type,
                        command.periodStart,
                        command.periodEnd,
                        summary.metadata.ledgerVersion,
                        JSON.stringify(snapshot),
                        null,
                        expiresAt,
                    ])).rows[0];
                    if (!captured)
                        throw new Error('REPORT_CAPTURE_FAILED');
                    const response = {
                        attemptId: captured.id,
                        status: captured.delivery_status,
                        ledgerVersion: summary.metadata.ledgerVersion,
                        schemaVersion: 1,
                        generatedAt: summary.metadata.generatedAt,
                    };
                    await client.query('select private.complete_idempotency_key($1,$2,$3,$4,$5,$6::jsonb,$7)', [
                        principal.userId,
                        'reports.create',
                        keyHash,
                        requestHash,
                        202,
                        JSON.stringify(response),
                        captured.id,
                    ]);
                    await client.query('commit');
                    void requestId;
                    return response;
                }
                catch (error) {
                    await client.query('rollback');
                    throw error;
                }
            });
        }
        catch (error) {
            throw mapDatabaseError(error);
        }
    }
    async getAttempt(principal, attemptId, requestId) {
        const rows = await this.withApiSnapshot(principal, async (client) => (await client.query('select * from private.read_report_output($1,$2::uuid)', [
            principal.userId,
            attemptId,
        ])).rows);
        const row = rows[0];
        if (!row)
            throw new common_1.HttpException({ code: 'REPORT_NOT_FOUND' }, 404);
        return this.attempt(row, requestId, true);
    }
    async getAdminReportCounts(principal, platform, days) {
        return this.withApiSnapshot(principal, async (client) => {
            const row = (await client.query('select private.read_admin_report_measurements($1,$2) value', [platform, days])).rows[0];
            if (!row)
                throw new common_1.HttpException({ code: 'REPORT_UNAVAILABLE' }, 503);
            return row.value;
        });
    }
    async recordMobileActivity(principal, platform) {
        try {
            await this.pool.withClient(async (client) => {
                await client.query('begin');
                try {
                    await this.setApiContext(client, principal);
                    await client.query('select private.record_mobile_activity($1)', [platform]);
                    await client.query('commit');
                }
                catch (error) {
                    await client.query('rollback');
                    throw error;
                }
            });
        }
        catch (error) {
            throw mapDatabaseError(error);
        }
    }
    async getAdminOverviewActivity(principal, query) {
        const rows = await this.withApiSnapshot(principal, async (client) => (await client.query('select * from private.read_admin_overview_activity($1,$2,$3,$4)', [query.platform, query.days, (query.page - 1) * query.pageSize, query.pageSize])).rows);
        return {
            items: rows.map((row) => ({
                id: row.id,
                eventType: row.event_type,
                summary: row.summary,
                occurredAt: row.occurred_at.toISOString(),
                platformScope: row.platform_scope,
                permission: row.permission,
                ...(row.destination ? { destination: row.destination } : {}),
            })),
            totalItems: safeInteger(rows[0]?.total_count ?? '0'),
        };
    }
    async getSupportedFinancialReport(principal, userId, days, observedAt) {
        return this.withApiSnapshot(principal, async (client) => {
            const row = (await client.query('select private.read_supported_financial_report_relative($1,$2,$3::timestamptz) value', [userId, days, observedAt.toISOString()])).rows[0];
            if (!row)
                throw new common_1.HttpException({ code: 'REPORT_NOT_FOUND' }, 404);
            return row.value;
        });
    }
    async getAdminActivityExport(principal, platform, days) {
        return this.withApiSnapshot(principal, async (client) => {
            const measurement = (await client.query('select private.read_admin_report_measurements($1,$2) value', [platform, days])).rows[0]?.value;
            if (!measurement?.observedAt)
                throw new common_1.HttpException({ code: 'REPORT_UNAVAILABLE' }, 503);
            const rows = (await client.query('select * from private.read_admin_overview_activity_at($1,$2,10001,$3::timestamptz)', [platform, days, measurement.observedAt])).rows;
            if (rows.length > 10000)
                throw new common_1.HttpException({ code: 'REPORT_LIMIT_EXCEEDED' }, 413);
            return {
                observation: (0, reports_admin_1.adminObservation)(measurement),
                items: rows.map((row) => ({
                    id: row.id,
                    eventType: row.event_type,
                    summary: row.summary,
                    occurredAt: row.occurred_at.toISOString(),
                    platformScope: row.platform_scope,
                    permission: row.permission,
                    ...(row.destination ? { destination: row.destination } : {}),
                })),
            };
        });
    }
    captureAdminExport(principal, command, snapshot, idempotencyKey, requestId) {
        return this.scheduleMutation(principal, 'reports.admin.export', idempotencyKey, command, 202, requestId, async (client) => {
            await client.query("select private.assert_admin_permission('privacy.exports.manage')");
            const retentionHours = this.config?.get('MASARIFI_REPORT_RETENTION_HOURS') ?? 24;
            const expiresAt = new Date(Date.now() + retentionHours * 3_600_000).toISOString();
            const row = (await client.query('select * from private.capture_report_snapshot($1,$2,$3::date,$4::date,$5,$6::jsonb,$7::uuid,$8::timestamptz)', [
                principal.userId,
                snapshot.reportType,
                snapshot.period.startDate,
                snapshot.period.endDate,
                snapshot.ledgerVersion,
                JSON.stringify(snapshot),
                null,
                expiresAt,
            ])).rows[0];
            if (!row)
                throw new Error('REPORT_CAPTURE_FAILED');
            await client.query('select audit.append_event($1,$2,$3,$4,$5,$6,$7,$8,$9,$10::jsonb)', [
                principal.userId,
                'admin',
                'report.export_requested',
                'report_attempt',
                row.id,
                null,
                null,
                typeof command.supportReason === 'string'
                    ? command.supportReason
                    : 'Admin aggregate export',
                requestId,
                JSON.stringify({
                    exportType: command.exportType,
                    platform: command.platform,
                    period: command.period,
                }),
            ]);
            return {
                attemptId: row.id,
                status: row.delivery_status,
                ledgerVersion: snapshot.ledgerVersion,
                schemaVersion: 1,
                generatedAt: snapshot.generatedAt,
            };
        });
    }
    async listAttempts(principal, query, requestId) {
        const cursor = this.decodeCursor(query.cursor);
        const rows = await this.withApiSnapshot(principal, async (client) => {
            const read = async (after, limit) => (await client.query('select * from private.list_report_outputs($1,$2::timestamptz,$3::uuid,$4,$5::uuid,$6)', [
                principal.userId,
                after?.createdAt ?? null,
                after?.id ?? null,
                limit,
                query.scheduleId,
                query.status,
            ])).rows;
            const page = await read(cursor, Math.min(query.limit + 1, 100));
            const last = page.at(-1);
            if (query.limit === 100 && page.length === 100 && last)
                page.push(...(await read({ createdAt: last.requested_at.toISOString(), id: last.id }, 1)));
            return page;
        });
        const more = rows.length > query.limit;
        const items = rows.slice(0, query.limit);
        const last = items.at(-1);
        return {
            items: items.map((row) => this.attempt(row, requestId, false)),
            nextCursor: more && last
                ? Buffer.from(JSON.stringify({ createdAt: last.requested_at.toISOString(), id: last.id })).toString('base64url')
                : null,
            requestId,
        };
    }
    async retryDelivery(principal, attemptId, idempotencyKey, requestId) {
        const command = { attemptId };
        return this.pool.withClient(async (client) => {
            await client.query('begin');
            try {
                await this.setApiContext(client, principal);
                const keyHash = (0, idempotency_1.hashIdempotencyKey)(idempotencyKey), requestHash = (0, idempotency_1.hashNormalizedCommand)(command);
                const claim = (await client.query('select * from private.claim_idempotency_key($1,$2,$3,$4,$5::interval)', [principal.userId, 'reports.delivery.retry', keyHash, requestHash, '2 minutes'])).rows[0];
                if (claim?.outcome === 'replay' && claim.response_body) {
                    await client.query('commit');
                    return claim.response_body;
                }
                if (claim?.outcome !== 'new')
                    throw new common_1.HttpException({
                        code: claim?.outcome === 'hash_mismatch'
                            ? 'IDEMPOTENCY_KEY_REUSED'
                            : 'IDEMPOTENCY_IN_PROGRESS',
                    }, 409);
                const status = (await client.query('select private.retry_report_delivery($1,$2::uuid)', [principal.userId, attemptId])).rows[0]?.retry_report_delivery;
                const response = { attemptId, status, schemaVersion: 1 };
                await client.query('select private.complete_idempotency_key($1,$2,$3,$4,$5,$6::jsonb,$7)', [
                    principal.userId,
                    'reports.delivery.retry',
                    keyHash,
                    requestHash,
                    202,
                    JSON.stringify(response),
                    attemptId,
                ]);
                await client.query('commit');
                void requestId;
                return response;
            }
            catch (error) {
                await client.query('rollback');
                throw mapDatabaseError(error);
            }
        });
    }
    async listWork(kind, limit) {
        return this.pool.withClient(async (client) => {
            await client.query(kind === 'report.output.expire' ? 'begin' : 'begin read only');
            try {
                await this.setWorkerContext(client);
                if (kind === 'report.output.expire')
                    await client.query('select private.prune_mobile_activity()');
                const rows = (await client.query('select * from private.list_report_work($1,$2)', [
                    kind,
                    limit,
                ])).rows;
                await client.query('commit');
                return rows.map(({ id }) => id);
            }
            catch (error) {
                await client.query('rollback');
                throw mapDatabaseError(error);
            }
        });
    }
    async listRequestedPdfEmailWork(kind, limit, acceptedAfter) {
        return this.pool.withClient(async (client) => {
            await client.query('begin read only');
            try {
                await this.setWorkerContext(client);
                const rows = (await client.query('select * from private.list_requested_pdf_email_work($1,$2,$3::timestamptz)', [kind, limit, acceptedAfter])).rows;
                await client.query('commit');
                return rows.map(({ id }) => id);
            }
            catch (error) {
                await client.query('rollback');
                throw mapDatabaseError(error);
            }
        });
    }
    async captureDeliveryWebhook(eventKeyHash, payloadHash) {
        return this.pool.withClient(async (client) => {
            await client.query('begin');
            try {
                await this.setWorkerContext(client);
                const outcome = (await client.query('select private.capture_report_delivery_webhook($1,$2)', [eventKeyHash, payloadHash])).rows[0]?.capture_report_delivery_webhook;
                await client.query('commit');
                if (!outcome)
                    throw new Error('REPORT_WEBHOOK_CAPTURE_FAILED');
                return outcome;
            }
            catch (error) {
                await client.query('rollback');
                throw mapDatabaseError(error);
            }
        });
    }
    async withWorkLock(kind, id, action) {
        return this.pool.withClient(async (client) => {
            const locked = (await client.query('select pg_try_advisory_lock(hashtextextended($1,0)) locked', [id])).rows[0]?.locked;
            if (!locked)
                return false;
            try {
                await client.query('begin');
                await this.setWorkerContext(client);
                const row = (await client.query('select * from private.read_report_work($1::uuid)', [id])).rows[0];
                if (!row) {
                    await client.query('rollback');
                    return false;
                }
                const expected = kind === 'report.generate'
                    ? ['queued', 'generating', 'failed']
                    : kind === 'report.email.deliver'
                        ? ['ready', 'sending']
                        : ['queued', 'generating', 'ready', 'sending', 'delivered', 'failed'];
                if (!expected.includes(row.status)) {
                    await client.query('rollback');
                    return false;
                }
                if (row.user_id)
                    await (0, financial_worker_generation_1.bindFinancialClaim)(client, 'report', id, null);
                const initial = kind === 'report.generate'
                    ? 'generating'
                    : kind === 'report.email.deliver'
                        ? 'sending'
                        : null;
                if (initial && row.status !== initial)
                    await client.query('select private.transition_report_output($1,$2,$3,$4,$5)', [
                        id,
                        initial,
                        null,
                        null,
                        null,
                    ]);
                await client.query('commit');
                const outcome = await action({
                    id: row.id,
                    userId: row.user_id,
                    status: row.status,
                    snapshot: row.snapshot,
                    storageRef: row.storage_ref,
                    expiresAt: row.expires_at.toISOString(),
                    attemptCount: row.attempt_count + (initial && row.status !== initial ? 1 : 0),
                    recipient: row.recipient,
                });
                await client.query('begin');
                await this.setWorkerContext(client);
                if (row.user_id)
                    await (0, financial_worker_generation_1.bindFinancialClaim)(client, 'report', id, null);
                await client.query('select private.transition_report_output($1,$2,$3,$4,$5)', [
                    id,
                    outcome.status,
                    outcome.storageRef ?? null,
                    outcome.providerMessageId ?? null,
                    outcome.errorCode ?? null,
                ]);
                if (outcome.event) {
                    const event = (0, reports_events_1.buildReportEvent)(outcome.event.type, outcome.event.data);
                    await client.query('select private.enqueue_outbox_event($1,$2,$3,$4::jsonb)', [
                        event.type,
                        'report_attempt',
                        id,
                        JSON.stringify(event),
                    ]);
                }
                await client.query('commit');
                return true;
            }
            catch (error) {
                try {
                    await client.query('rollback');
                }
                catch {
                }
                throw error;
            }
            finally {
                await client.query('select pg_advisory_unlock(hashtextextended($1,0))', [id]);
            }
        });
    }
    async listDueSchedules(now, limit) {
        return this.pool.withClient(async (client) => {
            await client.query('begin');
            try {
                await this.setWorkerContext(client);
                const rows = (await client.query('select * from private.list_due_report_schedules($1,$2)', [now.toISOString(), limit])).rows;
                await client.query('commit');
                return rows;
            }
            catch (error) {
                await client.query('rollback');
                throw mapDatabaseError(error);
            }
        });
    }
    async enqueueDueSchedule(id, now) {
        return this.pool.withClient(async (client) => {
            const locked = (await client.query('select pg_try_advisory_lock(hashtextextended($1,1)) locked', [id])).rows[0]?.locked;
            if (!locked)
                return false;
            try {
                await client.query('begin isolation level repeatable read');
                await this.setWorkerContext(client);
                const schedule = (await client.query('select * from private.read_due_report_schedule($1::uuid,$2::timestamptz)', [id, now.toISOString()])).rows[0];
                if (!schedule) {
                    await client.query('rollback');
                    return false;
                }
                await (0, financial_worker_generation_1.bindFinancialClaim)(client, 'report-schedule', id, null);
                const occurrence = (0, reports_period_1.nextScheduleOccurrence)({
                    frequency: schedule.frequency,
                    timezone: schedule.timezone,
                    nextRunAt: schedule.next_run_at,
                }, now);
                await this.setApiContext(client, {
                    userId: schedule.user_id,
                    sessionId: 'report-scheduler',
                    factorAgeSeconds: null,
                });
                const context = (await client.query(`select coalesce(u.default_currency,'SAR') currency from public.profiles p
           left join public.user_preferences u on u.user_id=p.id where p.id=$1`, [schedule.user_id])).rows[0];
                if (!context)
                    throw new Error('REPORT_OWNER_MISSING');
                const summary = await this.readSummary(client, schedule.user_id, schedule.report_type, occurrence.period, context.currency.trim());
                const content = await this.reportContent(client, {
                    userId: schedule.user_id,
                    reportType: schedule.report_type,
                    period: occurrence.period,
                    currency: context.currency.trim(),
                    summary,
                });
                const snapshot = (0, reports_schemas_1.parseReportSnapshot)({
                    schemaVersion: 1,
                    generatedAt: summary.metadata.generatedAt,
                    ledgerVersion: summary.metadata.ledgerVersion,
                    reportType: schedule.report_type,
                    period: {
                        startDate: occurrence.period.startDate,
                        endDate: occurrence.period.endDate,
                        timezone: schedule.timezone,
                        kind: schedule.frequency,
                    },
                    format: 'pdf',
                    delivery: schedule.delivery_channel,
                    currencyCode: context.currency.trim(),
                    dataState: content.dataState,
                    evidence: summary.metadata.evidence,
                    summary: content.summary,
                    breakdowns: content.breakdowns,
                    detailedRows: content.detailedRows,
                }, this.config?.get('MASARIFI_REPORT_MAX_BYTES') ?? 52_428_800);
                await this.setWorkerContext(client, schedule.user_id);
                const retentionHours = this.config?.get('MASARIFI_REPORT_RETENTION_HOURS') ?? 24;
                await client.query('select * from private.capture_report_snapshot($1,$2,$3::date,$4::date,$5,$6::jsonb,$7::uuid,$8::timestamptz)', [
                    schedule.user_id,
                    schedule.report_type,
                    occurrence.period.startDate,
                    occurrence.period.endDate,
                    summary.metadata.ledgerVersion,
                    JSON.stringify(snapshot),
                    schedule.id,
                    new Date(now.getTime() + retentionHours * 3_600_000).toISOString(),
                ]);
                await client.query('select private.advance_report_schedule($1::uuid,$2,$3::timestamptz,$4::timestamptz)', [
                    schedule.id,
                    safeInteger(schedule.version),
                    occurrence.scheduledFor.toISOString(),
                    occurrence.nextRunAt.toISOString(),
                ]);
                await client.query('commit');
                return true;
            }
            catch (error) {
                await client.query('rollback');
                throw mapDatabaseError(error);
            }
            finally {
                await client.query('select pg_advisory_unlock(hashtextextended($1,1))', [id]);
            }
        });
    }
    createSchedule(principal, command, idempotencyKey, requestId) {
        return this.scheduleMutation(principal, 'report-schedules.create', idempotencyKey, command, 201, requestId, async (client) => {
            const row = (await client.query('select * from private.create_report_schedule($1,$2,$3,$4,$5::timestamptz,$6,$7,$8)', [
                principal.userId,
                command.reportType,
                command.frequency,
                command.timezone,
                command.nextRunAt,
                command.deliveryChannel,
                command.recipient,
                command.enabled,
            ])).rows[0];
            if (!row)
                throw new Error('REPORT_SCHEDULE_CREATE_FAILED');
            return this.schedule(row);
        }, 'report.schedule_created');
    }
    async getSchedule(principal, id, requestId) {
        return { ...this.schedule(await this.getScheduleState(principal, id)), requestId };
    }
    async getScheduleState(principal, id) {
        const rows = await this.withApiSnapshot(principal, async (client) => (await client.query('select * from public.report_schedules where id=$1 and user_id=$2', [id, principal.userId])).rows);
        if (!rows[0])
            throw new common_1.HttpException({ code: 'REPORT_NOT_FOUND' }, 404);
        return rows[0];
    }
    async listSchedules(principal, cursor, limit, requestId) {
        const decoded = this.decodeCursor(cursor);
        const rows = await this.withApiSnapshot(principal, async (client) => (await client.query(`select * from public.report_schedules where user_id=$1
         and ($2::timestamptz is null or (created_at,id)<($2,$3::uuid))
         order by created_at desc,id desc limit $4`, [principal.userId, decoded?.createdAt ?? null, decoded?.id ?? null, limit + 1])).rows);
        const items = rows.slice(0, limit), last = items.at(-1);
        return {
            items: items.map((row) => this.schedule(row)),
            nextCursor: rows.length > limit && last
                ? Buffer.from(JSON.stringify({ createdAt: last.created_at.toISOString(), id: last.id })).toString('base64url')
                : null,
            requestId,
        };
    }
    updateSchedule(principal, command, idempotencyKey, requestId, auditAction = 'report.schedule_updated') {
        return this.scheduleMutation(principal, 'report-schedules.update', idempotencyKey, command, 200, requestId, async (client) => {
            const row = (await client.query('select * from private.update_report_schedule($1,$2::uuid,$3,$4,$5,$6,$7::timestamptz,$8,$9,$10)', [
                principal.userId,
                command.id,
                command.expectedVersion,
                command.reportType,
                command.frequency,
                command.timezone,
                command.nextRunAt,
                command.deliveryChannel,
                command.recipient,
                command.enabled,
            ])).rows[0];
            if (!row)
                throw new common_1.HttpException({ code: 'REPORT_SCHEDULE_CONFLICT' }, 409);
            return this.schedule(row);
        }, auditAction);
    }
    deleteSchedule(principal, id, expectedVersion, idempotencyKey, requestId) {
        const command = { id, expectedVersion };
        return this.scheduleMutation(principal, 'report-schedules.delete', idempotencyKey, command, 204, requestId, async (client) => {
            const deleted = (await client.query('select private.delete_report_schedule($1,$2::uuid,$3)', [principal.userId, id, expectedVersion])).rows[0]?.delete_report_schedule;
            if (!deleted)
                throw new Error('REPORT_SCHEDULE_DELETE_FAILED');
            return { id: deleted };
        }, 'report.schedule_deleted');
    }
    async scheduleMutation(principal, scope, idempotencyKey, command, status, requestId, action, auditAction) {
        return this.pool.withClient(async (client) => {
            await client.query('begin');
            try {
                await this.setApiContext(client, principal);
                const keyHash = (0, idempotency_1.hashIdempotencyKey)(idempotencyKey), requestHash = (0, idempotency_1.hashNormalizedCommand)(command);
                const claim = (await client.query('select * from private.claim_idempotency_key($1,$2,$3,$4,$5::interval)', [principal.userId, scope, keyHash, requestHash, '2 minutes'])).rows[0];
                if (claim?.outcome === 'replay' && claim.response_body) {
                    await client.query('commit');
                    return claim.response_body;
                }
                if (claim?.outcome !== 'new')
                    throw new common_1.HttpException({
                        code: claim?.outcome === 'hash_mismatch'
                            ? 'IDEMPOTENCY_KEY_REUSED'
                            : 'IDEMPOTENCY_IN_PROGRESS',
                    }, 409);
                const response = await action(client);
                const resourceId = typeof response.id === 'string' ? response.id : null;
                if (auditAction && resourceId) {
                    await client.query('select audit.append_event($1,$2,$3,$4,$5,$6,$7,$8,$9,$10::jsonb)', [
                        principal.userId,
                        'user',
                        auditAction,
                        'report_schedule',
                        resourceId,
                        null,
                        null,
                        null,
                        requestId,
                        JSON.stringify({
                            reportType: command.reportType,
                            frequency: command.frequency,
                            deliveryChannel: command.deliveryChannel,
                            enabled: command.enabled,
                        }),
                    ]);
                }
                await client.query('select private.complete_idempotency_key($1,$2,$3,$4,$5,$6::jsonb,$7)', [
                    principal.userId,
                    scope,
                    keyHash,
                    requestHash,
                    status,
                    JSON.stringify(response),
                    resourceId,
                ]);
                await client.query('commit');
                void requestId;
                return response;
            }
            catch (error) {
                await client.query('rollback');
                throw mapDatabaseError(error);
            }
        });
    }
    schedule(row) {
        const recipientMasked = row.recipient?.replace(/^(.)([^@]*)(@.*)$/u, '$1***$3');
        return {
            id: row.id,
            ...(row.schedule_id ? { scheduleId: row.schedule_id } : {}),
            version: safeInteger(row.version),
            reportType: row.report_type,
            frequency: row.frequency,
            timezone: row.timezone,
            nextRunAt: row.next_run_at.toISOString(),
            deliveryChannel: row.delivery_channel,
            ...(recipientMasked ? { recipientMasked, recipient: row.recipient } : {}),
            enabled: row.enabled,
            lastRunAt: row.last_run_at?.toISOString() ?? null,
            createdAt: row.created_at.toISOString(),
            updatedAt: row.updated_at.toISOString(),
        };
    }
    attempt(row, requestId, includeStorage) {
        return {
            id: row.id,
            reportType: row.report_type,
            format: row.format,
            delivery: row.delivery,
            status: row.status,
            metadata: row.metadata,
            requestedAt: row.requested_at.toISOString(),
            expiresAt: row.expires_at.toISOString(),
            ...(row.error_code ? { errorCode: row.error_code } : {}),
            ...(includeStorage && row.storage_ref ? { storageRef: row.storage_ref } : {}),
            requestId,
        };
    }
    decodeCursor(value) {
        if (!value)
            return null;
        try {
            const parsed = JSON.parse(Buffer.from(value, 'base64url').toString('utf8'));
            if (typeof parsed.createdAt !== 'string' ||
                !Number.isFinite(Date.parse(parsed.createdAt)) ||
                typeof parsed.id !== 'string')
                throw new Error();
            return { createdAt: parsed.createdAt, id: parsed.id };
        }
        catch {
            throw new common_1.HttpException({ code: 'VALIDATION_FAILED' }, 400);
        }
    }
    async readPlanning(client, userId, period, currency) {
        const budgets = (await client.query(`select b.currency_code,sum(b.total_minor)::bigint total_minor,
           coalesce(sum(u.spent_minor),0)::bigint spent_minor
         from public.budgets b left join public.v_budget_utilization u on u.budget_id=b.id
         where b.user_id=$1 and b.status<>'deleted' and b.period_end>=$2::date and b.period_start<=$3::date
           and ($4::char(3) is null or b.currency_code=$4)
         group by b.currency_code order by b.currency_code limit 16`, [userId, period.startDate, period.endDate, currency])).rows.map((row) => ({
            currency: row.currency_code.trim(),
            budgetMinor: safeInteger(row.total_minor),
            spentMinor: safeInteger(row.spent_minor),
        }));
        const obligations = (await client.query(`select currency_code,sum(paid_minor)::bigint paid_minor,
           sum(remaining_minor)::bigint remaining_minor,sum(overdue_minor)::bigint overdue_minor
         from public.v_obligation_status where user_id=$1
           and ($2::char(3) is null or currency_code=$2)
         group by currency_code order by currency_code limit 16`, [userId, currency])).rows.map((row) => ({
            currency: row.currency_code.trim(),
            paidMinor: safeInteger(row.paid_minor),
            remainingMinor: safeInteger(row.remaining_minor),
            overdueMinor: safeInteger(row.overdue_minor),
        }));
        const savingsGoals = (await client.query(`select g.currency_code,sum(g.target_minor)::bigint target_minor,
           sum(g.opening_tracked_minor+coalesce(m.movement_minor,0))::bigint tracked_minor
         from public.savings_goals g left join lateral (
           select sum(amount_minor)::bigint movement_minor from public.savings_goal_movements
           where goal_id=g.id
         ) m on true
         where g.user_id=$1 and g.status<>'deleted'
           and ($2::char(3) is null or g.currency_code=$2)
         group by g.currency_code order by g.currency_code limit 16`, [userId, currency])).rows.map((row) => ({
            currency: row.currency_code.trim(),
            targetMinor: safeInteger(row.target_minor),
            trackedMinor: safeInteger(row.tracked_minor),
        }));
        return { budgets, obligations, savingsGoals };
    }
    async readDetailedRows(client, userId, period, options) {
        const rows = (await client.query(`select t.occurred_at,t.kind,t.amount_minor,t.currency_code,
           coalesce(c.label_en,'Uncategorized') category_label
         from public.transactions t left join public.categories c on c.id=t.category_id
         where t.user_id=$1 and t.status='confirmed' and t.deleted_at is null
           and t.occurred_at>=$2::timestamptz and t.occurred_at<$3::timestamptz
           and ($4::char(3) is null or t.currency_code=$4)
           and ($6::uuid[] is null or exists(select 1 from public.transaction_postings p
             where p.transaction_id=t.id and p.account_id=any($6::uuid[]) and p.clearing_state='confirmed'))
         order by t.occurred_at,t.id limit $5`, [
            userId,
            period.startInstant,
            period.endExclusiveInstant,
            options.currency,
            options.limit + 1,
            options.accountIds ?? null,
        ])).rows;
        if (rows.length > options.limit)
            throw new common_1.HttpException({ code: 'REPORT_LIMIT_EXCEEDED' }, 413);
        return rows.map((row) => ({
            occurredAt: row.occurred_at.toISOString(),
            kind: row.kind,
            amountMinor: safeInteger(row.amount_minor),
            currencyCode: row.currency_code.trim(),
            categoryLabel: row.category_label,
        }));
    }
    async reportContent(client, input) {
        const includePlanning = !input.accountIds?.length &&
            [
                'financial_summary',
                'budget_performance',
                'obligation_progress',
                'savings_progress',
            ].includes(input.reportType);
        const planning = includePlanning
            ? await this.readPlanning(client, input.userId, input.period, input.currency)
            : undefined;
        const detailedRows = input.reportType === 'account_activity'
            ? await this.readDetailedRows(client, input.userId, input.period, {
                currency: input.currency,
                accountIds: input.accountIds,
                limit: this.config?.get('MASARIFI_REPORT_MAX_ROWS') ?? 100_000,
            })
            : [];
        const breakdowns = ['financial_summary', 'category_spending'].includes(input.reportType)
            ? input.summary.breakdowns
            : [];
        const hasPlanning = planning && Object.values(planning).some((rows) => rows.length > 0);
        const hasData = input.summary.summaries.length > 0 || breakdowns.length > 0 || detailedRows.length > 0;
        const minorUnit = (await client.query('select minor_unit from public.currencies where code=$1', [input.currency])).rows[0]?.minor_unit;
        if (!Number.isInteger(minorUnit) || minorUnit === undefined || minorUnit < 0 || minorUnit > 4)
            throw new Error('REPORT_CURRENCY_METADATA_UNAVAILABLE');
        return {
            summary: {
                summaries: input.summary.summaries,
                ...(planning ? { planning } : {}),
                currencyMinorUnits: { [input.currency]: minorUnit },
            },
            breakdowns,
            detailedRows,
            dataState: hasData || hasPlanning ? 'complete' : 'empty',
        };
    }
    async readSummary(client, userId, reportType, period, currency, accountIds) {
        const reportTransactions = `with report_transactions as (
      select t.id,t.user_id,t.kind,t.status,t.deleted_at,t.occurred_at,t.currency_code,
        t.category_id,t.reverses_transaction_id,
        case when $5::uuid[] is null then t.amount_minor
          when t.kind='expense' then -p.principal_minor else p.principal_minor end amount_minor,
        case when $5::uuid[] is null then t.fee_minor else -p.fee_minor end fee_minor
      from public.transactions t
      left join lateral (
        select coalesce(sum(p.amount_minor) filter(where p.posting_role<>'fee'),0)::bigint principal_minor,
          coalesce(sum(p.amount_minor) filter(where p.posting_role='fee'),0)::bigint fee_minor
        from public.transaction_postings p
        where $5::uuid[] is not null and p.transaction_id=t.id
          and p.account_id=any($5::uuid[]) and p.clearing_state='confirmed'
      ) p on true
      where t.user_id=$1 and t.status='confirmed' and t.deleted_at is null
        and t.occurred_at >= $2::timestamptz and t.occurred_at < $3::timestamptz
        and ($4::char(3) is null or t.currency_code=$4)
        and ($5::uuid[] is null or p.principal_minor<>0 or p.fee_minor<>0)
    )`;
        const parameters = [
            userId,
            period.startInstant,
            period.endExclusiveInstant,
            currency,
            accountIds ?? null,
        ];
        const summaries = (await client.query(`${reportTransactions}, effects as (
           select t.currency_code,
             case when t.kind='income' then t.amount_minor else 0 end::bigint income_minor,
             case
               when t.kind='expense' then t.amount_minor+t.fee_minor
               when t.kind='refund' then -t.amount_minor
               when t.fee_minor>0 then t.fee_minor
               else 0
             end::bigint expense_minor,
             case when t.kind in ('income','expense','refund') or t.fee_minor>0 then 1 else 0 end transaction_count
           from report_transactions t
         )
         select currency_code,sum(income_minor)::bigint income_minor,
           sum(expense_minor)::bigint expense_minor,
           (sum(income_minor)-sum(expense_minor))::bigint net_cash_flow_minor,
           sum(transaction_count)::bigint transaction_count
         from effects where transaction_count>0
         group by currency_code order by currency_code`, parameters)).rows.map((row) => {
            const income = safeInteger(row.income_minor);
            const netCashFlow = safeInteger(row.net_cash_flow_minor);
            const currencyCode = row.currency_code.trim();
            return {
                income: { amountMinor: income, currency: currencyCode },
                expense: { amountMinor: safeInteger(row.expense_minor), currency: currencyCode },
                netCashFlow: { amountMinor: netCashFlow, currency: currencyCode },
                savingsRateBasisPoints: income === 0 ? 0 : Math.trunc((netCashFlow * 10_000) / income),
                transactionCount: safeInteger(row.transaction_count),
            };
        });
        const breakdowns = (await client.query(`${reportTransactions}, category_effects as (
           select t.currency_code,t.category_id,t.amount_minor::bigint expense_minor
           from report_transactions t
           where t.kind='expense' and t.category_id is not null and t.amount_minor<>0
           union all
           select r.currency_code,o.category_id,-r.amount_minor::bigint
           from report_transactions r
           join public.transactions o on o.id=r.reverses_transaction_id and o.user_id=r.user_id
           where r.kind='refund' and o.category_id is not null
         )
         select e.category_id,c.label_ar category_label_ar,c.label_en category_label_en,e.currency_code,
           sum(e.expense_minor)::bigint expense_minor,count(*)::bigint transaction_count
         from category_effects e
         join public.categories c on c.id=e.category_id
         group by e.category_id,c.label_ar,c.label_en,e.currency_code
         order by currency_code,expense_minor desc,category_id limit 100`, parameters)).rows.map((row) => ({
            categoryId: row.category_id,
            labelAr: row.category_label_ar,
            labelEn: row.category_label_en,
            currencyCode: row.currency_code.trim(),
            expenseMinor: safeInteger(row.expense_minor),
            transactionCount: safeInteger(row.transaction_count),
        }));
        const ledgerVersion = safeInteger((await client.query(`select coalesce(max(b.ledger_version),0)::bigint ledger_version
           from public.account_balances b join public.accounts a on a.id=b.account_id where a.user_id=$1`, [userId])).rows[0]?.ledger_version ?? '0');
        const generatedAt = new Date().toISOString();
        return {
            metadata: {
                schemaVersion: 1,
                generatedAt,
                ledgerVersion,
                reportType,
                period: period.kind,
                range: {
                    startDate: period.startDate,
                    endDate: period.endDate,
                    timezone: period.timezone,
                },
                dataState: summaries.length === 0 ? 'empty' : 'complete',
                evidence: [{ kind: 'ledger', version: ledgerVersion, asOf: generatedAt }],
            },
            summaries,
            breakdowns,
        };
    }
    withApiSnapshot(principal, action) {
        return this.pool.withClient(async (client) => {
            await client.query('begin isolation level repeatable read read only');
            try {
                await this.setApiContext(client, principal);
                const result = await action(client);
                await client.query('commit');
                return result;
            }
            catch (error) {
                await client.query('rollback');
                throw error;
            }
        });
    }
    async setApiContext(client, principal) {
        await client.query("select set_config('request.jwt.claims',$1,true)", [
            JSON.stringify({ role: 'authenticated', sub: principal.userId, sid: principal.sessionId }),
        ]);
        await client.query('set local role masarifi_api');
    }
    async setWorkerContext(client, userId) {
        await client.query("select set_config('request.jwt.claims',$1,true)", [
            JSON.stringify({ role: 'worker', ...(userId ? { sub: userId } : {}) }),
        ]);
        await client.query('set local role masarifi_worker');
    }
};
exports.ReportsRepository = ReportsRepository;
exports.ReportsRepository = ReportsRepository = __decorate([
    (0, common_1.Injectable)(),
    __param(1, (0, common_1.Optional)()),
    __metadata("design:paramtypes", [pool_service_1.PoolService,
        platform_config_service_1.PlatformConfigService])
], ReportsRepository);
