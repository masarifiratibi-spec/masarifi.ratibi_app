"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.OperationsJobRegistry = exports.GOVERNED_JOB_KEYS = exports.OPERATIONS_JOB_KEYS = void 0;
const common_1 = require("@nestjs/common");
const ai_worker_1 = require("../ai/ai.worker");
const engagement_worker_1 = require("../engagement/engagement.worker");
const clerk_webhook_worker_1 = require("../identity/clerk-webhook.worker");
const ledger_worker_1 = require("../ledger/ledger.worker");
const outbox_worker_service_1 = require("../platform/outbox/outbox-worker.service");
const planning_worker_1 = require("../planning/planning.worker");
const reports_worker_1 = require("../reports/reports.worker");
const financial_reset_worker_1 = require("../security/financial-reset.worker");
const security_worker_1 = require("../security/security.worker");
const sync_worker_1 = require("../sync/sync.worker");
const tracking_worker_1 = require("../tracking/tracking.worker");
const operations_service_1 = require("./operations.service");
exports.OPERATIONS_JOB_KEYS = Object.freeze([
    'operations.provider-health',
    'operations.capacity-evaluate',
    'operations.cache-invalidate',
    'operations.backup-verify',
    'operations.restore-drill',
    'operations.dr-rehearse',
    'operations.maintenance-activate',
    'operations.maintenance-complete',
    'operations.job-history-retain',
]);
exports.GOVERNED_JOB_KEYS = Object.freeze([
    'platform.outbox.dispatch',
    'clerk.webhook.process',
    'clerk.identity.reconcile',
    'clerk.session-revoke.retry',
    'security.support-expire',
    'security.alert-dispatch',
    'privacy.export-generate',
    'privacy.export-expire',
    'privacy.account-delete',
    'privacy.financial-reset-cleanup',
    'retention.apply',
    'ledger.reconcile',
    'sync-mutations.retry',
    'idempotency.cleanup',
    'sync-state.cleanup',
    'conflicts.expire',
    'planning.salary-cycle.generate',
    'planning.obligation-schedule.generate',
    'planning.payment-match.propose',
    'planning.overdue.mark',
    'planning.reminders.emit',
    'planning.reconcile',
    'import.parse',
    'parser.corpus',
    'raw.purge',
    'tracking.reconcile',
    'ai.evaluate_route',
    'voice.transcribe_extract',
    'voice.finalize',
    'assistant.respond',
    'ai.usage_rollup',
    'voice-media.purge',
    'ai.reconcile',
    'financial-insights.generate',
    'report.generate',
    'report.email.deliver',
    'report.output.expire',
    'report.schedule.enqueue',
    'source.consume',
    'notification.dispatch',
    'notification.expire',
    'notification.campaign.expand',
    'notification.reminders.evaluate',
    'support-attachment.scan',
    'support-attachment.cleanup',
    ...exports.OPERATIONS_JOB_KEYS,
]);
let OperationsJobRegistry = class OperationsJobRegistry {
    operations;
    outbox;
    clerk;
    security;
    ledger;
    sync;
    planning;
    tracking;
    ai;
    reports;
    engagement;
    financialReset;
    constructor(operations, outbox, clerk, security, ledger, sync, planning, tracking, ai, reports, engagement, financialReset) {
        this.operations = operations;
        this.outbox = outbox;
        this.clerk = clerk;
        this.security = security;
        this.ledger = ledger;
        this.sync = sync;
        this.planning = planning;
        this.tracking = tracking;
        this.ai = ai;
        this.reports = reports;
        this.engagement = engagement;
        this.financialReset = financialReset;
    }
    async run(jobKey) {
        if (!exports.GOVERNED_JOB_KEYS.includes(jobKey))
            throw new Error('OPERATIONS_JOB_UNKNOWN');
        let result;
        if (exports.OPERATIONS_JOB_KEYS.includes(jobKey))
            return this.operations.runJob(jobKey);
        if (jobKey === 'platform.outbox.dispatch')
            result = await this.required(this.outbox).runOnce();
        else if (jobKey.startsWith('clerk.'))
            result = await this.required(this.clerk).runJob(jobKey);
        else if (jobKey === 'privacy.financial-reset-cleanup')
            result = await this.required(this.financialReset).run();
        else if (/^(security\.|privacy\.|retention\.)/u.test(jobKey)) {
            await this.required(this.security).runJob(jobKey);
            result = 1;
        }
        else if (jobKey === 'ledger.reconcile')
            result = await this.required(this.ledger).runOnce();
        else if (/^(sync-mutations\.|idempotency\.|sync-state\.|conflicts\.)/u.test(jobKey))
            result = await this.required(this.sync).runJob(jobKey);
        else if (jobKey.startsWith('planning.'))
            result = await this.required(this.planning).runJob(jobKey);
        else if (/^(import\.|parser\.|raw\.|tracking\.)/u.test(jobKey))
            result = await this.required(this.tracking).runJob(jobKey);
        else if (jobKey === 'voice-media.purge' ||
            /^(ai\.|voice\.|assistant\.|financial-insights\.)/u.test(jobKey))
            result = await this.required(this.ai).runJob(jobKey);
        else if (jobKey.startsWith('report.'))
            result = await this.required(this.reports).runJob(jobKey);
        else
            result = await this.required(this.engagement).runJob(jobKey);
        return {
            outcome: 'succeeded',
            processed: typeof result === 'number' && Number.isSafeInteger(result) ? result : 1,
        };
    }
    required(value) {
        if (!value)
            throw new Error('OPERATIONS_JOB_HANDLER_UNAVAILABLE');
        return value;
    }
};
exports.OperationsJobRegistry = OperationsJobRegistry;
exports.OperationsJobRegistry = OperationsJobRegistry = __decorate([
    (0, common_1.Injectable)(),
    __param(0, (0, common_1.Inject)(operations_service_1.OperationsService)),
    __param(1, (0, common_1.Optional)()),
    __param(2, (0, common_1.Optional)()),
    __param(3, (0, common_1.Optional)()),
    __param(4, (0, common_1.Optional)()),
    __param(5, (0, common_1.Optional)()),
    __param(6, (0, common_1.Optional)()),
    __param(7, (0, common_1.Optional)()),
    __param(8, (0, common_1.Optional)()),
    __param(9, (0, common_1.Optional)()),
    __param(10, (0, common_1.Optional)()),
    __param(11, (0, common_1.Optional)()),
    __metadata("design:paramtypes", [Object, outbox_worker_service_1.OutboxWorkerService,
        clerk_webhook_worker_1.ClerkWebhookWorker,
        security_worker_1.SecurityWorkerService,
        ledger_worker_1.LedgerWorker,
        sync_worker_1.SyncWorker,
        planning_worker_1.PlanningWorker,
        tracking_worker_1.TrackingWorker,
        ai_worker_1.AiWorker,
        reports_worker_1.ReportsWorker,
        engagement_worker_1.EngagementWorker,
        financial_reset_worker_1.FinancialResetWorker])
], OperationsJobRegistry);
