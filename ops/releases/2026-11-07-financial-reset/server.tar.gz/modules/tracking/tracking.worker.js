"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.TrackingWorker = void 0;
const financial_worker_generation_1 = require("../platform/database/financial-worker-generation");
const node_crypto_1 = require("node:crypto");
const node_util_1 = require("node:util");
const common_1 = require("@nestjs/common");
const ledger_service_1 = require("../ledger/ledger.service");
const tracking_observability_1 = require("./tracking.observability");
const tracking_repository_1 = require("./tracking.repository");
const tracking_parser_1 = require("./tracking.parser");
const tracking_storage_1 = require("./tracking.storage");
const tracking_capture_agreement_1 = require("./tracking-capture-agreement");
function record(value) {
    if (!value || typeof value !== 'object' || Array.isArray(value))
        throw new Error('IMPORT_RESULT_INVALID');
    return value;
}
function stableUuid(seed) {
    const value = (0, node_crypto_1.createHash)('sha256').update(seed).digest('hex');
    return `${value.slice(0, 8)}-${value.slice(8, 12)}-4${value.slice(13, 16)}-8${value.slice(17, 20)}-${value.slice(20, 32)}`;
}
let TrackingWorker = class TrackingWorker {
    repository;
    ledger;
    storage;
    active;
    timer;
    stopped = false;
    workerId = `tracking-${String(process.pid)}-${(0, node_crypto_1.createHash)('sha256').update(process.cwd()).digest('hex').slice(0, 12)}`;
    constructor(repository, ledger, storage) {
        this.repository = repository;
        this.ledger = ledger;
        this.storage = storage;
    }
    runOnce() {
        if (this.active)
            return this.active;
        const current = this.execute();
        this.active = current;
        void current
            .finally(() => {
            if (this.active === current)
                this.active = undefined;
        })
            .catch(() => undefined);
        return current;
    }
    start() {
        if (this.stopped || this.timer)
            return;
        void this.runOnce().catch(() => undefined);
        this.timer = setInterval(() => void this.runOnce().catch(() => undefined), 30_000);
        this.timer.unref();
    }
    async stop() {
        this.stopped = true;
        if (this.timer)
            clearInterval(this.timer);
        this.timer = undefined;
        await this.active?.catch(() => undefined);
    }
    async onModuleDestroy() {
        await this.stop();
    }
    async execute() {
        await Promise.all([this.runJob('parser.corpus'), this.runJob('import.parse')]);
        await this.runJob('raw.purge');
        await this.runJob('tracking.reconcile');
    }
    async runJob(job) {
        const startedAt = performance.now();
        if (job === 'parser.corpus') {
            const claims = await this.repository.claimParserCorpus(this.workerId);
            for (const claim of claims)
                await this.processCorpus(claim);
            (0, tracking_observability_1.recordTrackingJob)(job, claims.length ? 'success' : 'empty', claims.length);
            return claims.length;
        }
        if (job === 'import.parse') {
            const claims = await this.repository.claimImports(this.workerId);
            for (const claim of claims)
                await (0, financial_worker_generation_1.withClaimGeneration)(claim.generation, () => this.process(claim));
            (0, tracking_observability_1.recordTrackingJob)(job, claims.length ? 'success' : 'empty', claims.length);
            return claims.length;
        }
        if (job === 'raw.purge') {
            const due = await this.repository.rawDue();
            let purged = 0;
            let failed = false;
            for (const item of due)
                try {
                    await this.storage.delete(item.storage_ref);
                    if (await this.repository.completeRaw(item.id, item.purge_token))
                        purged += 1;
                    else
                        failed = true;
                }
                catch {
                    failed = true;
                }
            (0, tracking_observability_1.recordTrackingJob)(job, failed ? 'failure' : due.length ? 'success' : 'empty', purged);
            return purged;
        }
        await this.repository.maintenance();
        (0, tracking_observability_1.recordTrackingJob)(job, 'success', 1);
        const operational = await this.repository.operationalMetrics();
        (0, tracking_observability_1.recordTrackingOperational)('backlog', 'import.parse', Number(operational.importBacklog));
        (0, tracking_observability_1.recordTrackingOperational)('backlog', 'review', Number(operational.reviewBacklog));
        (0, tracking_observability_1.recordTrackingOperational)('backlog', 'duplicate', Number(operational.duplicateBacklog));
        (0, tracking_observability_1.recordTrackingOperational)('oldestAge', 'import.parse', Number(operational.oldestImportAgeSeconds));
        (0, tracking_observability_1.recordTrackingOperational)('rawPurgeLag', 'raw.purge', Number(operational.rawPurgeLagSeconds));
        (0, tracking_observability_1.recordTrackingDuration)(job, 'success', performance.now() - startedAt);
        return 1;
    }
    async processCorpus(claim) {
        try {
            const corpus = record(await this.repository.prepareParserCorpus(claim.id, claim.claim_token));
            if (!Array.isArray(corpus.cases))
                throw new Error('PARSER_CORPUS_INVALID');
            const results = corpus.cases.map((value) => {
                const item = record(value);
                return {
                    id: String(item.id),
                    passed: (0, node_util_1.isDeepStrictEqual)((0, tracking_parser_1.executeParserDefinition)(corpus.definition, {
                        body: String(item.input),
                        sender: '',
                    }), item.expected),
                };
            });
            await this.repository.completeParserCorpus(claim.id, claim.claim_token, results, null);
        }
        catch (error) {
            const code = (error instanceof Error ? error.message : 'PARSER_CORPUS_FAILED').match(/[A-Z][A-Z0-9_]{2,79}/)?.[0] ?? 'PARSER_CORPUS_FAILED';
            await this.repository
                .completeParserCorpus(claim.id, claim.claim_token, null, code)
                .catch(() => undefined);
            (0, tracking_observability_1.recordTrackingJob)('parser.corpus', 'failure');
        }
    }
    async process(claim) {
        try {
            const prepared = await this.repository.prepareImport(claim.id, claim.claim_token);
            const parserItems = Array.isArray(prepared.parserItems) ? prepared.parserItems : [];
            for (const value of parserItems) {
                const item = record(value);
                if (item.definition && typeof item.definition === 'object') {
                    const input = record(item.input);
                    const source = Object.fromEntries(Object.entries(input).map(([key, entry]) => [
                        key,
                        typeof entry === 'string' ? entry : '',
                    ]));
                    await this.repository.applyParserResult(String(item.id), claim.claim_token, (0, tracking_parser_1.executeParserDefinition)(item.definition, source));
                }
            }
            const finalized = await this.repository.finalizeImport(claim.id, claim.claim_token);
            const items = Array.isArray(finalized.autoItems) ? finalized.autoItems : [];
            for (const value of items) {
                const item = record(value), command = record(item.values);
                const principal = {
                    userId: String(item.userId),
                    sessionId: this.workerId,
                    factorAgeSeconds: null,
                    mfaAgeSeconds: null,
                };
                if (command.accountingPolicy === 'default_account_nominal_v1') {
                    try {
                        this.ledger.assertTrackingRecentAuth(principal, String(command.currency), Math.abs(Number(command.amountMinor)));
                    }
                    catch (error) {
                        const response = error instanceof common_1.HttpException ? error.getResponse() : null;
                        if (!response ||
                            typeof response !== 'object' ||
                            Reflect.get(response, 'code') !== 'RECENT_AUTH_REQUIRED')
                            throw error;
                        await this.repository.deferImportItem(String(item.id), claim.claim_token, 'recent_auth_required');
                        continue;
                    }
                    await this.repository.commitNominalCapture(String(item.id), claim.claim_token);
                    continue;
                }
                const reservation = command.transport
                    ? await this.repository.reserveCapture(String(item.id), claim.claim_token)
                    : null;
                const key = `tracking:${reservation
                    ? String(reservation.identityHash)
                    : await this.repository.getImportSourceIdentityHash(principal, String(item.id))}`;
                if (typeof reservation?.transactionId === 'string') {
                    const saved = record(record(await this.ledger.getTransaction(principal, reservation.transactionId, stableUuid(key))).transaction);
                    if (!(0, tracking_capture_agreement_1.captureEffectsAgree)(saved, command)) {
                        await this.repository.deferImportItem(String(item.id), claim.claim_token, 'duplicate_candidate');
                        continue;
                    }
                    await this.repository.acceptImportItem(String(item.id), claim.claim_token, null, reservation.transactionId);
                    continue;
                }
                if (reservation && reservation.primaryItemId !== String(item.id))
                    throw new Error('IMPORT_CAPTURE_IN_PROGRESS');
                try {
                    const common = {
                        principal,
                        idempotencyKey: key,
                        requestId: stableUuid(key),
                    };
                    const response = record(command.kind === 'refund' || command.kind === 'reversal'
                        ? await (record(command.classification ?? {}).subtype === 'reversal' ||
                            command.kind === 'reversal'
                            ? this.ledger.reverseTransaction({
                                ...common,
                                trackingCaptureId: String(item.id),
                                transactionId: String(command.originalTransactionId),
                                body: {
                                    expectedVersion: command.originalTransactionVersion,
                                    occurredAt: command.occurredAt,
                                    reason: 'Automatic tracking reversal',
                                },
                            })
                            : this.ledger.refundTransaction({
                                ...common,
                                trackingCaptureId: String(item.id),
                                transactionId: String(command.originalTransactionId),
                                body: {
                                    expectedVersion: command.originalTransactionVersion,
                                    amountMinor: Math.abs(Number(command.amountMinor)),
                                    accountId: command.accountId,
                                    occurredAt: command.occurredAt,
                                    reason: 'Automatic tracking refund',
                                },
                            }))
                        : command.kind === 'transfer'
                            ? await this.ledger.transfer({
                                ...common,
                                body: {
                                    sourceAccountId: record(command.classification ?? {}).direction === 'incoming'
                                        ? command.destinationAccountId
                                        : command.accountId,
                                    destinationAccountId: record(command.classification ?? {}).direction === 'incoming'
                                        ? command.accountId
                                        : command.destinationAccountId,
                                    amountMinor: Math.abs(Number(command.amountMinor)),
                                    currency: command.currency,
                                    feeMinor: 0,
                                    source: 'tracking-import',
                                    externalRef: key,
                                    occurredAt: command.occurredAt,
                                    title: command.title ?? command.merchant ?? 'Imported transaction',
                                    note: command.note ?? null,
                                },
                            })
                            : await this.ledger.createTransaction({
                                ...common,
                                body: {
                                    kind: command.kind === 'fee' ? 'expense' : command.kind,
                                    amountMinor: Math.abs(Number(command.amountMinor)),
                                    currency: command.currency,
                                    accountId: command.accountId,
                                    categoryId: command.categoryId ?? null,
                                    title: command.title ?? command.merchant ?? 'Imported transaction',
                                    merchant: command.merchant ?? null,
                                    paymentMethod: command.paymentMethod ?? null,
                                    note: command.note ?? null,
                                    occurredAt: command.occurredAt,
                                    source: 'tracking-import',
                                    externalRef: key,
                                },
                            }));
                    const transaction = record(record(response.transaction).transaction);
                    await this.repository.acceptImportItem(String(item.id), claim.claim_token, typeof response.operationId === 'string'
                        ? response.operationId
                        : stableUuid(`${principal.userId}:${key}`), String(transaction.id));
                }
                catch (error) {
                    const response = error && typeof error === 'object' && 'response' in error
                        ? Reflect.get(error, 'response')
                        : null;
                    const code = response && typeof response === 'object' && 'code' in response
                        ? Reflect.get(response, 'code')
                        : '';
                    if (typeof code !== 'string')
                        throw error;
                    if (!['RECENT_AUTH_REQUIRED', 'VALIDATION_FAILED', 'TRACKING_ACCOUNT_BLOCKED'].includes(code))
                        throw error;
                    await this.repository.deferImportItem(String(item.id), claim.claim_token, code === 'RECENT_AUTH_REQUIRED'
                        ? 'recent_auth_required'
                        : code === 'TRACKING_ACCOUNT_BLOCKED'
                            ? 'account_tracking_blocked'
                            : 'ledger_validation_failed');
                }
            }
            await this.repository.completeImport(claim.id, claim.claim_token, Number(finalized.deferredCount) > 0 ? 'failed' : 'succeeded', Number(finalized.deferredCount) > 0 ? 'TRACKING_CAPTURE_DEFERRED' : null);
        }
        catch (error) {
            const code = (error instanceof Error ? error.message : 'IMPORT_PROCESSING_FAILED').match(/[A-Z][A-Z0-9_]{2,79}/)?.[0] ?? 'IMPORT_PROCESSING_FAILED';
            await this.repository
                .completeImport(claim.id, claim.claim_token, 'failed', code)
                .catch(() => undefined);
            (0, tracking_observability_1.recordTrackingJob)('import.parse', 'failure');
        }
    }
};
exports.TrackingWorker = TrackingWorker;
exports.TrackingWorker = TrackingWorker = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [tracking_repository_1.TrackingRepository,
        ledger_service_1.LedgerService,
        tracking_storage_1.TrackingStorage])
], TrackingWorker);
