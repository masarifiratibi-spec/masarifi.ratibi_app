"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.TrackingService = void 0;
const financial_generation_1 = require("../platform/http/financial-generation");
const node_crypto_1 = require("node:crypto");
const transaction_parser_1 = require("@masarifi/transaction-parser");
const common_1 = require("@nestjs/common");
const identity_repository_1 = require("../identity/identity.repository");
const platform_config_service_1 = require("../platform/config/platform-config.service");
const idempotency_1 = require("../ledger/idempotency");
const ledger_service_1 = require("../ledger/ledger.service");
const tracking_dto_1 = require("./tracking.dto");
const tracking_parser_1 = require("./tracking.parser");
const tracking_repository_1 = require("./tracking.repository");
const tracking_storage_1 = require("./tracking.storage");
const tracking_observability_1 = require("./tracking.observability");
const tracking_capture_agreement_1 = require("./tracking-capture-agreement");
function record(value) {
    if (!value || typeof value !== 'object' || Array.isArray(value))
        throw new Error('VALIDATION_FAILED');
    return value;
}
function exact(input, allowed) {
    if (Object.keys(input).some((key) => !allowed.includes(key)))
        throw new Error('VALIDATION_FAILED');
}
function boundedText(value, min, max) {
    if (typeof value !== 'string')
        throw new Error('VALIDATION_FAILED');
    const normalized = value.normalize('NFKC').trim();
    if (normalized.length < min ||
        Buffer.byteLength(normalized, 'utf8') > max ||
        unsafeText(normalized))
        throw new Error('VALIDATION_FAILED');
    return normalized;
}
function unsafeText(value) {
    for (const character of value) {
        const code = character.codePointAt(0) ?? 0;
        if (code <= 31 ||
            code === 127 ||
            (code >= 0x202a && code <= 0x202e) ||
            (code >= 0x2066 && code <= 0x2069))
            return true;
    }
    return false;
}
function uuidFrom(seed) {
    const value = (0, node_crypto_1.createHash)('sha256').update(seed).digest('hex');
    return `${value.slice(0, 8)}-${value.slice(8, 12)}-4${value.slice(13, 16)}-8${value.slice(17, 20)}-${value.slice(20, 32)}`;
}
function trackingPage(items, limit, resource = '') {
    const selected = items.slice(0, limit);
    if (items.length <= limit)
        return { items: selected, nextCursor: null };
    const last = record(selected.at(-1));
    const at = resource === 'sessions'
        ? last.startedAt
        : resource === 'items' || resource === 'history'
            ? (last.occurredAt ?? last.createdAt)
            : last.createdAt;
    return {
        items: selected,
        nextCursor: (0, tracking_dto_1.encodeTrackingCursor)({ at: String(at), id: String(last.id) }),
    };
}
let TrackingService = class TrackingService {
    repository;
    ledger;
    storage;
    identity;
    config;
    async updateInstallationConsent(principal, deviceId, body) {
        let input;
        try {
            input = (0, tracking_dto_1.normalizeTrackingInstallationConsent)(deviceId, body);
        }
        catch {
            throw this.validation();
        }
        if (!this.identity)
            throw new Error('TRACKING_IDENTITY_UNAVAILABLE');
        const registration = await this.identity
            .registerDevice(principal, input.deviceRegistration)
            .catch((error) => {
            if (error instanceof Error && error.message === 'PUSH_TOKEN_CONFLICT')
                throw new common_1.HttpException({ code: 'TRACKING_DEVICE_SESSION_CONFLICT' }, 409);
            throw error;
        });
        const value = await this.repository.updateInstallationConsent(principal, {
            deviceId: input.deviceId,
            notificationDeviceId: registration.device.id,
            expectedVersion: input.expectedVersion,
            sources: input.sources,
        });
        return {
            ...value,
            configurationHash: (0, node_crypto_1.createHash)('sha256').update((0, transaction_parser_1.canonicalJson)(value)).digest('hex'),
        };
    }
    async deviceRuleSnapshot(principal, body) {
        if (this.config?.get('MASARIFI_MOBILE_AUTOMATION_ENABLED') !== true)
            throw new common_1.HttpException({ code: 'NOT_FOUND' }, 404);
        let input;
        try {
            input = (0, tracking_dto_1.normalizeTrackingInstallationEnrollment)(body);
        }
        catch {
            throw this.validation();
        }
        if (!this.identity)
            throw new Error('TRACKING_IDENTITY_UNAVAILABLE');
        const registration = await this.identity.registerDevice(principal, input.deviceRegistration);
        const value = await this.repository.enrollInstallation(principal, {
            deviceId: input.deviceId,
            notificationDeviceId: registration.device.id,
            smsActivationId: input.smsActivationId,
            remindersEnabled: input.remindersEnabled,
            foreground: input.foreground,
            reminderLocale: input.reminderLocale,
            reminderTimeZone: input.reminderTimeZone,
        });
        return {
            ...value,
            configurationHash: (0, node_crypto_1.createHash)('sha256').update((0, transaction_parser_1.canonicalJson)(value)).digest('hex'),
        };
    }
    confirmation(principal, id) {
        return this.repository.confirmation(principal, (0, tracking_dto_1.normalizeTrackingId)(id));
    }
    async ruleSnapshot(principal, deviceId) {
        let device;
        try {
            device = deviceId === undefined ? undefined : (0, tracking_dto_1.normalizeTrackingId)(deviceId);
        }
        catch {
            throw this.validation();
        }
        const value = await this.repository.ruleSnapshot(principal, device);
        return {
            ...value,
            configurationHash: (0, node_crypto_1.createHash)('sha256').update((0, transaction_parser_1.canonicalJson)(value)).digest('hex'),
        };
    }
    releaseRead(principal, id) {
        return this.repository.releaseRead(principal, id ? (0, tracking_dto_1.normalizeTrackingId)(id) : null);
    }
    async releaseMutate(id, input) {
        let action;
        try {
            action = (0, tracking_dto_1.normalizeAdminTrackingAction)(input.body);
            if (!['create', 'validate', 'publish', 'activate', 'rollback'].includes(action.action))
                throw new Error();
            exact(action.patch, action.action === 'create'
                ? ['snapshot']
                : ['validate', 'publish'].includes(action.action)
                    ? []
                    : ['mode']);
            if (action.action === 'create')
                (0, transaction_parser_1.validateRuleSnapshot)(action.patch.snapshot);
            if (action.action !== 'create' && !id)
                throw new Error();
            if (id)
                id = (0, tracking_dto_1.normalizeTrackingId)(id);
        }
        catch {
            throw this.validation();
        }
        if (action.action === 'validate') {
            const read = await this.repository.releaseRead(input.principal, (0, tracking_dto_1.normalizeTrackingId)(id));
            const releases = read.items;
            if (!releases[0])
                throw new common_1.HttpException({ code: 'TRACKING_RELEASE_NOT_FOUND' }, 404);
            const release = record(releases[0]);
            const snapshot = (0, transaction_parser_1.validateRuleSnapshot)(release.snapshot);
            const failures = transaction_parser_1.evidenceCorpus
                .filter((sample) => {
                const result = (0, transaction_parser_1.classifyFinancialMessage)({ text: sample.text, sender: sample.sender, country: sample.country }, snapshot);
                return Object.entries(sample.expected).some(([key, value]) => Reflect.get(result, key) !== value);
            })
                .map((sample) => sample.id);
            if (failures.length)
                throw new common_1.HttpException({ code: 'TRACKING_CORPUS_FAILED', cases: failures }, 400);
            action.patch = {
                validatedHash: release.contentHash ?? release.content_hash,
                corpusResult: { passed: true, caseCount: transaction_parser_1.evidenceCorpus.length },
            };
        }
        return this.repository.releaseMutate(input.principal, id ? (0, tracking_dto_1.normalizeTrackingId)(id) : null, action.action, action.patch, action.expectedVersion, action.reason, input.idempotencyKey, input.requestId);
    }
    constructor(repository, ledger, storage, identity, config) {
        this.repository = repository;
        this.ledger = ledger;
        this.storage = storage;
        this.identity = identity;
        this.config = config;
    }
    preferences(principal) {
        return this.repository.getPreferences(principal);
    }
    async status(principal) {
        const [preferences, status] = await Promise.all([
            this.repository.getPreferences(principal),
            this.repository.trackingStatus(principal),
        ]);
        return {
            available: true,
            mode: preferences.enabled
                ? preferences.reviewRequired
                    ? 'review_all'
                    : 'automatic_clear'
                : 'paused',
            ...status,
        };
    }
    updatePreferences(input) {
        try {
            const body = record(input.body);
            exact(body, [
                'mode',
                'enabled',
                'reviewRequired',
                'rawRetentionDays',
                'sourceRetentionDays',
                'historyRetentionDays',
                'expectedVersion',
            ]);
            const mode = body.mode == null ? null : boundedText(body.mode, 1, 32);
            if (mode !== null && !['automatic_clear', 'review_all', 'paused'].includes(mode))
                throw new Error();
            if (mode === null &&
                (typeof body.enabled !== 'boolean' || typeof body.reviewRequired !== 'boolean'))
                throw new Error();
            const command = {
                enabled: mode === null ? body.enabled : mode !== 'paused',
                reviewRequired: mode === null ? body.reviewRequired : mode !== 'automatic_clear',
                sourceRetentionDays: body.sourceRetentionDays ?? body.rawRetentionDays ?? 30,
                historyRetentionDays: body.historyRetentionDays ?? 365,
                expectedVersion: (0, tracking_dto_1.normalizeVersion)(body.expectedVersion),
            };
            if (!Number.isInteger(command.sourceRetentionDays) ||
                Number(command.sourceRetentionDays) < 1 ||
                Number(command.sourceRetentionDays) > 365 ||
                !Number.isInteger(command.historyRetentionDays) ||
                Number(command.historyRetentionDays) < 30 ||
                Number(command.historyRetentionDays) > 730)
                throw new Error();
            return this.repository.updatePreferences(input.principal, command, input.idempotencyKey, input.requestId);
        }
        catch {
            throw this.validation();
        }
    }
    list(principal, resource, query) {
        try {
            const filters = (0, tracking_dto_1.normalizeTrackingOwnerFilters)(resource, query);
            const values = record(query ?? {});
            const page = (0, tracking_dto_1.normalizeTrackingList)({ cursor: values.cursor, limit: values.limit });
            const cursor = page.cursor ? (0, tracking_dto_1.decodeTrackingCursor)(page.cursor) : null;
            return this.repository
                .listOwner(principal, resource, null, page.limit + 1, cursor, filters)
                .then((items) => trackingPage(items, page.limit, resource));
        }
        catch {
            throw this.validation();
        }
    }
    detail(principal, resource, id) {
        try {
            id = (0, tracking_dto_1.normalizeTrackingId)(id);
        }
        catch {
            throw this.validation();
        }
        return this.repository
            .listOwner(principal, resource, id, 1)
            .then((items) => items[0] ?? Promise.reject(new common_1.HttpException({ code: 'NOT_FOUND' }, 404)));
    }
    sessionItems(principal, sessionId, itemId, query) {
        try {
            sessionId = (0, tracking_dto_1.normalizeTrackingId)(sessionId);
            if (itemId)
                itemId = (0, tracking_dto_1.normalizeTrackingId)(itemId);
            const filters = (0, tracking_dto_1.normalizeTrackingOwnerFilters)('items', query);
            const values = record(query ?? {});
            const page = (0, tracking_dto_1.normalizeTrackingList)({ cursor: values.cursor, limit: values.limit });
            const cursor = page.cursor ? (0, tracking_dto_1.decodeTrackingCursor)(page.cursor) : null;
            return this.repository
                .listSessionItems(principal, sessionId, itemId, itemId ? 1 : page.limit + 1, cursor, filters)
                .then((items) => itemId
                ? (items[0] ?? Promise.reject(new common_1.HttpException({ code: 'NOT_FOUND' }, 404)))
                : trackingPage(items, page.limit, 'items'));
        }
        catch {
            throw this.validation();
        }
    }
    async createImport(input, contentType, rawBody, sourceName) {
        let normalized, bytes;
        let idempotencyHash;
        try {
            idempotencyHash = (0, idempotency_1.hashIdempotencyKey)(input.idempotencyKey);
            if (contentType === 'text/csv') {
                if (!rawBody)
                    throw new Error();
                const rows = (0, tracking_parser_1.parseTrackingCsv)(rawBody);
                const fileHash = (0, node_crypto_1.createHash)('sha256').update(rawBody).digest('hex');
                normalized = (0, tracking_dto_1.normalizeNormalizedImport)({
                    schemaVersion: 1,
                    sourceType: 'manual',
                    sourceChannel: 'manual',
                    events: rows.map((row, index) => ({
                        sourceItemKey: row.sourceItemKey || `${fileHash}:row:${String(index + 1)}`,
                        receivedAt: row.receivedAt,
                        body: row.body,
                        ...(row.amountMinor ? { amountMinor: Number(row.amountMinor) } : {}),
                        ...(row.currency ? { currency: row.currency } : {}),
                        ...(row.merchant ? { merchant: row.merchant } : {}),
                        ...(row.occurredAt ? { occurredAt: row.occurredAt } : {}),
                        ...(row.accountId ? { accountId: row.accountId } : {}),
                        ...(row.categoryId ? { categoryId: row.categoryId } : {}),
                    })),
                });
                bytes = rawBody;
            }
            else if (contentType === 'application/json') {
                normalized = (0, tracking_dto_1.normalizeNormalizedImport)(input.body);
                bytes = Buffer.from(JSON.stringify(normalized));
            }
            else {
                throw new Error('UNSUPPORTED_FORMAT');
            }
            if (sourceName && (sourceName.includes('/') || sourceName.includes('\\')))
                throw new Error();
        }
        catch (error) {
            const code = error instanceof Error && ['UNSAFE_IMPORT', 'UNSUPPORTED_FORMAT'].includes(error.message)
                ? error.message
                : 'VALIDATION_FAILED';
            const unsupported = rawBody
                ? await this.repository.recordUnsupported(input.principal, (0, node_crypto_1.createHash)('sha256').update(rawBody).digest('hex'), sourceName &&
                    Buffer.byteLength(sourceName, 'utf8') <= 120 &&
                    !unsafeText(sourceName) &&
                    !sourceName.includes('/') &&
                    !sourceName.includes('\\')
                    ? sourceName
                    : null, code)
                : undefined;
            (0, tracking_observability_1.recordTrackingIntake)(rawBody ? 'file' : 'manual', 'rejected');
            throw new common_1.HttpException({ code, ...(unsupported ? { unsupported } : {}) }, code === 'UNSUPPORTED_FORMAT' ? 415 : 400);
        }
        const hash = (0, node_crypto_1.createHash)('sha256').update(bytes).digest('hex');
        const generation = financial_generation_1.financialGeneration.getStore();
        const seed = [hash, idempotencyHash];
        if (generation && generation !== '0')
            seed.push(generation);
        const key = `tracking/${uuidFrom(input.principal.userId)}/${uuidFrom(seed.join('\0'))}`;
        const preferences = await this.repository.getPreferences(input.principal);
        const days = Number(preferences.sourceRetentionDays ?? 30);
        const raw = {
            storageRef: key,
            payloadHash: hash,
            contentType: contentType === 'text/csv' ? 'text/csv' : 'application/json',
            sizeBytes: bytes.length,
            expiresAt: new Date(Date.now() + days * 86_400_000),
        };
        await this.repository.reserveRawUpload(input.principal, raw);
        await this.storage.upload(key, bytes, raw.contentType);
        const created = await this.repository.createImport(input.principal, normalized, {
            sourceName: sourceName ?? null,
            key: input.idempotencyKey,
            requestId: input.requestId,
            raw,
        });
        (0, tracking_observability_1.recordTrackingIntake)(contentType === 'text/csv' ? 'file' : normalized.sourceType, 'accepted');
        return created;
    }
    keyword(input, id) {
        try {
            const body = record(input.body);
            exact(body, [
                'value',
                'group',
                'language',
                'matchType',
                'categoryId',
                'priority',
                'enabled',
                'expectedVersion',
            ]);
            return this.repository.keyword(input.principal, {
                id: id ? (0, tracking_dto_1.normalizeTrackingId)(id) : null,
                keyword: boundedText(body.value, 1, 120),
                groupKey: boundedText(body.group, 1, 40),
                languageCode: boundedText(body.language, 2, 2),
                matchType: body.matchType ?? 'contains',
                categoryId: body.categoryId == null ? null : (0, tracking_dto_1.normalizeTrackingId)(body.categoryId),
                priority: body.priority ?? 100,
                enabled: body.enabled,
                expectedVersion: body.expectedVersion == null ? null : (0, tracking_dto_1.normalizeVersion)(body.expectedVersion),
            }, input.idempotencyKey, input.requestId);
        }
        catch {
            throw this.validation();
        }
    }
    sender(input, id) {
        try {
            const body = record(input.body);
            exact(body, [
                'value',
                'displayLabel',
                'institutionId',
                'trusted',
                'enabled',
                'expectedVersion',
            ]);
            return this.repository.sender(input.principal, {
                id: id ? (0, tracking_dto_1.normalizeTrackingId)(id) : null,
                senderPattern: boundedText(body.value, 1, 256),
                displayLabel: boundedText(body.displayLabel, 1, 120),
                institutionId: body.institutionId == null ? null : (0, tracking_dto_1.normalizeTrackingId)(body.institutionId),
                trusted: body.trusted === true,
                enabled: body.enabled !== false,
                expectedVersion: body.expectedVersion == null ? null : (0, tracking_dto_1.normalizeVersion)(body.expectedVersion),
            }, input.idempotencyKey, input.requestId);
        }
        catch {
            throw this.validation();
        }
    }
    removeRule(kind, id, query, input) {
        try {
            return this.repository.removeRule(input.principal, kind, (0, tracking_dto_1.normalizeTrackingId)(id), (0, tracking_dto_1.normalizeVersion)(Number(query.expectedVersion)), input.idempotencyKey, input.requestId);
        }
        catch {
            throw this.validation();
        }
    }
    restoreKeywords(input) {
        return this.repository.restoreKeywords(input.principal, input.idempotencyKey, input.requestId);
    }
    async decideReview(id, input) {
        let command;
        try {
            const body = record(input.body);
            exact(body, ['decision', 'expectedVersion', 'edit']);
            const decision = boundedText(body.decision, 1, 20);
            if (!['accept', 'reject', 'edit_accept'].includes(decision))
                throw new Error();
            const patch = body.edit == null ? {} : record(body.edit);
            exact(patch, [
                'amountMinor',
                'currency',
                'accountId',
                'destinationAccountId',
                'categoryId',
                'title',
                'merchant',
                'paymentMethod',
                'note',
                'occurredAt',
                'kind',
                'originalTransactionId',
                'originalTransactionVersion',
                'settlementConfirmed',
                'rememberAccountBinding',
            ]);
            if ((patch.rememberAccountBinding !== undefined &&
                typeof patch.rememberAccountBinding !== 'boolean') ||
                (patch.settlementConfirmed !== undefined && typeof patch.settlementConfirmed !== 'boolean'))
                throw new Error();
            if ((decision === 'edit_accept') !== Object.keys(patch).length > 0)
                throw new Error();
            command = {
                decision,
                expectedVersion: (0, tracking_dto_1.normalizeVersion)(body.expectedVersion),
                patch,
            };
            (0, idempotency_1.hashIdempotencyKey)(input.idempotencyKey);
            id = (0, tracking_dto_1.normalizeTrackingId)(id);
        }
        catch {
            throw this.validation();
        }
        const decisionToken = uuidFrom(input.idempotencyKey);
        await this.repository.claimReview(input.principal, id, command.decision, command.expectedVersion, decisionToken);
        if (command.decision === 'reject')
            return this.repository.decideReview(input.principal, id, command, decisionToken, null, null, input.idempotencyKey, input.requestId);
        const review = record(await this.detail(input.principal, 'reviews', id));
        const importItem = record(await this.detail(input.principal, 'items', String(review.importItemId)));
        const sourceKey = `tracking:${await this.repository.getImportSourceIdentityHash(input.principal, String(importItem.id))}`;
        const values = { ...record(review.proposedValues), ...record(command.patch) };
        await this.assertBindingEligibility(input.principal, values);
        if (importItem.canonicalIdentityHash) {
            const existing = await this.repository.captureTransaction(input.principal, String(importItem.id));
            if (existing?.transactionId) {
                await this.assertCaptureAgreement(input.principal, existing.transactionId, values, input.requestId);
                return this.repository.decideReview(input.principal, id, command, decisionToken, null, existing.transactionId, input.idempotencyKey, input.requestId);
            }
        }
        const ledger = await this.createImportedLedgerEntry(input.principal, values, sourceKey, input.requestId);
        const transaction = record(record(ledger.transaction).transaction);
        return this.repository.decideReview(input.principal, id, command, decisionToken, typeof ledger.operationId === 'string' ? ledger.operationId : uuidFrom(input.idempotencyKey), String(transaction.id), input.idempotencyKey, input.requestId);
    }
    async decideDuplicate(id, input) {
        let command;
        try {
            const body = record(input.body);
            exact(body, ['resolution', 'expectedVersion', 'merge']);
            const resolution = boundedText(body.resolution, 1, 24);
            if (!['keep_existing', 'keep_new', 'keep_both', 'merge_details'].includes(resolution))
                throw new Error();
            command = {
                resolution,
                expectedVersion: (0, tracking_dto_1.normalizeVersion)(body.expectedVersion),
                merge: body.merge == null ? {} : record(body.merge),
            };
            exact(command.merge, [
                'title',
                'merchant',
                'categoryId',
                'occurredAt',
            ]);
            if (resolution === 'merge_details' && Object.keys(command.merge).length === 0)
                throw new Error();
            (0, idempotency_1.hashIdempotencyKey)(input.idempotencyKey);
            id = (0, tracking_dto_1.normalizeTrackingId)(id);
        }
        catch {
            throw this.validation();
        }
        const decisionToken = uuidFrom(input.idempotencyKey);
        await this.repository.claimDuplicate(input.principal, id, command.resolution, command.expectedVersion, decisionToken);
        const candidate = record(await this.detail(input.principal, 'duplicates', id));
        if (command.resolution === 'merge_details') {
            const transactionId = String(candidate.rightTransactionId);
            const current = record(record(await this.ledger.getTransaction(input.principal, transactionId, input.requestId))
                .transaction);
            const revision = record(await this.ledger.reviseTransaction({
                principal: input.principal,
                transactionId,
                body: {
                    expectedVersion: current.version,
                    reason: 'Merged details from a reviewed tracking duplicate',
                    ...command.merge,
                },
                idempotencyKey: `tracking-merge:${uuidFrom(input.idempotencyKey)}`,
                requestId: input.requestId,
            }));
            return this.repository.decideDuplicate(input.principal, id, command, decisionToken, typeof revision.operationId === 'string'
                ? revision.operationId
                : uuidFrom(`merge:${input.idempotencyKey}`), transactionId, input.idempotencyKey, input.requestId);
        }
        if (command.resolution === 'keep_existing')
            return this.repository.decideDuplicate(input.principal, id, command, decisionToken, null, String(candidate.rightTransactionId), input.idempotencyKey, input.requestId);
        const item = record(await this.detail(input.principal, 'items', String(candidate.leftItemId)));
        if (item.canonicalIdentityHash) {
            const existing = await this.repository.captureTransaction(input.principal, String(item.id));
            if (existing?.transactionId) {
                await this.assertCaptureAgreement(input.principal, existing.transactionId, record(item.normalizedPayload), input.requestId);
                return this.repository.decideDuplicate(input.principal, id, command, decisionToken, null, existing.transactionId, input.idempotencyKey, input.requestId);
            }
        }
        const sourceKey = `tracking:${await this.repository.getImportSourceIdentityHash(input.principal, String(item.id))}`;
        const values = { ...record(item.normalizedPayload), ...record(command.merge) };
        const ledger = await this.createImportedLedgerEntry(input.principal, values, sourceKey, input.requestId);
        const transaction = record(record(ledger.transaction).transaction);
        return this.repository.decideDuplicate(input.principal, id, command, decisionToken, typeof ledger.operationId === 'string' ? ledger.operationId : uuidFrom(input.idempotencyKey), String(transaction.id), input.idempotencyKey, input.requestId);
    }
    async assertCaptureAgreement(principal, transactionId, values, requestId) {
        const existing = record(record(await this.ledger.getTransaction(principal, transactionId, requestId)).transaction);
        if (!(0, tracking_capture_agreement_1.captureEffectsAgree)(existing, values))
            throw new common_1.HttpException({ code: 'TRACKING_CAPTURE_CONFLICT' }, 409);
    }
    async assertBindingEligibility(principal, values) {
        if (values.rememberAccountBinding !== true)
            return;
        const provider = values.sourceProvider ?? record(values.metadata ?? {}).sourceProvider;
        const configuration = await this.repository.ruleSnapshot(principal);
        const snapshot = (0, transaction_parser_1.validateRuleSnapshot)(configuration.snapshot);
        if (typeof values.accountId !== 'string' ||
            !(await this.repository.accountType(principal, (0, tracking_dto_1.normalizeTrackingId)(values.accountId))) ||
            !snapshot.providers?.some((candidate) => candidate.providerKey === provider) ||
            !Array.isArray(record(values.classification ?? {}).instruments) ||
            !record(values.classification).instruments.length)
            throw new common_1.HttpException({ code: 'TRACKING_BINDING_INVALID' }, 400);
    }
    async createImportedLedgerEntry(principal, values, sourceKey, requestId) {
        const common = {
            principal,
            idempotencyKey: sourceKey,
            requestId,
        };
        if (values.classification) {
            const classification = record(values.classification);
            if (!['completed', 'pending', 'unknown'].includes(String(classification.status)) ||
                (classification.status !== 'completed' && values.settlementConfirmed !== true))
                throw new common_1.HttpException({ code: 'TRACKING_SETTLEMENT_REQUIRED' }, 400);
            if (classification.timeProvenance === 'ambiguous' && !values.occurredAt)
                throw new common_1.HttpException({ code: 'TRACKING_TIME_REQUIRED' }, 400);
        }
        if (values.kind === 'refund' || values.kind === 'reversal') {
            if (!values.originalTransactionId || !values.originalTransactionVersion)
                throw new common_1.HttpException({ code: 'TRACKING_ORIGINAL_TRANSACTION_REQUIRED' }, 400);
            return record(await (values.kind === 'reversal' ||
                record(values.classification ?? {}).subtype === 'reversal'
                ? this.ledger.reverseTransaction({
                    ...common,
                    transactionId: (0, tracking_dto_1.normalizeTrackingId)(values.originalTransactionId),
                    body: {
                        expectedVersion: values.originalTransactionVersion,
                        occurredAt: values.occurredAt,
                        reason: 'Reviewed tracking reversal',
                    },
                })
                : this.ledger.refundTransaction({
                    ...common,
                    transactionId: (0, tracking_dto_1.normalizeTrackingId)(values.originalTransactionId),
                    body: {
                        expectedVersion: values.originalTransactionVersion,
                        amountMinor: Math.abs(Number(values.amountMinor)),
                        accountId: values.accountId,
                        occurredAt: values.occurredAt,
                        reason: 'Reviewed tracking refund',
                    },
                })));
        }
        if (record(values.classification ?? {}).subtype === 'withdrawal' &&
            (values.kind !== 'transfer' ||
                typeof values.destinationAccountId !== 'string' ||
                (await this.repository.accountType(principal, (0, tracking_dto_1.normalizeTrackingId)(values.destinationAccountId))) !== 'cash'))
            throw new common_1.HttpException({ code: 'TRACKING_CASH_ACCOUNT_REQUIRED' }, 400);
        if (values.kind === 'transfer')
            return record(await this.ledger.transfer({
                ...common,
                body: {
                    sourceAccountId: record(values.classification ?? {}).direction === 'incoming'
                        ? values.destinationAccountId
                        : values.accountId,
                    destinationAccountId: record(values.classification ?? {}).direction === 'incoming'
                        ? values.accountId
                        : values.destinationAccountId,
                    amountMinor: Math.abs(Number(values.amountMinor)),
                    currency: values.currency,
                    feeMinor: 0,
                    occurredAt: values.occurredAt,
                    title: values.title ?? values.merchant ?? 'Imported transaction',
                    note: values.note ?? null,
                },
            }));
        return record(await this.ledger.createTransaction({
            ...common,
            body: {
                kind: values.kind === 'fee' ? 'expense' : values.kind,
                amountMinor: Math.abs(Number(values.amountMinor)),
                currency: values.currency,
                accountId: values.accountId,
                categoryId: values.categoryId ?? null,
                title: values.title ?? values.merchant ?? 'Imported transaction',
                merchant: values.merchant ?? null,
                paymentMethod: values.paymentMethod ?? null,
                note: values.note ?? null,
                occurredAt: values.occurredAt,
                source: 'tracking-import',
                externalRef: sourceKey,
            },
        }));
    }
    feedback(input) {
        try {
            const body = record(input.body);
            exact(body, ['historyId', 'kind', 'correctedCategoryId', 'comment']);
            const kind = boundedText(body.kind, 1, 40);
            if (![
                'wrong_detection',
                'wrong_category',
                'wrong_merchant',
                'duplicate_missed',
                'other',
            ].includes(kind))
                throw new Error();
            if (body.correctedCategoryId != null && kind !== 'wrong_category')
                throw new Error();
            return this.repository.feedback(input.principal, {
                historyId: (0, tracking_dto_1.normalizeTrackingId)(body.historyId),
                feedbackType: kind,
                correctedCategoryId: body.correctedCategoryId == null ? null : (0, tracking_dto_1.normalizeTrackingId)(body.correctedCategoryId),
                comment: body.comment == null ? null : boundedText(body.comment, 1, 500),
            }, input.idempotencyKey, input.requestId);
        }
        catch {
            throw this.validation();
        }
    }
    async adminRead(principal, resource, id, query) {
        try {
            const values = record(query);
            exact(values, [
                'cursor',
                'limit',
                'purpose',
                'search',
                'status',
                'severity',
                'sourceType',
                'institutionId',
                'parserVersionId',
                'from',
                'to',
            ]);
            const filters = Object.fromEntries(Object.entries(values)
                .filter(([key, value]) => !['cursor', 'limit', 'purpose'].includes(key) && value != null && value !== '')
                .map(([key, value]) => [key, String(value).trim()])
                .sort(([a], [b]) => a.localeCompare(b)));
            const page = (0, tracking_dto_1.normalizeTrackingList)({ limit: values.limit });
            const scope = (0, node_crypto_1.createHash)('sha256')
                .update(JSON.stringify([principal.userId, resource, page.limit, filters]))
                .digest('hex');
            let cursor = null;
            if (values.cursor) {
                const saved = JSON.parse(Buffer.from(boundedText(values.cursor, 1, 512), 'base64url').toString('utf8'));
                if (saved.scope !== scope)
                    throw new Error('CURSOR_SCOPE_CHANGED');
                cursor = (0, tracking_dto_1.decodeTrackingCursor)(saved.position);
            }
            for (const key of [
                'search',
                'status',
                'severity',
                'sourceType',
                'institutionId',
                'parserVersionId',
                'from',
                'to',
            ])
                if (values[key] != null)
                    boundedText(values[key], 1, 128);
            const purpose = values.purpose == null ? null : boundedText(values.purpose, 10, 500);
            const response = await this.repository.adminRead(principal, resource, id ? (0, tracking_dto_1.normalizeTrackingId)(id) : null, id ? 1 : page.limit + 1, purpose, cursor, filters);
            if (id) {
                const entries = Array.isArray(response) ? response : [];
                return entries[0] ?? Promise.reject(new common_1.HttpException({ code: 'NOT_FOUND' }, 404));
            }
            if (!Array.isArray(response))
                return response;
            const result = trackingPage(response, page.limit, resource);
            if (typeof result.nextCursor === 'string')
                result.nextCursor = Buffer.from(JSON.stringify({ scope, position: result.nextCursor })).toString('base64url');
            return result;
        }
        catch {
            throw this.validation();
        }
    }
    publishVersion(id, input) {
        try {
            const action = (0, tracking_dto_1.normalizeAdminTrackingAction)(input.body);
            if (action.action !== 'publish')
                throw new Error();
            return this.repository.publishVersion(input.principal, (0, tracking_dto_1.normalizeTrackingId)(id), action.expectedVersion, action.reason, input.idempotencyKey, input.requestId);
        }
        catch {
            throw this.validation();
        }
    }
    adminMutate(resource, id, input) {
        try {
            const action = (0, tracking_dto_1.normalizeAdminTrackingAction)(input.body);
            const policies = {
                sessions: { actions: ['retry', 'retry_handoff', 'cancel'], fields: [] },
                failures: {
                    actions: [
                        'retry_handoff',
                        'assign_parser_issue',
                        'mark_unsupported',
                        'create_rule_draft_handoff',
                        'save',
                    ],
                    fields: [],
                },
                'low-confidence': {
                    actions: [
                        'accept_suggestion',
                        'correct_merchant',
                        'correct_category',
                        'defer',
                        'mark_unsupported',
                    ],
                    fields: ['title', 'merchant', 'categoryId'],
                },
                duplicates: { actions: ['confirm_duplicate', 'reject_match', 'defer'], fields: [] },
                unsupported: {
                    actions: [
                        'acknowledge',
                        'ignore',
                        'covered',
                        'assign_parser_issue',
                        'mark_unsupported',
                        'create_rule_draft_handoff',
                        'defer',
                    ],
                    fields: [],
                },
                institutions: {
                    actions: ['create', 'save', 'deactivate'],
                    fields: ['countryCode', 'name', 'code', 'active'],
                },
                senders: {
                    actions: ['create', 'save', 'activate', 'deactivate'],
                    fields: ['institutionId', 'senderPattern', 'displayLabel', 'priority', 'active'],
                },
                rules: {
                    actions: ['create', 'save', 'activate', 'deactivate'],
                    fields: ['institutionId', 'name', 'sourceType'],
                },
                versions: {
                    actions: ['create', 'retire', 'rollback'],
                    fields: ['ruleId', 'versionNo', 'definition'],
                },
                'test-cases': {
                    actions: ['create', 'save', 'activate', 'deactivate'],
                    fields: ['parserVersionId', 'name', 'inputFixture', 'expectedOutput', 'enabled'],
                },
                'merchant-rules': {
                    actions: ['create', 'save', 'activate', 'deactivate'],
                    fields: ['pattern', 'normalizedMerchant', 'priority', 'active'],
                },
                'category-rules': {
                    actions: ['create', 'save', 'activate', 'deactivate'],
                    fields: ['pattern', 'categoryId', 'priority', 'active'],
                },
                settings: {
                    actions: ['save'],
                    fields: ['rawRetentionDays', 'historyRetentionDays', 'maxCsvBytes', 'maxRows'],
                },
            };
            const policy = policies[resource];
            if (!policy || !policy.actions.includes(action.action))
                throw new Error();
            exact(action.patch, policy.fields);
            if (resource === 'low-confidence' &&
                ((action.action === 'correct_merchant' &&
                    (Object.keys(action.patch).length === 0 ||
                        Object.keys(action.patch).some((key) => !['title', 'merchant'].includes(key)))) ||
                    (action.action === 'correct_category' &&
                        (Object.keys(action.patch).length !== 1 ||
                            Object.keys(action.patch).some((key) => key !== 'categoryId'))) ||
                    (!['correct_merchant', 'correct_category'].includes(action.action) &&
                        Object.keys(action.patch).length > 0)))
                throw new Error();
            if (resource === 'versions' && id === null)
                (0, tracking_parser_1.validateParserDefinition)(action.patch.definition);
            return this.repository.adminMutate(input.principal, resource, id ? (0, tracking_dto_1.normalizeTrackingId)(id) : null, action.action, action.patch, action.expectedVersion, action.reason, input.idempotencyKey, input.requestId);
        }
        catch {
            throw this.validation();
        }
    }
    async parserPreview(principal, ruleId, body) {
        try {
            const input = record(body);
            exact(input, ['sample']);
            const preview = record(await this.repository.parserPreview(principal, (0, tracking_dto_1.normalizeTrackingId)(ruleId)));
            return (0, tracking_parser_1.executeParserDefinition)((0, tracking_parser_1.validateParserDefinition)(preview.definition), {
                body: boundedText(input.sample, 1, 4096),
                sender: '',
            });
        }
        catch {
            throw this.validation();
        }
    }
    createParserVersion(ruleId, input) {
        try {
            const action = (0, tracking_dto_1.normalizeAdminTrackingAction)(input.body);
            exact(action.patch, ['versionNo', 'definition']);
            return this.adminMutate('versions', null, {
                ...input,
                body: {
                    ...action,
                    patch: { ...action.patch, ruleId: (0, tracking_dto_1.normalizeTrackingId)(ruleId) },
                },
            });
        }
        catch {
            throw this.validation();
        }
    }
    async runCorpus(versionId, input) {
        let normalizedVersionId;
        let reason;
        try {
            const action = (0, tracking_dto_1.normalizeAdminTrackingAction)(input.body);
            if (action.action !== 'run')
                throw new Error();
            if (versionId === null) {
                exact(action.patch, ['versionId']);
                if (Object.keys(action.patch).length !== 1)
                    throw new Error();
                normalizedVersionId = (0, tracking_dto_1.normalizeTrackingId)(action.patch.versionId);
            }
            else {
                normalizedVersionId = (0, tracking_dto_1.normalizeTrackingId)(versionId);
                if (Object.keys(action.patch).length)
                    throw new Error();
            }
            reason = action.reason;
        }
        catch {
            throw this.validation();
        }
        return this.repository.queueParserCorpus(input.principal, normalizedVersionId, reason, input.idempotencyKey, input.requestId);
    }
    validation() {
        return new common_1.HttpException({ code: 'VALIDATION_FAILED' }, 400);
    }
};
exports.TrackingService = TrackingService;
exports.TrackingService = TrackingService = __decorate([
    (0, common_1.Injectable)(),
    __param(3, (0, common_1.Optional)()),
    __param(4, (0, common_1.Optional)()),
    __metadata("design:paramtypes", [tracking_repository_1.TrackingRepository,
        ledger_service_1.LedgerService,
        tracking_storage_1.TrackingStorage,
        identity_repository_1.IdentityRepository,
        platform_config_service_1.PlatformConfigService])
], TrackingService);
