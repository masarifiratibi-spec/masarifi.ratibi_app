"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.TrackingRepository = void 0;
const node_crypto_1 = require("node:crypto");
const common_1 = require("@nestjs/common");
const idempotency_1 = require("../ledger/idempotency");
const pool_service_1 = require("../platform/database/pool.service");
function stableUuid(seed) {
    const bytes = (0, node_crypto_1.createHash)('sha256').update(seed).digest().subarray(0, 16);
    bytes[6] = ((bytes[6] ?? 0) & 0x0f) | 0x40;
    bytes[8] = ((bytes[8] ?? 0) & 0x3f) | 0x80;
    const hex = bytes.toString('hex');
    return `${hex.slice(0, 8)}-${hex.slice(8, 12)}-${hex.slice(12, 16)}-${hex.slice(16, 20)}-${hex.slice(20)}`;
}
function camel(key) {
    return key.replace(/_([a-z])/g, (_match, letter) => letter.toUpperCase());
}
function publicValue(value) {
    if (value instanceof Date)
        return value.toISOString();
    if (Array.isArray(value))
        return value.map(publicValue);
    if (!value || typeof value !== 'object')
        return value;
    return Object.fromEntries(Object.entries(value).map(([key, child]) => [
        camel(key),
        publicValue(child),
    ]));
}
function mappedError(error) {
    const message = error && typeof error === 'object' && 'message' in error
        ? String(Reflect.get(error, 'message'))
        : '';
    if (/CONFLICT|STALE|IN_PROGRESS|REUSED/.test(message))
        return new common_1.HttpException({ code: message }, 409);
    if (/NOT_FOUND/.test(message))
        return new common_1.HttpException({ code: message }, 404);
    if (/QUOTA_EXCEEDED/.test(message))
        return new common_1.HttpException({ code: message }, 429);
    if (/INVALID|LIMIT|REQUIRED/.test(message))
        return new common_1.HttpException({ code: message }, 400);
    return error instanceof Error ? error : new Error('TRACKING_DATABASE_UNAVAILABLE');
}
let TrackingRepository = class TrackingRepository {
    pool;
    constructor(pool) {
        this.pool = pool;
    }
    updateInstallationConsent(principal, input) {
        return this.ownerJson(principal, 'select private.configure_tracking_installation($1,$2::uuid,$3::uuid,$4::integer,$5::jsonb) result', [
            principal.userId,
            input.deviceId,
            input.notificationDeviceId,
            input.expectedVersion,
            JSON.stringify(input.sources),
        ]);
    }
    enrollInstallation(principal, input) {
        return this.ownerJson(principal, 'select private.enroll_dev_mobile_installation($1,$2,$3::uuid,$4,$5,$6,$7,$8) result', [
            principal.userId,
            input.deviceId,
            input.notificationDeviceId,
            input.smsActivationId,
            input.remindersEnabled,
            input.foreground,
            input.reminderLocale,
            input.reminderTimeZone,
        ]);
    }
    ruleSnapshot(principal, deviceId) {
        return deviceId === undefined
            ? this.ownerJson(principal, 'select private.get_tracking_rule_snapshot($1) result', [
                principal.userId,
            ])
            : this.ownerJson(principal, 'select private.get_tracking_device_rule_snapshot($1,$2) result', [principal.userId, deviceId]);
    }
    confirmation(principal, id) {
        return this.ownerJson(principal, 'select private.get_tracking_confirmation($1,$2::uuid) result', [principal.userId, id]);
    }
    captureTransaction(principal, itemId) {
        return this.owner(principal, async (client) => (await client.query('select private.read_tracking_capture_transaction($1,$2::uuid) capture', [
            principal.userId,
            itemId,
        ])).rows[0]?.capture ?? null);
    }
    releaseRead(principal, id) {
        return this.ownerJson(principal, "select jsonb_build_object('items',private.read_tracking_releases($1::uuid)) result", [id]);
    }
    releaseMutate(principal, id, action, patch, version, reason, key, requestId) {
        return this.idempotent(principal, 'tracking.admin.release.' + action, key, { id, action, patch, version, reason }, 200, requestId, (client) => this.queryJson(client, 'select private.mutate_tracking_release($1::uuid,$2,$3::jsonb,$4,$5,$6) result', [id, action, JSON.stringify(patch), version, reason, principal.userId]), true);
    }
    accountType(principal, id) {
        return this.owner(principal, async (client) => (await client.query("select type from public.accounts where id=$1::uuid and user_id=$2 and status='active'", [id, principal.userId])).rows[0]?.type ?? null);
    }
    reserveCapture(itemId, fence) {
        return this.claimedWorker('item', itemId, fence, (client) => this.queryJson(client, 'select private.reserve_tracking_capture($1::uuid,$2::uuid) result', [
            itemId,
            fence,
        ]));
    }
    commitNominalCapture(itemId, fence) {
        return this.claimedWorker('item', itemId, fence, (client) => this.queryJson(client, 'select private.commit_tracking_nominal_capture($1::uuid,$2::uuid) result', [itemId, fence]));
    }
    getPreferences(principal) {
        return this.ownerJson(principal, 'select private.get_tracking_preferences($1) result', [
            principal.userId,
        ]);
    }
    trackingStatus(principal) {
        return this.ownerJson(principal, `select jsonb_build_object(
        'lastDetectedAt',(select max(h.occurred_at) from public.tracking_history h where h.user_id=$1),
        'lastSuccessfulTransactionId',(select h.transaction_id from public.tracking_history h where h.user_id=$1 and h.outcome='accepted' and h.transaction_id is not null order by h.occurred_at desc,h.id desc limit 1),
        'detectedThisMonth',(select count(*) from public.tracking_history h where h.user_id=$1 and h.occurred_at>=date_trunc('month',clock_timestamp())),
        'reviewCount',(select count(*) from public.review_items r where r.user_id=$1 and r.status='pending'),
        'activeKeywordCount',(select count(*) from public.user_keyword_rules k where k.user_id=$1 and k.enabled),
        'activeSenderCount',(select count(*) from public.user_sender_rules s where s.user_id=$1 and s.enabled),
        'lastUpdatedAt',greatest(p.updated_at,coalesce((select max(h.occurred_at) from public.tracking_history h where h.user_id=$1),p.updated_at))
      ) result from public.tracking_preferences p where p.user_id=$1`, [principal.userId]);
    }
    updatePreferences(principal, command, key, requestId) {
        return this.idempotent(principal, 'tracking.preferences.update', key, command, 200, requestId, (client) => this.queryJson(client, 'select private.update_tracking_preferences($1,$2,$3,$4,$5,$6) result', [
            principal.userId,
            command.enabled,
            command.reviewRequired,
            command.sourceRetentionDays,
            command.historyRetentionDays,
            command.expectedVersion,
        ]));
    }
    listOwner(principal, table, id, limit, cursor = null, filters = {}) {
        const allowed = {
            keywords: 'user_keyword_rules',
            senders: 'user_sender_rules',
            sessions: 'import_sessions',
            items: 'import_items',
            reviews: 'review_items',
            duplicates: 'duplicate_candidates',
            history: 'tracking_history',
        };
        const name = allowed[table];
        if (!name)
            throw new Error('TRACKING_RESOURCE_INVALID');
        const cursorColumn = name === 'import_sessions'
            ? 'started_at'
            : name === 'import_items'
                ? 'coalesce(occurred_at,created_at)'
                : name === 'tracking_history'
                    ? 'occurred_at'
                    : 'created_at';
        const sensitive = name === 'import_sessions'
            ? "-'request_hash'-'claim_token'-'claimed_by'-'lease_until'-'last_error_code'"
            : name === 'user_keyword_rules'
                ? "-'deleted_at'||jsonb_build_object('recent_use_count',(select count(*) from public.import_items i where i.user_id=x.user_id and x.id=any(i.applied_rule_ids)),'last_used_at',(select max(i.occurred_at) from public.import_items i where i.user_id=x.user_id and x.id=any(i.applied_rule_ids)))"
                : name === 'user_sender_rules'
                    ? "||jsonb_build_object('recent_use_count',(select count(*) from public.import_items i where i.user_id=x.user_id and lower(i.normalized_payload->>'sender')=lower(x.sender_pattern)),'last_used_at',(select max(i.occurred_at) from public.import_items i where i.user_id=x.user_id and lower(i.normalized_payload->>'sender')=lower(x.sender_pattern)))"
                    : name === 'import_items'
                        ? "-'source_hash'-'normalized_hash'||jsonb_build_object('normalized_payload',x.normalized_payload-'body'-'sender'-'metadata'-'sourceText','notification_id',(select n.id from public.notification_events n where n.user_id=x.user_id and n.data->>'targetId'=x.transaction_id::text and n.type in ('transaction.created','transfer.created','transaction.refunded','transaction.reversed') order by n.created_at limit 1))"
                        : name === 'review_items'
                            ? "-'decision_token'-'decision_lease_until'"
                            : name === 'duplicate_candidates'
                                ? "-'decision_token'-'decision_lease_until'"
                                : '';
        const predicates = {
            keywords: 'and deleted_at is null',
            sessions: 'and ($6::text is null or status=$6) and ($7::text is null or source_type=$7)',
            reviews: 'and ($6::text is null or status=$6)',
            duplicates: 'and ($6::text is null or status=$6) and ($8::integer is null or score*10000 >= $8)',
            history: 'and ($9::text is null or outcome=$9) and ($7::text is null or source_type=$7)',
        };
        return this.owner(principal, async (client) => {
            const rows = await client.query(`select to_jsonb(x)${sensitive} value from public.${name} x
         where user_id=$1 and ($2::uuid is null or id=$2)
           and ($4::timestamptz is null or (${cursorColumn},id)<($4::timestamptz,$5::uuid))
           ${predicates[table] ?? ''}
           and ($6::text is null or true) and ($7::text is null or true)
           and ($8::integer is null or true) and ($9::text is null or true)
         order by ${cursorColumn} desc,id desc limit $3`, [
                principal.userId,
                id,
                limit,
                cursor?.at ?? null,
                cursor?.id ?? null,
                filters.status ?? null,
                filters.sourceType ?? null,
                filters.minScore ?? null,
                filters.outcome ?? null,
            ]);
            return rows.rows.map((row) => publicValue(row.value));
        });
    }
    listSessionItems(principal, sessionId, itemId, limit, cursor = null, filters = {}) {
        return this.owner(principal, async (client) => {
            const rows = await client.query(`select to_jsonb(i)-'user_id'-'source_hash'-'normalized_hash'||jsonb_build_object('normalized_payload',i.normalized_payload-'body'-'sender'-'metadata'-'sourceText','notification_id',(select n.id from public.notification_events n where n.user_id=i.user_id and n.data->>'targetId'=i.transaction_id::text and n.type in ('transaction.created','transfer.created','transaction.refunded','transaction.reversed') order by n.created_at,n.id limit 1)) value from public.import_items i
         where user_id=$1 and session_id=$2::uuid and ($3::uuid is null or id=$3)
           and ($5::timestamptz is null or (coalesce(occurred_at,created_at),id)<($5::timestamptz,$6::uuid))
           and ($7::text is null or status=$7)
         order by coalesce(occurred_at,created_at) desc,id desc limit $4`, [
                principal.userId,
                sessionId,
                itemId,
                limit,
                cursor?.at ?? null,
                cursor?.id ?? null,
                filters.status ?? null,
            ]);
            return rows.rows.map((row) => publicValue(row.value));
        });
    }
    getImportSourceIdentityHash(principal, itemId) {
        return this.owner(principal, async (client) => {
            const row = (await client.query(`select s.source_type,i.source_item_key,i.canonical_identity_hash from public.import_items i
           join public.import_sessions s on s.id=i.session_id and s.user_id=i.user_id
           where i.id=$1::uuid and i.user_id=$2`, [itemId, principal.userId])).rows[0];
            if (!row)
                throw new common_1.HttpException({ code: 'IMPORT_ITEM_NOT_FOUND' }, 404);
            if (row.canonical_identity_hash)
                return row.canonical_identity_hash;
            return (0, node_crypto_1.createHash)('sha256')
                .update(`${row.source_type}\0${row.source_item_key}`)
                .digest('hex');
        });
    }
    reserveRawUpload(principal, raw) {
        return this.owner(principal, async (client) => {
            await client.query('select private.reserve_tracking_upload($1,$2,$3,$4,$5)', [
                principal.userId,
                raw.storageRef,
                raw.payloadHash,
                raw.contentType,
                raw.sizeBytes,
            ]);
        });
    }
    async createImport(principal, input, request) {
        const replayCommand = {
            ...input,
            events: input.events.map((event) => Object.fromEntries(Object.entries(event).filter(([key]) => key !== 'receivedAt'))),
        };
        return this.idempotent(principal, 'tracking.import.create', request.key, replayCommand, 201, request.requestId, async (client) => {
            await this.queryJson(client, 'select private.reserve_user_job_quota($1,$2,$3) result', [
                principal.userId,
                'import',
                (0, idempotency_1.hashIdempotencyKey)(request.key),
            ]);
            if (input.events.length &&
                (input.sourceType === 'sms' || input.sourceChannel === 'android_notification')) {
                const boundary = await client.query('select reset_at >= $2::timestamptz as stale from private.financial_reset_state($1)', [
                    principal.userId,
                    new Date(Math.min(...input.events.map((event) => Date.parse(event.receivedAt)))),
                ]);
                if (boundary.rows[0]?.stale)
                    throw new common_1.HttpException({ code: 'FINANCIAL_CAPTURE_BEFORE_RESET' }, 409);
            }
            const requestHash = (0, idempotency_1.hashNormalizedCommand)(input).replace('sha256:', '');
            const sourceType = input.sourceType;
            const row = await this.queryJson(client, 'select private.create_import_session($1,$2,$3,$6,$4,$5::jsonb) result', [
                principal.userId,
                sourceType,
                request.sourceName,
                requestHash,
                JSON.stringify(input.events),
                input.schemaVersion,
            ]);
            if (request.raw)
                await this.queryJson(client, 'select private.register_raw_ingestion_payload($1,$2::uuid,$3,$4,$5,$6,$7) result', [
                    principal.userId,
                    row.id,
                    request.raw.storageRef,
                    request.raw.payloadHash,
                    request.raw.contentType,
                    request.raw.sizeBytes,
                    request.raw.expiresAt,
                ]);
            return row;
        });
    }
    recordUnsupported(principal, contentHash, sourceName, reason) {
        return this.ownerJson(principal, 'select private.record_unsupported_import($1,$2,$3,$4) result', [principal.userId, contentHash, sourceName, reason]);
    }
    keyword(principal, command, key, requestId) {
        return this.idempotent(principal, 'tracking.keyword.mutate', key, command, command.id ? 200 : 201, requestId, (client) => this.queryJson(client, 'select private.upsert_keyword_rule($1,$2,$3,$4,$5,$6,$7,$8,$9,$10) result', [
            principal.userId,
            command.id,
            command.keyword,
            command.groupKey,
            command.languageCode,
            command.matchType,
            command.categoryId,
            command.priority,
            command.enabled,
            command.expectedVersion,
        ]));
    }
    sender(principal, command, key, requestId) {
        return this.idempotent(principal, 'tracking.sender.mutate', key, command, command.id ? 200 : 201, requestId, (client) => this.queryJson(client, 'select private.upsert_sender_rule($1,$2,$3,$4,$5,$6,$7,$8) result', [
            principal.userId,
            command.id,
            command.senderPattern,
            command.displayLabel,
            command.institutionId,
            command.trusted,
            command.enabled,
            command.expectedVersion,
        ]));
    }
    removeRule(principal, kind, id, version, key, requestId) {
        return this.idempotent(principal, `tracking.${kind}.delete`, key, { id, version }, 204, requestId, async (client) => {
            await client.query(`select private.delete_${kind}_rule($1,$2::uuid,$3)`, [
                principal.userId,
                id,
                version,
            ]);
            return { id };
        });
    }
    restoreKeywords(principal, key, requestId) {
        return this.idempotent(principal, 'tracking.keyword.restore', key, {}, 200, requestId, async (client) => ({
            restored: Number((await client.query('select private.restore_default_keyword_rules($1) result', [principal.userId])).rows[0]?.result ?? 0),
        }));
    }
    claimReview(principal, id, decision, expectedVersion, decisionToken) {
        return this.owner(principal, (client) => this.queryJson(client, 'select private.claim_review_decision($1,$2::uuid,$3,$4,$5::uuid,120) result', [principal.userId, id, decision, expectedVersion, decisionToken]));
    }
    decideReview(principal, id, command, decisionToken, operationId, transactionId, key, requestId) {
        return this.idempotent(principal, 'tracking.review.decide', key, { id, ...command }, 200, requestId, async (client) => {
            return this.queryJson(client, 'select private.decide_review_item($1,$2::uuid,$3,$4::jsonb,$5::uuid,$6::uuid,$7::uuid) result', [
                principal.userId,
                id,
                command.decision,
                JSON.stringify(command.patch ?? {}),
                decisionToken,
                operationId,
                transactionId,
            ]);
        });
    }
    claimDuplicate(principal, id, resolution, expectedVersion, decisionToken) {
        return this.owner(principal, (client) => this.queryJson(client, 'select private.claim_duplicate_decision($1,$2::uuid,$3,$4,$5::uuid,120) result', [principal.userId, id, resolution, expectedVersion, decisionToken]));
    }
    decideDuplicate(principal, id, command, decisionToken, operationId, transactionId, key, requestId) {
        return this.idempotent(principal, 'tracking.duplicate.decide', key, { id, ...command }, 200, requestId, async (client) => {
            return this.queryJson(client, 'select private.decide_duplicate_candidate($1,$2::uuid,$3,$4::uuid,$5::uuid,$6::uuid) result', [principal.userId, id, command.resolution, decisionToken, operationId, transactionId]);
        });
    }
    feedback(principal, command, key, requestId) {
        return this.idempotent(principal, 'tracking.feedback.create', key, command, 201, requestId, (client) => this.queryJson(client, 'select private.record_tracking_feedback($1,$2::uuid,$3,$4::uuid,$5) result', [
            principal.userId,
            command.historyId,
            command.feedbackType,
            command.correctedCategoryId,
            command.comment,
        ]));
    }
    clearHistory(principal, key, requestId) {
        return this.idempotent(principal, 'tracking.history.clear', key, {}, 204, requestId, async (client) => ({
            cleared: Number((await client.query('select private.clear_tracking_history($1) result', [principal.userId])).rows[0]?.result ?? 0),
        }));
    }
    adminRead(principal, resource, id, limit, purpose, cursor, filters) {
        return this.owner(principal, async (client) => publicValue((await client.query('select private.read_tracking_admin($1,$2::uuid,$3,$4,$5,$6::timestamptz,$7::uuid,$8::jsonb) result', [
            resource,
            id,
            limit,
            purpose,
            principal.userId,
            cursor?.at ?? null,
            cursor?.id ?? null,
            JSON.stringify(filters),
        ])).rows[0]?.result));
    }
    publishVersion(principal, id, expectedVersion, reason, key, requestId) {
        return this.idempotent(principal, 'tracking.parser.publish', key, { id, expectedVersion, reason }, 200, requestId, (client) => this.queryJson(client, 'select private.publish_parser_version($1::uuid,$2,$3,$4) result', [
            id,
            expectedVersion,
            principal.userId,
            reason,
        ]), true);
    }
    adminMutate(principal, resource, id, action, patch, expectedVersion, reason, key, requestId) {
        const command = { resource, id, action, patch, expectedVersion, reason };
        return this.idempotent(principal, `tracking.admin.${resource}`, key, command, 200, requestId, (client) => this.queryJson(client, 'select private.mutate_tracking_admin($1,$2::uuid,$3,$4::jsonb,$5,$6,$7) result', [resource, id, action, JSON.stringify(patch), expectedVersion, reason, principal.userId]), true);
    }
    parserPreview(principal, ruleId) {
        return this.ownerJson(principal, 'select private.read_parser_preview($1::uuid) result', [
            ruleId,
        ]);
    }
    queueParserCorpus(principal, versionId, reason, key, requestId) {
        return this.idempotent(principal, 'tracking.parser.corpus', key, { versionId, reason }, 202, requestId, (client) => this.queryJson(client, 'select private.queue_parser_corpus($1::uuid,$2,$3) result', [
            versionId,
            principal.userId,
            reason,
        ]), true);
    }
    claimParserCorpus(workerId) {
        return this.worker(async (client) => (await client.query('select * from private.claim_parser_corpus($1,20,60)', [workerId])).rows);
    }
    prepareParserCorpus(id, token) {
        return this.worker((client) => this.queryJson(client, 'select private.read_parser_corpus($1::uuid,$2::uuid) result', [
            id,
            token,
        ]));
    }
    completeParserCorpus(id, token, results, errorCode) {
        return this.worker((client) => this.queryJson(client, 'select private.complete_parser_corpus($1::uuid,$2::uuid,$3::jsonb,$4) result', [id, token, results ? JSON.stringify(results) : null, errorCode]));
    }
    claimImports(workerId) {
        return this.worker(async (client) => (await client.query("select w.*, private.bind_financial_worker_generation('import',w.id,w.claim_token)::text generation from private.claim_import_session($1,100,60) w", [workerId])).rows);
    }
    completeImport(id, token, status, code) {
        return this.claimedWorker('session', id, token, async (client) => {
            await client.query('select private.complete_import_attempt($1::uuid,$2::uuid,$3,$4)', [
                id,
                token,
                status,
                code,
            ]);
        });
    }
    prepareImport(id, token) {
        return this.claimedWorker('session', id, token, async (client) => publicValue(await this.queryJson(client, 'select private.prepare_import_session($1::uuid,$2::uuid) result', [id, token])));
    }
    applyParserResult(id, token, result) {
        return this.claimedWorker('item', id, token, async (client) => {
            await client.query('select private.apply_parser_result($1::uuid,$2::uuid,$3::jsonb)', [
                id,
                token,
                JSON.stringify(result),
            ]);
        });
    }
    finalizeImport(id, token) {
        return this.claimedWorker('session', id, token, (client) => this.queryJson(client, 'select private.finalize_import_session($1::uuid,$2::uuid) result', [
            id,
            token,
        ]));
    }
    acceptImportItem(id, token, operationId, transactionId) {
        return this.claimedWorker('item', id, token, async (client) => {
            await client.query('select private.accept_import_item($1::uuid,$2::uuid,$3::uuid,$4::uuid)', [
                id,
                token,
                operationId,
                transactionId,
            ]);
        });
    }
    deferImportItem(id, token, reason) {
        return this.claimedWorker('item', id, token, async (client) => {
            await client.query('select private.defer_import_item($1::uuid,$2::uuid,$3)', [
                id,
                token,
                reason,
            ]);
        });
    }
    maintenance() {
        return this.worker(async (client) => {
            await client.query('select private.compact_tracking_history(1000)');
            await client.query('select private.reconcile_import_sessions(1000)');
        });
    }
    operationalMetrics() {
        return this.worker((client) => this.queryJson(client, 'select private.tracking_operational_metrics() result', []));
    }
    rawDue() {
        return this.worker(async (client) => (await client.query('select * from private.purge_raw_ingestion_payloads(100)')).rows);
    }
    completeRaw(id, purgeToken) {
        return this.worker(async (client) => {
            const row = (await client.query('select private.complete_raw_ingestion_purge($1::uuid,$2::uuid) completed', [id, purgeToken])).rows[0];
            return row?.completed === true;
        });
    }
    async idempotent(principal, scope, key, command, status, requestId, action, admin = false) {
        try {
            return await this.owner(principal, async (client) => {
                const keyHash = (0, idempotency_1.hashIdempotencyKey)(key), requestHash = (0, idempotency_1.hashNormalizedCommand)(command);
                const claim = (await client.query(admin
                    ? 'select * from private.claim_tracking_admin_idempotency($1,$2,$3,$4,$5::interval)'
                    : 'select * from private.claim_sync_idempotency_key($1,$2,$3,$4,$5::interval)', [principal.userId, scope, keyHash, requestHash, '2 minutes'])).rows[0];
                if (!claim)
                    throw new Error('IDEMPOTENCY_REPLAY_UNAVAILABLE');
                if (claim.outcome === 'replay')
                    return { ...(claim.response_body ?? {}), replayed: true };
                if (claim.outcome === 'hash_mismatch')
                    throw new Error('IDEMPOTENCY_KEY_REUSED');
                if (claim.outcome === 'in_progress' || !claim.lease_token)
                    throw new Error('IDEMPOTENCY_IN_PROGRESS');
                const resource = await action(client);
                const operationId = stableUuid(`${principal.userId}:${scope}:${keyHash}`);
                const response = {
                    operationId,
                    replayed: false,
                    resource: publicValue(resource),
                    requestId,
                    occurredAt: new Date().toISOString(),
                };
                await client.query(admin
                    ? 'select private.complete_tracking_admin_idempotency($1,$2,$3,$4,$5,$6,$7::jsonb,$8)'
                    : 'select private.complete_sync_idempotency_key($1,$2,$3,$4,$5,$6,$7::jsonb,$8)', [
                    principal.userId,
                    scope,
                    keyHash,
                    requestHash,
                    claim.lease_token,
                    status,
                    JSON.stringify(response),
                    typeof resource.id === 'string' ? resource.id : operationId,
                ]);
                return response;
            });
        }
        catch (error) {
            throw mappedError(error);
        }
    }
    ownerJson(principal, sql, values) {
        return this.owner(principal, async (client) => publicValue(await this.queryJson(client, sql, values)));
    }
    async queryJson(client, sql, values) {
        const result = (await client.query(sql, [...values])).rows[0]?.result;
        if (!result)
            throw new Error('TRACKING_RESULT_MISSING');
        return result;
    }
    owner(principal, action) {
        return this.transaction('masarifi_api', principal, action);
    }
    claimedWorker(kind, id, token, action) {
        return this.worker(async (client) => {
            await client.query('select private.set_tracking_worker_context($1,$2::uuid,$3::uuid)', [
                kind,
                id,
                token,
            ]);
            return action(client);
        });
    }
    worker(action) {
        return this.transaction('masarifi_worker', null, action);
    }
    async transaction(role, principal, action) {
        return this.pool.withClient(async (client) => {
            await client.query('begin');
            try {
                if (principal)
                    await client.query("select set_config('request.jwt.claims',$1,true)", [
                        JSON.stringify({
                            role: 'authenticated',
                            sub: principal.userId,
                            sid: principal.sessionId,
                        }),
                    ]);
                await client.query(role === 'masarifi_api'
                    ? 'set local role masarifi_api'
                    : 'set local role masarifi_worker');
                const result = await action(client);
                await client.query('commit');
                return result;
            }
            catch (error) {
                await client.query('rollback');
                throw mappedError(error);
            }
        });
    }
};
exports.TrackingRepository = TrackingRepository;
exports.TrackingRepository = TrackingRepository = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [pool_service_1.PoolService])
], TrackingRepository);
