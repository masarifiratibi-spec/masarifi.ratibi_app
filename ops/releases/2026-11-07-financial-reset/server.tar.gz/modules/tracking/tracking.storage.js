"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.TrackingStorage = void 0;
const common_1 = require("@nestjs/common");
const missing_storage_object_1 = require("../platform/storage/missing-storage-object");
const platform_config_service_1 = require("../platform/config/platform-config.service");
const KEY = /^tracking\/[0-9a-f-]{36}\/[0-9a-f-]{36}$/;
let TrackingStorage = class TrackingStorage {
    fetcher;
    origin;
    credential;
    constructor(config, fetcher = fetch) {
        this.fetcher = fetcher;
        this.origin = new URL(config.getRequired('SUPABASE_URL'));
        this.credential = config.getRequired('SUPABASE_SERVICE_ROLE_KEY');
    }
    async upload(key, body, contentType) {
        const status = await this.request(key, {
            method: 'PUT',
            headers: {
                'Content-Type': contentType,
                'Content-Length': String(body.length),
                'x-upsert': 'false',
            },
            body: body,
        });
        return status !== 409;
    }
    async delete(key) {
        await this.request(key, { method: 'DELETE' });
    }
    async request(key, input) {
        if (!KEY.test(key))
            throw new Error('TRACKING_STORAGE_INVALID');
        const controller = new AbortController();
        const timeout = setTimeout(() => {
            controller.abort();
        }, 10_000);
        const headers = new Headers(input.headers);
        headers.set('Authorization', `Bearer ${this.credential}`);
        headers.set('apikey', this.credential);
        try {
            const encoded = key.split('/').map(encodeURIComponent).join('/');
            const response = await this.fetcher(new URL(`/storage/v1/object/tracking-imports/${encoded}`, this.origin), { ...input, headers, signal: controller.signal });
            if (!response.ok &&
                !(input.method === 'PUT' && response.status === 409) &&
                !(input.method === 'DELETE' && (await (0, missing_storage_object_1.isMissingStorageObject)(response, controller.signal))))
                throw new Error('TRACKING_STORAGE_UNAVAILABLE');
            return response.status;
        }
        catch (error) {
            if (error instanceof Error && error.message === 'TRACKING_STORAGE_INVALID')
                throw error;
            throw new Error('TRACKING_STORAGE_UNAVAILABLE');
        }
        finally {
            clearTimeout(timeout);
        }
    }
};
exports.TrackingStorage = TrackingStorage;
exports.TrackingStorage = TrackingStorage = __decorate([
    (0, common_1.Injectable)(),
    __param(1, (0, common_1.Optional)()),
    __metadata("design:paramtypes", [platform_config_service_1.PlatformConfigService, Object])
], TrackingStorage);
