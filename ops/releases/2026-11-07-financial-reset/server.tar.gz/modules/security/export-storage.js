"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ExportStorage = void 0;
const common_1 = require("@nestjs/common");
const missing_storage_object_1 = require("../platform/storage/missing-storage-object");
const platform_config_service_1 = require("../platform/config/platform-config.service");
const keyPattern = /^exports\/[A-Za-z0-9-]{1,64}\/[A-Za-z0-9._/-]{1,256}\.zip$/;
function storageError(code = 'EXPORT_STORAGE_UNAVAILABLE') {
    return new Error(code);
}
let ExportStorage = class ExportStorage {
    fetcher;
    origin;
    credential;
    constructor(config, fetcher = fetch) {
        this.fetcher = fetcher;
        this.origin = new URL(config.getRequired('SUPABASE_URL'));
        this.credential = config.getRequired('SUPABASE_SERVICE_ROLE_KEY');
    }
    async upload(key, body, bytes) {
        if (bytes !== undefined && (!Number.isSafeInteger(bytes) || bytes < 1))
            throw storageError('EXPORT_STORAGE_INVALID');
        await this.request(key, '', {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/zip',
                ...(bytes === undefined ? {} : { 'Content-Length': String(bytes) }),
                'x-upsert': 'false',
            },
            body: body,
            duplex: 'half',
        });
    }
    async head(key, expectedBytes) {
        const response = await this.request(key, '', { method: 'HEAD' });
        const length = response.headers.get('content-length');
        const bytes = Number(length);
        if (!/^[0-9]+$/.test(length ?? '') || !Number.isSafeInteger(bytes) || bytes !== expectedBytes) {
            throw storageError('EXPORT_STORAGE_INTEGRITY_FAILED');
        }
        return { bytes, etag: response.headers.get('etag')?.replace(/^"|"$/g, '') ?? null };
    }
    async sign(key, expiresInSeconds) {
        if (!Number.isInteger(expiresInSeconds) || expiresInSeconds < 60 || expiresInSeconds > 900) {
            throw storageError('EXPORT_STORAGE_INVALID');
        }
        const response = await this.request(key, 'sign/', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ expiresIn: expiresInSeconds }),
        });
        let value;
        try {
            value = await response.json();
        }
        catch {
            throw storageError();
        }
        const signedUrl = typeof value === 'object' && value !== null
            ? value.signedURL
            : undefined;
        if (typeof signedUrl !== 'string') {
            throw storageError();
        }
        const signed = new URL(signedUrl, this.origin);
        const expectedPath = `/storage/v1/object/sign/report-exports/${key.split('/').map(encodeURIComponent).join('/')}`;
        if (signed.origin !== this.origin.origin || signed.pathname !== expectedPath)
            throw storageError();
        return signed.toString();
    }
    async delete(key) {
        await this.request(key, '', { method: 'DELETE' });
    }
    async request(key, prefix, input) {
        if (!keyPattern.test(key) || key.includes('..') || key.includes('//') || key.includes('\\')) {
            throw storageError('EXPORT_STORAGE_INVALID');
        }
        const encoded = key.split('/').map(encodeURIComponent).join('/');
        const controller = new AbortController();
        const timeout = setTimeout(() => {
            controller.abort();
        }, 10_000);
        const headers = new Headers(input.headers);
        headers.set('Authorization', `Bearer ${this.credential}`);
        headers.set('apikey', this.credential);
        try {
            const response = await this.fetcher(new URL(`/storage/v1/object/${prefix}report-exports/${encoded}`, this.origin), {
                ...input,
                redirect: 'error',
                signal: controller.signal,
                headers,
            });
            if (!response.ok &&
                !(input.method === 'DELETE' && (await (0, missing_storage_object_1.isMissingStorageObject)(response, controller.signal))))
                throw storageError();
            return response;
        }
        catch (error) {
            if (error instanceof Error &&
                ['EXPORT_STORAGE_INVALID', 'EXPORT_STORAGE_INTEGRITY_FAILED'].includes(error.message))
                throw error;
            throw storageError();
        }
        finally {
            clearTimeout(timeout);
        }
    }
};
exports.ExportStorage = ExportStorage;
exports.ExportStorage = ExportStorage = __decorate([
    (0, common_1.Injectable)(),
    __param(1, (0, common_1.Optional)()),
    __metadata("design:paramtypes", [platform_config_service_1.PlatformConfigService, Object])
], ExportStorage);
