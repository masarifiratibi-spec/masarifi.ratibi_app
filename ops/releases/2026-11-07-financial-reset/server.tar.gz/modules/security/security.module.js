"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.SecurityModule = exports.SecurityWorkerModule = void 0;
const common_1 = require("@nestjs/common");
const database_module_1 = require("../platform/database/database.module");
const identity_module_1 = require("../identity/identity.module");
const admin_auth_guard_1 = require("./admin-auth.guard");
const financial_reset_controller_1 = require("./financial-reset.controller");
const financial_reset_service_1 = require("./financial-reset.service");
const financial_reset_worker_1 = require("./financial-reset.worker");
const security_controller_1 = require("./security.controller");
const export_storage_1 = require("./export-storage");
const security_repository_1 = require("./security.repository");
const security_service_1 = require("./security.service");
const security_worker_1 = require("./security.worker");
const tracking_privacy_handler_1 = require("../tracking/tracking-privacy.handler");
const tracking_storage_1 = require("../tracking/tracking.storage");
const ai_privacy_handler_1 = require("../ai/ai-privacy.handler");
const ai_storage_1 = require("../ai/ai.storage");
const engagement_privacy_handler_1 = require("../engagement/engagement-privacy.handler");
const support_storage_1 = require("../engagement/support.storage");
const reports_storage_1 = require("../reports/reports.storage");
const owner_data_erasure_service_1 = require("./owner-data-erasure.service");
const immediate_deletion_service_1 = require("./immediate-deletion.service");
const deletion_completion_controller_1 = require("./deletion-completion.controller");
let SecurityWorkerModule = class SecurityWorkerModule {
};
exports.SecurityWorkerModule = SecurityWorkerModule;
exports.SecurityWorkerModule = SecurityWorkerModule = __decorate([
    (0, common_1.Module)({
        imports: [database_module_1.DatabaseModule, identity_module_1.IdentityWorkerModule],
        providers: [
            security_repository_1.SecurityRepository,
            export_storage_1.ExportStorage,
            tracking_storage_1.TrackingStorage,
            tracking_privacy_handler_1.TrackingPrivacyHandler,
            ai_storage_1.AiStorage,
            ai_privacy_handler_1.AiPrivacyHandler,
            support_storage_1.SupportStorage,
            engagement_privacy_handler_1.EngagementPrivacyHandler,
            security_worker_1.SecurityWorkerService,
            reports_storage_1.ReportsStorage,
            financial_reset_worker_1.FinancialResetWorker,
            owner_data_erasure_service_1.OwnerDataErasureService,
        ],
        exports: [security_worker_1.SecurityWorkerService, financial_reset_worker_1.FinancialResetWorker],
    })
], SecurityWorkerModule);
let SecurityModule = class SecurityModule {
};
exports.SecurityModule = SecurityModule;
exports.SecurityModule = SecurityModule = __decorate([
    (0, common_1.Module)({
        imports: [database_module_1.DatabaseModule, identity_module_1.IdentityModule],
        controllers: [security_controller_1.SecurityController, deletion_completion_controller_1.DeletionCompletionController, financial_reset_controller_1.FinancialResetController],
        providers: [
            security_repository_1.SecurityRepository,
            security_service_1.SecurityService,
            admin_auth_guard_1.AdminAuthGuard,
            export_storage_1.ExportStorage,
            immediate_deletion_service_1.ImmediateDeletionService,
            financial_reset_service_1.FinancialResetService,
        ],
        exports: [security_repository_1.SecurityRepository, security_service_1.SecurityService, admin_auth_guard_1.AdminAuthGuard],
    })
], SecurityModule);
