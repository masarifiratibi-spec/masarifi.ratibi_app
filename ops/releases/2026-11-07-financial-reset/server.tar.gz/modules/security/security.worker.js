"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.SecurityWorkerService = void 0;
const node_crypto_1 = require("node:crypto");
const node_stream_1 = require("node:stream");
const common_1 = require("@nestjs/common");
const clerk_client_service_1 = require("../identity/clerk-client.service");
const identity_privacy_handler_1 = require("../identity/identity-privacy.handler");
const platform_config_service_1 = require("../platform/config/platform-config.service");
const platform_metrics_1 = require("../platform/observability/platform-metrics");
const export_package_1 = require("./export-package");
const export_storage_1 = require("./export-storage");
const privacy_handlers_1 = require("./privacy-handlers");
const security_repository_1 = require("./security.repository");
const security_events_1 = require("./security.events");
const tracking_privacy_handler_1 = require("../tracking/tracking-privacy.handler");
const ai_privacy_handler_1 = require("../ai/ai-privacy.handler");
const engagement_privacy_handler_1 = require("../engagement/engagement-privacy.handler");
const owner_data_erasure_service_1 = require("./owner-data-erasure.service");
let SecurityWorkerService = class SecurityWorkerService {
    repository;
    storage;
    config;
    erasure;
    timer;
    running = false;
    registry;
    constructor(repository, storage, identity, tracking, ai, engagement, config, erasure) {
        this.repository = repository;
        this.storage = storage;
        this.config = config;
        this.erasure = erasure;
        const manifest = config.get('MASARIFI_PRIVACY_HANDLER_MANIFEST');
        if (!manifest)
            throw new Error('PRIVACY_HANDLER_MANIFEST_MISSING');
        this.registry = new privacy_handlers_1.PrivacyHandlerRegistry([ai, engagement, identity, tracking], manifest);
    }
    start() {
        if (this.timer)
            return;
        this.timer = setInterval(() => {
            void this.runOnce();
        }, this.config.getRequired('MASARIFI_SECURITY_WORKER_POLL_MS'));
        this.timer.unref();
        void this.runOnce();
    }
    async stop() {
        if (this.timer)
            clearInterval(this.timer);
        this.timer = undefined;
        while (this.running)
            await new Promise((resolve) => setTimeout(resolve, 10));
    }
    async runOnce() {
        if (this.running)
            return;
        this.running = true;
        try {
            await this.isolated('support-expiry', () => this.expireSupportGrants());
            await this.isolated('security-alerts', () => this.dispatchSecurityAlerts());
            await this.isolated('privacy-export', async () => {
                await this.expireExports();
                await this.generateExport();
            });
            await this.isolated('account-deletion', () => this.deleteAccountsAndUploads());
            await this.isolated('retention', () => this.applyRetention());
        }
        finally {
            this.running = false;
        }
    }
    async runJob(job) {
        const handlers = {
            'security.support-expire': () => this.expireSupportGrants(),
            'security.alert-dispatch': () => this.dispatchSecurityAlerts(),
            'privacy.export-generate': () => this.generateExport(),
            'privacy.export-expire': () => this.expireExports(),
            'privacy.account-delete': () => this.deleteAccountsAndUploads(),
            'retention.apply': () => this.applyRetention(),
        };
        const handler = handlers[job];
        if (!handler)
            throw new Error('SECURITY_JOB_UNKNOWN');
        await this.measured(job, handler);
    }
    async runDeletionForOwner(userId) {
        if (!/^[A-Za-z0-9_-]{1,128}$/.test(userId))
            throw new Error('PRIVACY_OWNER_INVALID');
        await this.measured('privacy.account-delete', async () => {
            await this.executeDeletion(userId);
            await this.erasure.purgeOutstandingUploads(userId);
        });
    }
    async runDeletionRequestForOwner(userId, requestId) {
        if (!/^[A-Za-z0-9_-]{1,128}$/.test(userId))
            throw new Error('PRIVACY_OWNER_INVALID');
        if (!/^[0-9a-f]{8}(?:-[0-9a-f]{4}){3}-[0-9a-f]{12}$/i.test(requestId))
            throw new Error('PRIVACY_REQUEST_INVALID');
        await this.measured('privacy.account-delete', async () => {
            await this.executeDeletion(userId, requestId);
            await this.erasure.purgeOutstandingUploads(userId);
        });
        return this.repository.getDeletionRequestForWorker(userId, requestId);
    }
    async measured(job, action) {
        const startedAt = performance.now();
        try {
            await action();
            (0, platform_metrics_1.recordPlatformMetric)(platform_metrics_1.SECURITY_METRICS.jobRun, 1, { job, outcome: 'success' });
        }
        catch (error) {
            (0, platform_metrics_1.recordPlatformMetric)(platform_metrics_1.SECURITY_METRICS.jobRun, 1, { job, outcome: 'failure' });
            throw error;
        }
        finally {
            (0, platform_metrics_1.recordPlatformMetric)(platform_metrics_1.SECURITY_METRICS.jobDuration, performance.now() - startedAt, { job });
        }
    }
    async isolated(job, action) {
        await this.measured(job, action).catch(() => undefined);
    }
    async expireSupportGrants() {
        await this.repository.withWorkerTransaction(async (client) => {
            const expired = await client.query(`with due as (select id from private.support_access_requests where status='approved' and expires_at<=clock_timestamp()
        order by expires_at,id for update skip locked limit $1)
        update private.support_access_requests r set status='expired',decided_at=coalesce(decided_at,clock_timestamp()) from due where r.id=due.id
        returning r.id,r.user_id,r.assignee,r.scope`, [this.config.getRequired('MASARIFI_SECURITY_JOB_BATCH_SIZE')]);
            for (const request of expired.rows) {
                const grant = (await client.query(`update private.support_access_grants set revoked_at=clock_timestamp()
          where request_id=$1 and revoked_at is null returning id`, [request.id])).rows[0];
                if (!grant)
                    continue;
                const occurredAt = new Date().toISOString();
                await client.query(`select private.enqueue_outbox_event('support_access.revoked','support_request',$1,$2)`, [
                    request.id,
                    JSON.stringify((0, security_events_1.buildSecurityEventPayload)('support_access.revoked', {
                        requestId: request.id,
                        grantId: grant.id,
                        adminId: request.assignee,
                        userId: request.user_id,
                        scopeKeys: this.scopeKeys(request.scope),
                        occurredAt,
                    })),
                ]);
                await client.query('select audit.append_event($1,$2,$3,$4,$5,$6,$7,$8,$9,$10)', [
                    null,
                    'system',
                    'security.support-access-expired',
                    'support_request',
                    request.id,
                    null,
                    null,
                    'Automatic support grant expiry',
                    request.id,
                    JSON.stringify({ operation: 'support-expiry' }),
                ]);
            }
        });
    }
    async dispatchSecurityAlerts() {
        await this.repository.withWorkerTransaction(async (client) => {
            await client.query('select private.dispatch_security_alerts($1)', [
                this.config.getRequired('MASARIFI_SECURITY_JOB_BATCH_SIZE'),
            ]);
        });
    }
    async generateExport() {
        const claim = await this.repository.withWorkerTransaction(async (client) => {
            const result = await client.query(`with selected as (
          select e.id from private.privacy_export_requests e join public.profiles p on p.id=e.user_id and p.status='active'
          where e.status='verified' or (e.status='processing' and e.updated_at<=clock_timestamp()-interval '15 minutes')
          order by e.requested_at,e.id for share of p skip locked for update of e skip locked limit 1)
        update private.privacy_export_requests r set status='processing',error_code=null from selected where r.id=selected.id
        returning r.id,r.user_id,r.scope`);
            return result.rows[0];
        });
        if (!claim)
            return;
        const key = `exports/${claim.id}/privacy.zip`;
        const uploadOutcome = { succeeded: false };
        const evidence = {
            requestId: claim.id,
            userId: claim.user_id,
            evidenceAt: new Date(),
            correlationId: (0, node_crypto_1.randomUUID)(),
        };
        try {
            const entries = [];
            const handlers = claim.scope.map((entry) => this.registry
                .entries()
                .find((handler) => `${handler.resourceType}@${String(handler.schemaVersion)}` === entry));
            if (handlers.length < 1 || handlers.some((handler) => !handler))
                throw new Error('PRIVACY_HANDLER_MANIFEST_MISMATCH');
            for (const handler of handlers) {
                if (!handler)
                    throw new Error('PRIVACY_HANDLER_MANIFEST_MISMATCH');
                for await (const entry of handler.export(evidence))
                    entries.push(entry);
            }
            const stream = new node_stream_1.PassThrough();
            const upload = this.storage.upload(key, stream).then(() => {
                uploadOutcome.succeeded = true;
            });
            const [packaged] = await Promise.all([
                (0, export_package_1.writeExportPackage)(entries, stream, {
                    maxBytes: this.config.getRequired('MASARIFI_EXPORT_MAX_BYTES'),
                    maxEntries: this.config.getRequired('MASARIFI_EXPORT_MAX_ENTRIES'),
                }),
                upload,
            ]);
            await this.storage.head(key, packaged.bytes);
            await this.repository.withWorkerTransaction(async (client) => {
                await client.query(`update private.privacy_export_requests set status='ready',storage_ref=$2,completed_at=clock_timestamp(),
          expires_at=clock_timestamp()+make_interval(hours=>$3) where id=$1 and status='processing'`, [claim.id, key, this.config.getRequired('MASARIFI_EXPORT_RETENTION_HOURS')]);
                const expiresAt = new Date(Date.now() + this.config.getRequired('MASARIFI_EXPORT_RETENTION_HOURS') * 3_600_000).toISOString();
                await client.query(`select private.enqueue_outbox_event('privacy.export_ready','privacy_export',$1,$2)`, [
                    claim.id,
                    JSON.stringify((0, security_events_1.buildSecurityEventPayload)('privacy.export_ready', {
                        requestId: claim.id,
                        userId: claim.user_id,
                        expiresAt,
                        occurredAt: new Date().toISOString(),
                    })),
                ]);
            });
        }
        catch {
            await this.repository.withWorkerTransaction(async (client) => {
                await client.query("update private.privacy_export_requests set status='failed',error_code='EXPORT_GENERATION_FAILED' where id=$1 and status='processing'", [claim.id]);
            });
            if (uploadOutcome.succeeded)
                await this.storage.delete(key).catch(() => {
                });
        }
    }
    async expireExports() {
        const references = await this.repository.withWorkerTransaction(async (client) => {
            const rows = (await client.query(`with due as (select id from private.privacy_export_requests where status='ready' and expires_at<=clock_timestamp()
        order by expires_at,id for update skip locked limit $1)
        update private.privacy_export_requests r set status='expired' from due where r.id=due.id returning r.id,r.user_id,r.storage_ref,r.expires_at`, [this.config.getRequired('MASARIFI_SECURITY_JOB_BATCH_SIZE')])).rows;
            for (const row of rows)
                await client.query(`select private.enqueue_outbox_event('privacy.export_expired','privacy_export',$1,$2)`, [
                    row.id,
                    JSON.stringify((0, security_events_1.buildSecurityEventPayload)('privacy.export_expired', {
                        requestId: row.id,
                        userId: row.user_id,
                        expiresAt: row.expires_at.toISOString(),
                        occurredAt: new Date().toISOString(),
                    })),
                ]);
            return rows;
        });
        for (const { storage_ref } of references)
            await this.storage.delete(storage_ref).catch(() => {
            });
    }
    async deleteAccountsAndUploads() {
        await this.executeDeletion();
        await this.erasure.purgeDueUploads();
    }
    async executeDeletion(userId = null, requestId = null) {
        const claim = await this.repository.withWorkerTransaction(async (client) => {
            const result = await client.query(`with selected as (select d.id from private.account_deletion_requests d
        where ($1::text is null or d.user_id=$1) and ($2::uuid is null or d.id=$2) and (d.status='verified' or (d.status='processing' and d.updated_at<=clock_timestamp()-interval '15 minutes')) and d.cooling_off_ends_at<=clock_timestamp() and not exists(
          select 1 from private.retention_holds h where h.resource_id=d.user_id and h.starts_at<=clock_timestamp() and (h.ends_at is null or h.ends_at>clock_timestamp()))
        order by d.cooling_off_ends_at,d.id for update skip locked limit 1)
        update private.account_deletion_requests d set status='processing',error_code=null from selected where d.id=selected.id returning d.id,d.user_id`, [userId, requestId]);
            const claim = result.rows[0];
            if (claim)
                await client.query('select private.freeze_account_deletion_owner($1::uuid,$2)', [
                    claim.id,
                    claim.user_id,
                ]);
            return claim;
        });
        if (!claim)
            return;
        const evidence = {
            requestId: claim.id,
            userId: claim.user_id,
            evidenceAt: new Date(),
            correlationId: (0, node_crypto_1.randomUUID)(),
        };
        try {
            const outcomes = [];
            await this.erasure.prepare(evidence);
            const handlers = [...this.registry.entries()].sort((left, right) => Number(left.resourceType === 'identity') - Number(right.resourceType === 'identity'));
            for (const handler of handlers) {
                if (handler.resourceType === 'identity')
                    outcomes.push({ resourceType: 'owner-data', ...(await this.erasure.erase(evidence)) });
                const held = await this.repository.withWorkerTransaction(async (client) => (await client.query(`select exists(select 1 from private.retention_holds where resource_type=$1 and resource_id=$2
            and starts_at<=clock_timestamp() and (ends_at is null or ends_at>clock_timestamp())) held`, [handler.resourceType, claim.user_id])).rows[0]?.held === true);
                if (held)
                    throw new Error('ERASURE_ACTIVE_HOLD');
                outcomes.push({
                    resourceType: handler.resourceType,
                    ...(await handler.deleteAccount(evidence)),
                });
            }
            await this.repository.withWorkerTransaction(async (client) => {
                const completion = await client.query(`update private.account_deletion_requests set status='completed',completed_at=clock_timestamp(),retention_result=$2
          where id=$1 and status='processing'`, [claim.id, JSON.stringify({ outcomes })]);
                if (completion.rowCount !== 1)
                    throw new Error('DELETION_CLAIM_LOST');
                await client.query(`select private.enqueue_outbox_event('privacy.deletion_completed','deletion_request',$1,$2)`, [
                    claim.id,
                    JSON.stringify((0, security_events_1.buildSecurityEventPayload)('privacy.deletion_completed', {
                        requestId: claim.id,
                        userId: claim.user_id,
                        occurredAt: new Date().toISOString(),
                    })),
                ]);
            });
        }
        catch (error) {
            const dependencyBusy = error instanceof Error &&
                ['ERASURE_EXPORT_BUSY', 'ERASURE_WORK_BUSY'].includes(error.message);
            await this.repository.withWorkerTransaction(async (client) => {
                await client.query("update private.account_deletion_requests set status=$2,error_code=$3 where id=$1 and status='processing'", [
                    claim.id,
                    'processing',
                    error instanceof clerk_client_service_1.ClerkProviderUnavailableError
                        ? 'DELETION_PROVIDER_UNAVAILABLE'
                        : dependencyBusy
                            ? 'DELETION_DEPENDENCY_BUSY'
                            : 'DELETION_HANDLER_FAILED',
                ]);
            });
        }
    }
    async applyRetention() {
        const policies = await this.repository.withWorkerTransaction(async (client) => (await client.query('select id,resource_type,retention_days,deletion_mode from private.retention_policies where enabled order by resource_type limit $1', [this.config.getRequired('MASARIFI_SECURITY_JOB_BATCH_SIZE')])).rows);
        for (const policy of policies) {
            const handler = this.registry
                .entries()
                .find(({ resourceType }) => resourceType === policy.resource_type);
            if (!handler)
                throw new Error('PRIVACY_HANDLER_MANIFEST_MISMATCH');
            const candidates = await handler.listRetentionCandidates(new Date(Date.now() - policy.retention_days * 86_400_000), null, this.config.getRequired('MASARIFI_SECURITY_JOB_BATCH_SIZE'));
            for (const candidate of candidates.items) {
                const held = await this.repository.withWorkerTransaction(async (client) => (await client.query(`select exists(select 1 from private.retention_holds where resource_type=$1 and resource_id=$2
            and starts_at<=clock_timestamp() and (ends_at is null or ends_at>clock_timestamp())) held`, [policy.resource_type, candidate.resourceId])).rows[0]?.held === true);
                if (!held)
                    await handler.applyRetention(candidate, policy.deletion_mode, {
                        requestId: policy.id,
                        userId: candidate.resourceId,
                        evidenceAt: new Date(),
                        correlationId: (0, node_crypto_1.randomUUID)(),
                    });
            }
        }
    }
    scopeKeys(value) {
        if (!Array.isArray(value))
            return [];
        return value
            .flatMap((entry) => typeof entry === 'object' &&
            entry !== null &&
            typeof entry.resource === 'string' &&
            Array.isArray(entry.actions)
            ? entry.actions.flatMap((action) => typeof action === 'string'
                ? [`${entry.resource}:${action}`]
                : [])
            : [])
            .sort()
            .slice(0, 18);
    }
};
exports.SecurityWorkerService = SecurityWorkerService;
exports.SecurityWorkerService = SecurityWorkerService = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [security_repository_1.SecurityRepository,
        export_storage_1.ExportStorage,
        identity_privacy_handler_1.IdentityPrivacyHandler,
        tracking_privacy_handler_1.TrackingPrivacyHandler,
        ai_privacy_handler_1.AiPrivacyHandler,
        engagement_privacy_handler_1.EngagementPrivacyHandler,
        platform_config_service_1.PlatformConfigService,
        owner_data_erasure_service_1.OwnerDataErasureService])
], SecurityWorkerService);
