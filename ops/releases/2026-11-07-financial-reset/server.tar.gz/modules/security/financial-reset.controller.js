"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.FinancialResetController = exports.FinancialResetCommand = void 0;
const common_1 = require("@nestjs/common");
const swagger_1 = require("@nestjs/swagger");
const class_validator_1 = require("class-validator");
const clerk_auth_guard_1 = require("../identity/clerk-auth.guard");
const financial_reset_service_1 = require("./financial-reset.service");
class FinancialResetCommand {
    operationId;
}
exports.FinancialResetCommand = FinancialResetCommand;
__decorate([
    (0, swagger_1.ApiProperty)({ format: 'uuid' }),
    (0, class_validator_1.IsUUID)(),
    __metadata("design:type", String)
], FinancialResetCommand.prototype, "operationId", void 0);
class FinancialResetReceipt {
    id;
    status;
    generation;
}
__decorate([
    (0, swagger_1.ApiProperty)({ format: 'uuid' }),
    __metadata("design:type", String)
], FinancialResetReceipt.prototype, "id", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ enum: ['processing', 'completed'] }),
    __metadata("design:type", String)
], FinancialResetReceipt.prototype, "status", void 0);
__decorate([
    (0, swagger_1.ApiProperty)(),
    __metadata("design:type", Number)
], FinancialResetReceipt.prototype, "generation", void 0);
class FinancialResetState {
    generation;
    resetAt;
    status;
    requestId;
}
__decorate([
    (0, swagger_1.ApiProperty)(),
    __metadata("design:type", Number)
], FinancialResetState.prototype, "generation", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ type: String, format: 'date-time', nullable: true }),
    __metadata("design:type", Object)
], FinancialResetState.prototype, "resetAt", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ enum: ['ready', 'processing'] }),
    __metadata("design:type", String)
], FinancialResetState.prototype, "status", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ type: String, format: 'uuid', nullable: true }),
    __metadata("design:type", Object)
], FinancialResetState.prototype, "requestId", void 0);
function principal(request) {
    if (!request.clerkPrincipal)
        throw new common_1.HttpException({ code: 'AUTH_TOKEN_INVALID' }, 401);
    return request.clerkPrincipal;
}
let FinancialResetController = class FinancialResetController {
    service;
    constructor(service) {
        this.service = service;
    }
    reset(request, command) {
        return this.service.reset(principal(request), command.operationId);
    }
    state(request) {
        return this.service.state(principal(request));
    }
    receipt(request, id) {
        return this.service.receipt(principal(request), id);
    }
};
exports.FinancialResetController = FinancialResetController;
__decorate([
    (0, common_1.Post)(),
    (0, swagger_1.ApiOperation)({ operationId: 'resetMyFinancialData' }),
    (0, common_1.HttpCode)(200),
    (0, common_1.Header)('Cache-Control', 'no-store'),
    (0, swagger_1.ApiOkResponse)({ type: FinancialResetReceipt }),
    __param(0, (0, common_1.Req)()),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, FinancialResetCommand]),
    __metadata("design:returntype", void 0)
], FinancialResetController.prototype, "reset", null);
__decorate([
    (0, common_1.Get)('state'),
    (0, swagger_1.ApiOperation)({ operationId: 'getMyFinancialResetState' }),
    (0, common_1.Header)('Cache-Control', 'no-store'),
    (0, swagger_1.ApiOkResponse)({ type: FinancialResetState }),
    __param(0, (0, common_1.Req)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", void 0)
], FinancialResetController.prototype, "state", null);
__decorate([
    (0, common_1.Get)(':id'),
    (0, swagger_1.ApiOperation)({ operationId: 'getMyFinancialResetReceipt' }),
    (0, common_1.Header)('Cache-Control', 'no-store'),
    (0, swagger_1.ApiOkResponse)({ type: FinancialResetReceipt }),
    __param(0, (0, common_1.Req)()),
    __param(1, (0, common_1.Param)('id', common_1.ParseUUIDPipe)),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, String]),
    __metadata("design:returntype", void 0)
], FinancialResetController.prototype, "receipt", null);
exports.FinancialResetController = FinancialResetController = __decorate([
    (0, swagger_1.ApiTags)('Privacy'),
    (0, swagger_1.ApiBearerAuth)('ClerkBearer'),
    (0, common_1.UseGuards)(clerk_auth_guard_1.ClerkAuthGuard),
    (0, common_1.Controller)('api/v1/me/financial-reset'),
    __metadata("design:paramtypes", [financial_reset_service_1.FinancialResetService])
], FinancialResetController);
