"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.FinancialResetWorker = void 0;
const common_1 = require("@nestjs/common");
const ai_storage_1 = require("../ai/ai.storage");
const reports_storage_1 = require("../reports/reports.storage");
const tracking_storage_1 = require("../tracking/tracking.storage");
const export_storage_1 = require("./export-storage");
const security_repository_1 = require("./security.repository");
let FinancialResetWorker = class FinancialResetWorker {
    repository;
    voice;
    report;
    tracking;
    exports;
    constructor(repository, voice, report, tracking, exports) {
        this.repository = repository;
        this.voice = voice;
        this.report = report;
        this.tracking = tracking;
        this.exports = exports;
    }
    async run(owner = null) {
        const batch = await this.repository.withWorkerTransaction(async (client) => (await client.query('select * from private.list_pending_financial_reset_objects(16,$1)', [owner])).rows);
        const storage = {
            voice: this.voice,
            report: this.report,
            tracking: this.tracking,
            export: this.exports,
        };
        let failed = false;
        for (const object of batch) {
            try {
                await storage[object.kind].delete(object.storage_ref);
                await this.repository.withWorkerTransaction(async (client) => {
                    await client.query("select set_config('request.jwt.claims',$1,true)", [
                        JSON.stringify({ role: 'worker', sub: object.owner_id }),
                    ]);
                    await client.query('select private.complete_financial_reset_object($1,$2::uuid,$3,$4)', [
                        object.owner_id,
                        object.request_id,
                        object.kind,
                        object.storage_ref,
                    ]);
                });
            }
            catch {
                failed = true;
            }
        }
        if (failed)
            throw new Error('FINANCIAL_RESET_CLEANUP_UNAVAILABLE');
        return batch.length;
    }
};
exports.FinancialResetWorker = FinancialResetWorker;
exports.FinancialResetWorker = FinancialResetWorker = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [security_repository_1.SecurityRepository,
        ai_storage_1.AiStorage,
        reports_storage_1.ReportsStorage,
        tracking_storage_1.TrackingStorage,
        export_storage_1.ExportStorage])
], FinancialResetWorker);
